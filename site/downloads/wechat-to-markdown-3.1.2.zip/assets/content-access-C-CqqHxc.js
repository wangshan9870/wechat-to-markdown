/*! wx2md-offline-protected */
class t extends Error{}function e(e,s){if([401,403,429].includes(e))throw new t(`任务已暂停（HTTP ${e}）：请停止批量请求，确认访问权限或稍后手动重试；不会自动绕过限制。`);if(s&&!/id\s*=\s*["']js_content["']/i.test(s)&&/环境异常|访问过于频繁|完成验证|验证码|captcha|verify_page/i.test(s))throw new t("任务已暂停：页面要求验证或触发访问限制，请在原页面处理；工具不会自动重试验证页面。")}export{t as C,e as a};
