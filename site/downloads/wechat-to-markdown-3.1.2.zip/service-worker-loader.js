import './assets/index.ts-my-gOoDJ.js';
