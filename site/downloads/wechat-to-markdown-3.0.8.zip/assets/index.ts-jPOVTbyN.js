import{f as te,h as Te,d as Se,j as ae,k as me,A as se,i as Ce,l as ee,m as Ee,s as $e,u as Fe,n as Ae,p as qe,q as Re,t as Ne,v as Oe,a as Ue}from"./official-site-DsUlxlf5.js";import{c as ge}from"./content-consent-BXr1hERJ.js";import{i as He,e as ze,a as $,r as De,b as je,c as Ye,d as j,f as oe,g as Ve,s as Me,t as he,h as ie,j as K,k as Be,l as We}from"./telemetry-client-DwJdKm-N.js";import{e as Ke}from"./library-BAT00Q9T.js";import{m as Xe,c as Ge}from"./quota-panel-C9dS0R8I.js";import{C as Qe,r as ce,v as Ze,c as Je,I as et}from"./release-CrTFwBnK.js";class ye extends Error{}function le(e,n){if([401,403,429].includes(e))throw new ye(`任务已暂停（HTTP ${e}）：请停止批量请求，确认访问权限或稍后手动重试；不会自动绕过限制。`);if(n&&!/id\s*=\s*["']js_content["']/i.test(n)&&/环境异常|访问过于频繁|完成验证|验证码|captcha|verify_page/i.test(n))throw new ye("任务已暂停：页面要求验证或触发访问限制，请在原页面处理；工具不会自动重试验证页面。")}function tt(e,n,r,c){const l=Math.max(n,0);if(e.restartButton.hidden=!r,e.libraryButton.hidden=!r,r)return e.primaryButton.textContent="下载新增文章",{mode:"licensed",trialCount:0,remaining:0};const u=Math.min(te,l),y=Math.max(l-u,0);return c?(e.primaryButton.textContent=y>0?`解锁剩余 ${y} 篇`:"解锁完整版",{mode:"trial-consumed",trialCount:u,remaining:y}):(e.primaryButton.textContent=`免费试用 ${u} 篇`,{mode:"trial-available",trialCount:u,remaining:y})}const ot=2;function Pe(e){return e.replace(/\s+/g," ").trim()}function rt(e){const n=[];let r="";for(const c of e){const l=Pe(c.text);if(!l||l===r)continue;const u=Math.min(6,Math.max(1,Math.round(c.level)||1));n.push({level:u,text:l}),r=l}return n}function nt(e){return rt(e).length>=ot}function at(e,n,r){const c=e.querySelector(".drawer"),l=document.createElement("style");l.textContent=`
    .drawer { overflow: visible; max-height: none; }
    .article-title { display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical;overflow:hidden;margin-bottom:14px; }
    .feedback:empty { display:none; }
    .account { display:none; }
    .reader-tools { display:flex;gap:6px;padding:0 14px 12px; }
    .reader-tools button,.quota-compact { border:0;border-radius:8px;background:#eef6f1;color:#426b54;padding:9px 6px;font:600 11px/1.5 -apple-system,BlinkMacSystemFont,"PingFang SC",sans-serif;cursor:pointer; }
    .reader-tools button { flex:1; }
    .reader-tools button:disabled { opacity:.55;cursor:default; }
    .reader-tools button[aria-expanded=true] { background:#d8eddf;color:#087f4e; }
    .reader-tools button:focus-visible,.quota-compact:focus-visible,.popover button:focus-visible { outline:2px solid #087f4e;outline-offset:2px; }
    .quota-compact { margin:0 14px 14px;text-align:left;background:transparent;border-top:1px solid #e3ece6;border-radius:0; }
    .popover { position:fixed;top:72px;right:326px;width:290px;max-width:calc(100vw - 32px);max-height:calc(100dvh - 92px);overflow:auto;overscroll-behavior:contain;background:#fbfdfb;border:1px solid #dbe8df;border-radius:14px;box-shadow:0 8px 30px #1b30232e;padding:14px;z-index:2147483647;color:#24352b;font:13px/1.5 -apple-system,BlinkMacSystemFont,"PingFang SC",sans-serif; }
    .popover[hidden] { display:none; }
    .popover-head { display:flex;align-items:center;gap:8px;margin-bottom:12px; }
    .popover-head strong { margin-right:auto; }
    .popover-head button { border:0;border-radius:6px;background:#eef6f1;color:#426b54;cursor:pointer;padding:5px 8px; }
    .popover-head button[aria-pressed=true] { background:#087f4e;color:white; }
    .popover .list { max-height:none;overflow:visible;padding:0; }
    .popover .export-settings-content { display:block;padding:0; }
    .popover .action { margin-top:8px; }
    .popover .wtm-quota { margin:0; }
    @media(max-width:650px) { .popover { right:16px; } .drawer {right:16px;} }
    @media(max-height:520px) { .drawer,.popover {top:12px;} .popover {max-height:calc(100dvh - 24px);} .drawer {max-height:calc(100dvh - 24px);overflow:auto;} }
  `,e.append(l);const u=document.createElement("div");u.className="reader-tools";const y=document.createElement("button");y.type="button",y.className="quota-compact",y.textContent="正在读取额度… · 权益 / 激活 ›";let t,i=!1;const f=new Map;function k(C=!1){const s=t&&f.get(t);for(const{panel:g,trigger:m}of f.values())g.hidden=!0,m.setAttribute("aria-expanded","false");t=void 0,C&&s&&s.trigger.focus()}function x(C){k();const s=f.get(C);t=C,s.panel.hidden=!1,s.trigger.setAttribute("aria-expanded","true"),s.panel.querySelector(".popover-close").focus()}function P(C,s,g){const m=g||document.createElement("button");m.type="button",g||(m.textContent=s,u.append(m)),m.dataset.panel=C,m.setAttribute("aria-expanded","false"),m.setAttribute("aria-controls",`reader-${C}`);const b=document.createElement("section");b.id=`reader-${C}`,b.className="popover",b.hidden=!0,b.setAttribute("aria-label",s);const h=document.createElement("div");h.className="popover-head";const L=document.createElement("strong");L.textContent=s;const a=document.createElement("button");return a.type="button",a.className="popover-close",a.textContent="×",a.setAttribute("aria-label",`关闭${s}`),a.onclick=()=>k(!0),h.append(L,a),b.append(h),e.append(b),f.set(C,{panel:b,trigger:m}),m.onclick=()=>t===C?k():x(C),b}const I=P("toc","文章目录");f.get("toc").trigger.textContent=n?`目录 ${r}`:"暂无目录",n||(f.get("toc").trigger.disabled=!0,f.get("toc").trigger.title="本文未使用标题结构，暂无目录");const A=document.createElement("button");A.type="button",A.textContent="固定",A.setAttribute("aria-pressed","false"),A.onclick=()=>{i=!i,A.textContent=i?"已固定":"固定",A.setAttribute("aria-pressed",String(i))},I.querySelector(".popover-head").insertBefore(A,I.querySelector(".popover-close")),I.append(e.querySelector(".list")),e.querySelector(".toc").remove();const T=P("settings","导出设置"),O=e.querySelector(".export-settings-content");O.removeAttribute("aria-hidden"),T.append(O),e.querySelector(".export-settings").remove();const z=P("more","更多");z.append(e.querySelector(".albums"),e.querySelector(".updates"),e.querySelector(".back-top"),e.querySelector(".community"));const Y=P("quota","额度与权益",y);return c.append(u,y),e.querySelector(".footer").remove(),document.addEventListener("pointerdown",C=>{C.target!==e.host&&!(t==="toc"&&i)&&k()}),{quotaPanel:Y,more:z,close:k,open:x,isActive:()=>!!t,isTocOpen:()=>t==="toc",onNavigate:()=>{i||k(!0)},setSummary:C=>{y.textContent=`${C} · 权益 / 激活 ›`}}}const st=`
  :host{all:initial;display:block}
  *{box-sizing:border-box}
  .notice{position:relative;margin:0;padding:12px 13px 13px;border:1px solid #cfe1d5;border-left:4px solid #087f4e;border-radius:10px;color:#33443a;background:#f7fbf8;box-shadow:0 5px 15px rgba(27,48,35,.08);font-family:-apple-system,BlinkMacSystemFont,"PingFang SC",sans-serif;animation:notice-in .18s ease-out}
  .topline{display:flex;align-items:center;justify-content:space-between;gap:10px;margin:0 28px 6px 0}
  .eyebrow{margin:0;color:#087f4e;font:700 10px/1 ui-monospace,SFMono-Regular,Menlo,monospace;letter-spacing:.06em}
  .version{flex:none;padding:3px 6px;border-radius:999px;color:#087f4e;background:#e3f2e8;font:700 10px/1 ui-monospace,SFMono-Regular,Menlo,monospace}
  h3{margin:0;color:#16211b;font:700 13px/1.45 -apple-system,BlinkMacSystemFont,"PingFang SC",sans-serif}
  .summary{margin:5px 0 0;color:#4f6056;font:400 12px/1.55 -apple-system,BlinkMacSystemFont,"PingFang SC",sans-serif}
  .hint{margin:7px 0 0;color:#728078;font:400 10px/1.5 -apple-system,BlinkMacSystemFont,"PingFang SC",sans-serif}
  .actions{display:flex;flex-wrap:wrap;align-items:center;gap:7px;margin-top:10px}
  a,.ignore{display:inline-flex;align-items:center;justify-content:center;min-height:30px;border-radius:8px;padding:7px 10px;font:600 11px/1 -apple-system,BlinkMacSystemFont,"PingFang SC",sans-serif;text-decoration:none;cursor:pointer}
  .primary{border:1px solid #087f4e;color:#fff;background:#087f4e}
  .primary:hover{background:#066d43}
  .secondary{border:1px solid #cfe1d5;color:#087f4e;background:#fff}
  .secondary:hover{background:#eef6f1}
  .ignore{border:0;color:#607068;background:transparent}
  .ignore:hover{color:#24352b;background:#e9f2ec}
  .ignore:disabled{opacity:.55;cursor:wait}
  .dismiss{position:absolute;top:7px;right:7px;display:grid;width:28px;height:28px;place-items:center;border:0;border-radius:7px;color:#607068;background:transparent;font:700 15px/1 -apple-system,BlinkMacSystemFont,"PingFang SC",sans-serif;cursor:pointer}
  .dismiss:hover{color:#16211b;background:#e9f2ec}
  a:focus-visible,button:focus-visible{outline:3px solid #a6dbc0;outline-offset:2px}
  .feedback{min-height:14px;margin:7px 0 0;color:#a33b32;font:400 10px/1.4 -apple-system,BlinkMacSystemFont,"PingFang SC",sans-serif}
  @keyframes notice-in{from{opacity:0;transform:translateY(-3px)}to{opacity:1;transform:translateY(0)}}
  @media (prefers-reduced-motion:reduce){.notice{animation:none}}
`;function it(e){return typeof e=="object"&&e!==null&&!Array.isArray(e)}function ct(e){const n=e.channel==="store",r=n?e.storeUrl:e.offlineDownloadUrl,c=e.guideUrl&&e.guideUrl!==r?e.guideUrl:void 0;return{eyebrow:e.noticeLevel==="required"?"需要更新":"新版可用",primaryLabel:n?"打开扩展商店":"下载新版 ZIP",primaryUrl:r,...c?{secondaryLabel:"查看更新步骤",secondaryUrl:c}:{},channelHint:n?"商店版通常会自动更新；打开商店可立即查看新版本。":"离线版需手动更新：解压覆盖原目录，再到扩展管理页点击“重新加载”。",canIgnore:e.noticeLevel!=="required"}}async function lt(e){try{const n=await chrome.runtime.sendMessage({type:et,version:e});return n?.ok===!0&&n.ignored===!0}catch{return!1}}function dt(e){if(!it(e))return;const n=chrome.runtime.getManifest().version;if(e.currentVersion!==n||e.channel!==ce.channel)return;const r=Ze(e,{channel:ce.channel,trustedOrigins:ce.trustedOrigins});return r?Je(r,n,ce.channel):void 0}async function pt(){try{const e=await chrome.runtime.sendMessage({type:Qe});return e?.ok!==!0?void 0:dt(e.update)}catch{return}}function ut(e,n={}){const r=ct(e),c=document.createElement("div");c.dataset.wechatToMarkdownUpdate=e.latestVersion;const l=c.attachShadow({mode:"open"});l.innerHTML=`
    <style>${st}</style>
    <section class="notice" role="region" aria-live="polite" aria-labelledby="wtm-update-title">
      <button class="dismiss" type="button" aria-label="暂时关闭更新提示">×</button>
      <div class="topline">
        <p class="eyebrow"></p>
        <span class="version"></span>
      </div>
      <h3 id="wtm-update-title"></h3>
      <p class="summary"></p>
      <p class="hint"></p>
      <div class="actions"></div>
      <p class="feedback" role="status" aria-live="polite"></p>
    </section>`,l.querySelector(".eyebrow").textContent=r.eyebrow,l.querySelector(".version").textContent=`v${e.latestVersion}`,l.querySelector("h3").textContent=e.title,l.querySelector(".summary").textContent=e.summary,l.querySelector(".hint").textContent=r.channelHint;const u=l.querySelector(".actions"),y=l.querySelector(".feedback");if(r.primaryUrl){const i=document.createElement("a");i.className="primary",i.href=r.primaryUrl,i.target="_blank",i.rel="noopener noreferrer",i.textContent=r.primaryLabel,u.append(i)}if(r.secondaryUrl&&r.secondaryLabel){const i=document.createElement("a");i.className="secondary",i.href=r.secondaryUrl,i.target="_blank",i.rel="noopener noreferrer",i.textContent=r.secondaryLabel,u.append(i)}const t=()=>{c.remove(),n.onDismiss?.()};if(l.querySelector(".dismiss").addEventListener("click",t),r.canIgnore){const i=document.createElement("button");i.type="button",i.className="ignore",i.textContent="忽略此版本",i.addEventListener("click",()=>{(async()=>(i.disabled=!0,y.textContent="",await(n.onIgnore??lt)(e.latestVersion)?t():(i.disabled=!1,y.textContent="暂时无法保存此设置，请稍后再试。")))()}),u.append(i)}return{element:c,focus:()=>l.querySelector(".primary, .secondary, .dismiss")?.focus(),remove:t}}async function ft(e){const n=await pt();if(!n)return;const r=ut(n);return e.appendChild(r.element),r}const mt=90;function gt(e={}){if(!He()||document.querySelector("#wechat-to-markdown-reader-entry"))return;const n=document.querySelector("#js_content");if(!n)return;const r=[...n.querySelectorAll("h1, h2, h3, h4, h5, h6")],c=[];let l="";for(const o of r){const d=Pe(o.textContent||"");!d||d===l||(l=d,c.push({level:Math.min(6,Math.max(1,Math.round(Number(o.tagName.slice(1)))||1)),text:d,element:o}))}const u=nt(r.map(o=>({level:Number(o.tagName.slice(1)),text:o.textContent||""}))),y=document.createElement("div");y.id="wechat-to-markdown-reader-entry";const t=y.attachShadow({mode:"closed"});t.innerHTML=`
    <style>
      :host { all: initial; }
      * { box-sizing: border-box; }
      button { font-family: inherit; }
      .trigger {
        position: fixed; right: 30px; top: 50%; transform: translateY(-50%);
        z-index: 2147483646; display: grid; place-items: center;
        width: 30px; height: 56px; border: 0; border-radius: 12px;
        color: #fff; background: #087f4e; box-shadow: 0 9px 25px rgba(5, 67, 40, .27);
        font: 700 18px/1 -apple-system, BlinkMacSystemFont, "PingFang SC", sans-serif;
        cursor: pointer;
        transition: opacity .18s ease, transform .18s ease;
      }
      .trigger:hover { background: #066d43; }
      .trigger:focus-visible { outline: 3px solid #a6dbc0; outline-offset: 3px; }
      .trigger.hidden { opacity: 0; pointer-events: none; }
      .drawer {
        position: fixed; top: 72px; right: 30px; height: auto; max-height: calc(100vh - 92px); width: 280px; max-width: 85vw; overflow-y: auto; overscroll-behavior: contain;
        z-index: 2147483647; display: flex; flex-direction: column;
        color: #24352b; background: #fbfdfb; border-radius: 14px;
        box-shadow: 0 8px 30px rgba(27, 48, 35, .18);
        font-family: -apple-system, BlinkMacSystemFont, "PingFang SC", sans-serif;
        transform: translateX(calc(100% + 34px)); transition: transform .22s ease;
      }
      .drawer.open { transform: translateX(0); }
      .drawer > * { flex-shrink: 0; }
      .header { display: flex; align-items: center; justify-content: space-between; gap: 10px; padding: 14px 14px 12px; border-bottom: 1px solid #e3ece6; }
      .brand { display: flex; align-items: center; gap: 10px; min-width: 0; }
      .mark { display: grid; flex: none; width: 34px; height: 34px; place-items: center; border-radius: 10px 4px 10px 4px; color: #fff; background: #087f4e; box-shadow: 0 6px 14px rgba(8, 127, 78, .2); font: 400 18px/1 STSong, SimSun, serif; }
      .eyebrow { margin: 0 0 2px; color: #77847c; font: 600 8px/1 ui-monospace, monospace; letter-spacing: .14em; }
      .brand h2 { margin: 0; color: #16211b; font: 700 15px/1.2 -apple-system, BlinkMacSystemFont, "PingFang SC", sans-serif; letter-spacing: .03em; }
      .close { display: grid; flex: none; width: 30px; height: 30px; place-items: center; border: 0; border-radius: 8px; color: #607068; background: transparent; font: 700 15px/1 -apple-system, BlinkMacSystemFont, "PingFang SC", sans-serif; cursor: pointer; }
      .close:hover { background: #eef4f0; }
      .close:focus-visible { outline: 3px solid #a6dbc0; outline-offset: 1px; }
      .archive { padding: 14px 14px 12px; border-bottom: 1px solid #e3ece6; }
      .status { display: flex; align-items: center; gap: 7px; margin: 0 0 10px; color: #087f4e; font: 600 11px/1 -apple-system, BlinkMacSystemFont, "PingFang SC", sans-serif; }
      .status::before { content: ""; width: 6px; height: 6px; border-radius: 50%; background: #08a864; box-shadow: 0 0 0 4px #def4e8; }
      .article-title { margin: 0; color: #16211b; font: 700 16px/1.5 STSong, SimSun, serif; display: -webkit-box; -webkit-line-clamp: 3; -webkit-box-orient: vertical; overflow: hidden; }
      .account { margin: 6px 0 12px; color: #728078; font: 400 12px/1.4 -apple-system, BlinkMacSystemFont, "PingFang SC", sans-serif; }
      .archive-option { position: relative; display: flex; align-items: center; justify-content: space-between; gap: 12px; margin-bottom: 10px; padding: 10px 12px; border: 1px solid #dce6df; border-radius: 10px; background: #f4f8f5; cursor: pointer; }
      .archive-option strong, .archive-option small { display: block; }
      .archive-option strong { color: #24352b; font: 600 12px/1.3 -apple-system, BlinkMacSystemFont, "PingFang SC", sans-serif; }
      .archive-option small { margin-top: 3px; color: #77847c; font: 400 10px/1.4 -apple-system, BlinkMacSystemFont, "PingFang SC", sans-serif; }
      .archive-option input { position: absolute; width: 1px; height: 1px; opacity: 0; }
      .switch { position: relative; flex: 0 0 36px; width: 36px; height: 20px; border-radius: 999px; background: #b9c4bd; transition: background .16s ease; }
      .switch::after { content: ""; position: absolute; left: 3px; top: 3px; width: 14px; height: 14px; border-radius: 50%; background: #fff; box-shadow: 0 1px 3px rgba(0, 0, 0, .2); transition: transform .16s ease; }
      .archive-option input:checked + .switch { background: #087f4e; }
      .archive-option input:checked + .switch::after { transform: translateX(16px); }
      .archive-option input:focus-visible + .switch { outline: 3px solid #a6dbc0; outline-offset: 2px; }
      .segmented { display: flex; flex: none; border: 1px solid #cfdcd3; border-radius: 999px; background: #fff; overflow: hidden; }
      .option-stack { flex-direction: column; align-items: stretch; }
      .option-stack .segmented { margin-top: 8px; width: 100%; }
      .segment { flex: 1 1 0; min-width: 0; border: 0; padding: 6px 2px; color: #4a5950; background: transparent; font: 600 10px/1 -apple-system, BlinkMacSystemFont, "PingFang SC", sans-serif; text-align: center; cursor: pointer; transition: background .16s ease, color .16s ease; }
      .segment + .segment { border-left: 1px solid #e3ece6; }
      .segment:hover { background: #f1f7f3; }
      .segment.active { color: #fff; background: #087f4e; }
      .segment:focus-visible { outline: 3px solid #a6dbc0; outline-offset: -1px; }
      .archive-option.is-hidden { display: none; }
      .save-archive { display: flex; width: 100%; align-items: center; justify-content: space-between; border: 0; border-radius: 10px; padding: 12px 14px; color: #fff; background: #087f4e; font: 600 14px/1 -apple-system, BlinkMacSystemFont, "PingFang SC", sans-serif; cursor: pointer; transition: background .16s ease; }
      .save-archive:hover { background: #066d43; }
      .save-archive:focus-visible { outline: 3px solid #a6dbc0; outline-offset: 2px; }
      .save-archive:disabled { opacity: .62; cursor: wait; }
      .library-actions { display: grid; grid-template-columns: 1fr auto; gap: 8px; margin-top: 8px; }
      .library-actions[hidden] { display: none; }
      .archive-library, .open-library { min-height: 38px; border: 1px solid #b9d5c4; border-radius: 9px; color: #087f4e; background: #f7fbf8; font: 600 12px/1 -apple-system, BlinkMacSystemFont, "PingFang SC", sans-serif; cursor: pointer; }
      .archive-library { padding: 0 12px; text-align: left; }
      .open-library { width: 38px; padding: 0; font-size: 17px; }
      .archive-library:hover, .open-library:hover { background: #eaf5ed; }
      .archive-library:focus-visible, .open-library:focus-visible { outline: 3px solid #a6dbc0; outline-offset: 2px; }
      .archive-library:disabled { cursor: wait; opacity: .62; }
      .feedback { min-height: 15px; margin: 8px 0 0; color: #607068; font: 400 11px/1.4 -apple-system, BlinkMacSystemFont, "PingFang SC", sans-serif; text-align: center; }
      .export-settings { border-top: 1px solid #e3ece6; margin-top: 10px; }
      .export-settings-toggle { display: flex; align-items: center; justify-content: space-between; width: 100%; padding: 10px 14px; border: 0; background: transparent; color: #77847c; font: 600 11px/1 -apple-system, BlinkMacSystemFont, "PingFang SC", sans-serif; cursor: pointer; }
      .export-settings-toggle:hover { color: #4a5950; }
      .export-settings-toggle .chevron { transition: transform .2s ease; }
      .export-settings-toggle[aria-expanded="true"] .chevron { transform: rotate(180deg); }
      .export-settings-content { display: none; padding: 0 14px 12px; }
      .export-settings-content[aria-hidden="false"] { display: block; }
      .toc-toggle { display: flex; align-items: center; justify-content: space-between; padding: 12px 14px; list-style: none; color: #77847c; font: 600 11px/1.4 -apple-system, BlinkMacSystemFont, "PingFang SC", sans-serif; cursor: pointer; }
      .toc-toggle::-webkit-details-marker { display: none; }
      .toc-toggle:hover { color: #4a5950; }
      .toc-toggle:focus-visible { outline: 2px solid #087f4e; outline-offset: -3px; }
      .toc[open] .chevron { transform: rotate(180deg); }
      .list { max-height: min(32vh, 320px); overflow-y: auto; padding: 0 8px 12px; }
      .item { display: block; width: 100%; padding: 9px 10px; border: 0; border-radius: 8px; color: #4a5950; background: transparent; font: 400 13px/1.5 -apple-system, BlinkMacSystemFont, "PingFang SC", sans-serif; text-align: left; cursor: pointer; }
      .item:hover { background: #f1f7f3; color: #24352b; }
      .item:focus-visible { outline: 3px solid #a6dbc0; outline-offset: 1px; }
      .item.active { color: #087f4e; background: #eef6f1; font-weight: 600; }
      .empty { margin: 0 6px; padding: 10px; border: 1px dashed #d8e3dc; border-radius: 10px; color: #77847c; font: 400 12px/1.6 -apple-system, BlinkMacSystemFont, "PingFang SC", sans-serif; text-align: center; }
      .albums { display: grid; gap: 6px; padding: 8px 14px 10px; border-top: 1px solid #e3ece6; }
      .albums:empty { display: none; }
      .albums .label { color: #77847c; font: 400 11px/1.4 -apple-system, BlinkMacSystemFont, "PingFang SC", sans-serif; }
      .album { display: flex; align-items: center; justify-content: space-between; gap: 8px; width: 100%; padding: 8px 10px; border: 1px solid #d8e8de; border-radius: 9px; color: #087f4e; background: #f4faf6; font: 600 12px/1.4 -apple-system, BlinkMacSystemFont, "PingFang SC", sans-serif; text-align: left; cursor: pointer; }
      .album:hover { background: #e9f5ec; }
      .album:focus-visible { outline: 3px solid #a6dbc0; outline-offset: 1px; }
      .album .arrow { flex: none; color: #5f8a72; }
      .updates { padding: 8px 14px 10px; border-top: 1px solid #e3ece6; }
      .updates:empty { display: none; }
      .footer { padding: 10px 14px 14px; border-top: 1px solid #e3ece6; }
      .action { display: flex; width: 100%; align-items: center; justify-content: center; gap: 6px; padding: 10px 12px; border: 0; border-radius: 10px; color: #087f4e; background: #eef6f1; font: 600 13px/1 -apple-system, BlinkMacSystemFont, "PingFang SC", sans-serif; cursor: pointer; }
      .action:hover { background: #e3f0e7; }
      .footer > .action + .action { margin-top: 6px; }
      .action:focus-visible { outline: 3px solid #a6dbc0; outline-offset: 2px; }
      .toast {
        position: fixed; right: 16px; bottom: 20px; z-index: 2147483647;
        max-width: 260px; padding: 9px 12px; border: 1px solid #dbe5de; border-radius: 9px;
        color: #33443a; background: rgba(251, 253, 251, .97); box-shadow: 0 7px 20px rgba(27, 48, 35, .12);
        font: 400 12px/1.5 -apple-system, BlinkMacSystemFont, "PingFang SC", sans-serif;
        opacity: 0; pointer-events: none; transition: opacity .16s ease;
      }
      .toast.show { opacity: 1; }
      @media (prefers-reduced-motion: reduce) { .trigger, .drawer, .toast { transition: none; } }
    </style>
    <button class="trigger hidden" type="button" aria-label="展开文章存档面板" aria-expanded="true">‹</button>
    <aside class="drawer open" aria-hidden="false">
      <header class="header">
        <div class="brand">
          <div class="mark" aria-hidden="true">文</div>
          <div>
            <p class="eyebrow">WECHAT · MARKDOWN</p>
            <h2>文章存档</h2>
          </div>
        </div>
        <button class="close" type="button" aria-label="收起面板">›</button>
      </header>
      <section class="archive" aria-label="文章存档">
        <p class="status">已识别微信公众号文章</p>
        <h3 class="article-title"></h3>
        <p class="account"></p>
        <button class="save-archive" type="button">
          <span class="save-label">保存 Markdown</span>
          <span aria-hidden="true">↓</span>
        </button>
        <div class="library-actions">
          <button class="archive-library" type="button">☆ 加入本地文章库</button>
          <button class="open-library" type="button" aria-label="打开本地文章库" title="打开本地文章库">›</button>
        </div>
        <p class="feedback" role="status" aria-live="polite"></p>
        <div class="export-settings">
          <button class="export-settings-toggle" type="button" aria-expanded="false">
            <span>导出设置</span>
            <span class="chevron" aria-hidden="true">▼</span>
          </button>
          <div class="export-settings-content" aria-hidden="true">
            <div class="archive-option option-stack">
              <span>
                <strong>导出类型</strong>
                <small class="format-desc">Markdown · 适合笔记与知识库</small>
              </span>
              <span class="segmented" role="radiogroup" aria-label="导出类型">
                <button class="segment active" type="button" data-format="markdown" role="radio" aria-checked="true">MD</button>
                <button class="segment" type="button" data-format="html" role="radio" aria-checked="false">HTML</button>
                <button class="segment" type="button" data-format="image" role="radio" aria-checked="false">图片</button>
                <button class="segment" type="button" data-format="pdf" role="radio" aria-checked="false">PDF</button>
              </span>
            </div>
            <label class="archive-option download-option">
              <span>
                <strong>下载文章图片</strong>
                <small>导出 ZIP，离线阅读不依赖网络</small>
              </span>
              <input class="download-images" type="checkbox" role="switch" />
              <span class="switch" aria-hidden="true"></span>
            </label>
          </div>
        </div>
      </section>
      <details class="toc" ${u?"open":""}>
        <summary class="toc-toggle"><span>文章目录${u?"":" · 未检测到"}</span><span class="chevron" aria-hidden="true">▼</span></summary>
        <nav class="list" aria-label="文章目录"></nav>
      </details>
      <section class="albums" aria-label="所属合集"></section>
      <section class="updates" aria-label="扩展更新"></section>
      <footer class="footer">
        <button class="action back-top" type="button">↑ 返回顶部</button>
        <button class="action community" type="button">反馈 / 交流群</button>
      </footer>
    </aside>
    <div class="toast" role="status" aria-live="polite"></div>`;const i=t.querySelector(".trigger"),f=t.querySelector(".drawer"),k=t.querySelector(".close"),x=t.querySelector(".back-top"),P=t.querySelector(".community"),I=t.querySelector(".save-archive"),A=t.querySelector(".save-label");t.querySelector(".library-actions");const T=t.querySelector(".archive-library"),O=t.querySelector(".open-library"),z=t.querySelector(".download-images"),Y=t.querySelector(".download-option"),C=t.querySelector(".format-desc"),s=[...t.querySelectorAll(".segment")],g=t.querySelector(".feedback"),m=t.querySelector(".toast"),b=t.querySelector(".list"),h=t.querySelector(".albums"),L=t.querySelector(".updates"),a=at(t,u,c.length),v=Xe(a.quotaPanel,"reader_panel",void 0,a.setSummary),E=document.createElement("button");E.type="button",E.className="action",E.textContent="使用帮助",E.addEventListener("click",()=>{chrome.runtime.sendMessage({type:"OPEN_WELCOME"}).catch(()=>N("使用帮助暂时无法打开，请刷新页面后重试"))}),a.more.append(E);try{const o=ze();t.querySelector(".article-title").textContent=o.title,t.querySelector(".account").textContent=o.accountName||"公众号文章"}catch{t.querySelector(".article-title").textContent=document.title,t.querySelector(".account").textContent="公众号文章"}let M="markdown";const R=v.entry;function S(){if(M==="image"){A.textContent="保存图片";return}if(M==="pdf"){A.textContent="导出 PDF";return}if(z.checked){A.textContent="保存完整文章";return}A.textContent=M==="html"?"保存 HTML":"保存 Markdown"}function w(o,d=!0){M=o;for(const _ of s){const F=_.dataset.format===o;_.classList.toggle("active",F),_.setAttribute("aria-checked",String(F))}const p={markdown:"Markdown · 适合笔记与知识库",html:"HTML · 保留原文排版，可直接浏览",image:"图片 · 生成一张分享卡片 PNG",pdf:"PDF · 浏览器打印，版式还原"};C.textContent=p[o],Y.classList.toggle("is-hidden",o==="image"||o==="pdf"),S(),d&&$().set({exportFormat:o})}for(const o of s)o.addEventListener("click",()=>{const d=o.dataset.format;w(d==="markdown"||d==="html"||d==="image"||d==="pdf"?d:"markdown")});z.addEventListener("change",()=>{S(),$().set({downloadImages:z.checked})}),De().then(o=>{z.checked=o.downloadImages,w(o.exportFormat,!1),S()}).catch(()=>{});const q=je();if(q.length>0){const o=document.createElement("div");o.className="label",o.textContent="本文收录于合集",h.append(o);for(const d of q){const p=document.createElement("button");p.type="button",p.className="album";const _=document.createElement("span");_.textContent=d.title;const F=document.createElement("span");F.className="arrow",F.textContent="›",p.append(_,F),p.addEventListener("click",()=>{window.open(d.url,"_blank","noopener,noreferrer")}),h.append(p)}}let U=-1,B=!0,V;const D=[];if(u)c.forEach((o,d)=>{const p=document.createElement("button");p.type="button",p.className="item",p.style.paddingLeft=`${10+(o.level-1)*14}px`,p.textContent=o.text,p.addEventListener("click",()=>{o.element.scrollIntoView({behavior:"smooth",block:"start"}),H(d),a.onNavigate()}),b.append(p),D.push(p)});else{const o=document.createElement("p");o.className="empty",o.textContent="本文未使用标题结构，暂无目录",b.append(o)}function H(o){if(o!==U&&(U>=0&&D[U]?.classList.remove("active"),U=o,U>=0)){const d=D[U];if(d?.classList.add("active"),a.isTocOpen()&&B&&d){const p=d.closest(".popover"),_=p.getBoundingClientRect(),F=d.getBoundingClientRect();F.bottom>_.bottom?p.scrollTop+=F.bottom-_.bottom:F.top<_.top&&(p.scrollTop-=_.top-F.top)}}}function G(){let o=-1;for(let d=0;d<c.length;d+=1){const p=c[d];if(!p)break;if(p.element.getBoundingClientRect().top<=mt)o=d;else break}H(o)}function Q(o=!1){B||(B=!0,f.inert=!1,f.classList.add("open"),f.setAttribute("aria-hidden","false"),i.classList.add("hidden"),i.setAttribute("aria-expanded","true"),o&&k.focus(),G())}function W(){B&&(B=!1,a.close(),f.inert=!0,f.classList.remove("open"),f.setAttribute("aria-hidden","true"),i.classList.remove("hidden"),i.setAttribute("aria-expanded","false"),t.activeElement&&f.contains(t.activeElement)&&i.focus())}function N(o){g.textContent=o,!B&&(m.textContent=o,m.classList.add("show"),V&&window.clearTimeout(V),V=window.setTimeout(()=>m.classList.remove("show"),5e3))}async function ne(){if(Ve())return N("正在保存，请稍候…"),Me();I.disabled=!0,A.textContent="保存中…";try{N(M==="pdf"?"正在打开打印窗口…":M==="image"?"正在生成分享图片…":z.checked?"正在下载图片并打包…":M==="html"?"正在生成 HTML…":"正在生成 Markdown…");const o=await he({surface:"reader_panel",format:M},Me,d=>d.success);return N(o.success?o.message||"已保存":o.error),await v.handleResult(o),!o.success&&"reason"in o&&o.reason==="quota_exceeded"&&(Q(!0),a.open("quota")),o}catch(o){const d=oe(o,"保存失败，请稍后重试");return N(d),R&&(a.open("quota"),R.open("manual_click")),{success:!1,error:d}}finally{I.disabled=!1,S()}}i.addEventListener("click",()=>B?W():Q(!0)),k.addEventListener("click",W),x.addEventListener("click",()=>{window.scrollTo({top:0,behavior:"smooth"})}),P.addEventListener("click",()=>{chrome.runtime.sendMessage({type:"OPEN_FEEDBACK"})}),I.addEventListener("click",()=>{ne()}),T.addEventListener("click",()=>{(async()=>{T.disabled=!0,T.textContent="正在加入…";const o=await Ye();o.success?(T.textContent=o.data?.created===!1?"✓ 已更新文章库快照":"✓ 已加入文章库",N(o.data?.created===!1?"文章库中的正文快照已更新":"已加入本地文章库，可按公众号、日期和归档合集整理")):(T.textContent="☆ 加入本地文章库",N(o.error),o.reason==="not-licensed"&&R&&(j("pro_feature_blocked",{surface:"reader_panel",trigger:"library_locked",errorReason:"not_licensed"}),R.open("library_locked"),a.open("quota"))),T.disabled=!1})().catch(o=>{T.disabled=!1,T.textContent="☆ 加入本地文章库",N(oe(o,"加入文章库失败，请刷新页面后再试"))})}),O.addEventListener("click",()=>{(async()=>{const o={type:"OPEN_LIBRARY"},d=await chrome.runtime.sendMessage(o);d?.success||N(d?.error??"文章库暂时无法打开，请刷新页面后重试")})().catch(o=>{N(oe(o,"文章库暂时无法打开，请刷新页面后重试"))})}),window.addEventListener("keydown",o=>{o.key==="Escape"&&B&&(a.isActive()?a.close(!0):W())});let X=!1;return window.addEventListener("scroll",()=>{X||(X=!0,window.requestAnimationFrame(()=>{X=!1,B&&G()}))},{passive:!0}),R.badge.style.margin="0 14px 8px",a.more.append(R.badge),ft(L),e.onQuickSave?.(()=>ne()),G(),document.documentElement.append(y),{open:()=>Q(!0)}}let ve,de,pe,we;function be(e,n){return e.then(n).catch(r=>n({success:!1,error:oe(r,"扩展操作失败，请刷新页面后再试")})),!0}async function _e(e){const n=await chrome.runtime.sendMessage(e);if(!n)throw new Error("扩展没有返回文章库结果，请重新加载扩展后再试");if(!n.success)throw new Error(n.error);return n.data}chrome.runtime.onMessage.addListener((e,n,r)=>e.type==="OPEN_DRAWER"?we?(we.open(),r({success:!0}),!1):(r({success:!1,error:"当前页面没有存档面板"}),!1):e.type==="QUICK_SAVE"?ve?be(ve(),r):(r({success:!1,error:"请打开一篇微信公众号文章后再试"}),!1):e.type==="DOWNLOAD_ALBUM"?de?be(de(),r):(r({success:!1,error:"请打开微信公众号合集页面后再试"}),!1):e.type==="RESTART_ALBUM"?pe?be(pe(),r):(r({success:!1,error:"请打开微信公众号合集页面后再试"}),!1):!1);const re=e=>new Promise(n=>window.setTimeout(n,e));async function Le(e,n=Number.POSITIVE_INFINITY){const r=new URL(location.href).searchParams.get("__biz");if(!r)throw new Error("合集链接缺少公众号标识");const c=[],l=new Set;let u=!0;for(;u&&c.length<n;){const y=c.at(-1),t=Math.min(10,n-c.length),i=await fetch(Re(r,e.id,y,t,e.ascending),{credentials:"omit",referrerPolicy:"no-referrer"});if(le(i.status),!i.ok)throw new Error(`合集列表读取失败（HTTP ${i.status}）`);const f=await i.text();le(i.status,f);const k=Ne(JSON.parse(f));let x=0;for(const P of k.articles){const I=qe(P);if(!l.has(I)&&(l.add(I),c.push(P),x+=1,c.length>=n))break}if(u=k.continueFlag,u&&x===0)throw new Error("合集分页没有返回新文章，请稍后重试");await re(250)}if(!Oe(c,e.ascending))throw new Error("微信返回的合集序号不连续，请刷新页面后重试");return c}async function xe(e){for(let n=0;n<3;n+=1)try{const r=await fetch(e.url,{credentials:"omit",referrerPolicy:"no-referrer"});if(le(r.status),!r.ok){if(r.status>=500&&n<2){await re(500*2**n);continue}throw new Error(`文章读取失败（HTTP ${r.status}）：${e.title}`)}const c=await r.text();le(r.status,c);const l=new DOMParser().parseFromString(c,"text/html"),u=We(l,e.url);return u.publishTime||(u.publishTime=Fe(e.createTime)),await re(500),{article:u,markdown:Ue(u)}}catch(r){if(r instanceof ye||r instanceof Error&&r.message.startsWith("文章读取失败")||n>=2)throw r;await re(500*2**n)}throw new Error(`文章读取失败：${e.title}`)}function bt(){if(!Te()||document.querySelector("#wechat-to-markdown-album-entry")||!Se)return;let e;try{e=ae()}catch{return}const n=document.createElement("div");n.id="wechat-to-markdown-album-entry";const r=n.attachShadow({mode:"closed"});r.innerHTML=`<style>
    :host{all:initial}.wrap{position:fixed;right:22px;bottom:148px;z-index:2147483647;display:grid;justify-items:end;gap:9px;width:min(310px,calc(100vw - 28px));font-family:-apple-system,BlinkMacSystemFont,"PingFang SC",sans-serif}
    .card{width:100%;padding:13px;border:1px solid #d3e4da;border-radius:14px;background:rgba(253,255,253,.98);box-shadow:0 14px 38px rgba(19,58,36,.18)}
    .head{display:flex;align-items:center;gap:9px;margin:0 1px 10px}.mark{display:grid;flex:none;width:30px;height:30px;place-items:center;border-radius:9px;color:#087f4e;background:#e5f3ea}.mark svg{width:18px;height:18px;fill:none;stroke:currentColor;stroke-width:1.7;stroke-linecap:round;stroke-linejoin:round}.title{display:grid;gap:2px;min-width:0}.title strong{color:#183b29;font-size:13px;line-height:1.2}.title small{color:#77847c;font-size:10px;line-height:1.2;letter-spacing:.05em}
    button{border:0;font:700 13px/1.2 inherit;cursor:pointer}button:focus-visible{outline:3px solid #a6dbc0;outline-offset:2px}button:disabled{cursor:wait;opacity:.55}button[hidden]{display:none}
    #download{width:100%;min-height:42px;border-radius:10px;padding:11px 14px;color:#fff;background:#087f4e;box-shadow:0 7px 18px rgba(5,67,40,.22)}#download:hover{background:#076f45}
    #library{width:100%;min-height:38px;margin-top:8px;border:1px solid #9bcdb2;border-radius:10px;padding:9px 12px;color:#087f4e;background:#f0f8f3}#library:hover{background:#e5f3ea}
    .secondary-actions{display:flex;align-items:center;justify-content:flex-end;gap:7px;margin-top:8px}.secondary-actions:empty{display:none}button.secondary{min-height:32px;border:1px solid #d7e5dc;border-radius:8px;padding:7px 10px;color:#597065;background:#f5f8f6;box-shadow:none;font-size:11px}button.secondary:hover{color:#087f4e;background:#ebf4ee}
    .note{display:none;margin:0 0 10px;padding:9px 10px;border-left:3px solid #53a477;border-radius:4px 8px 8px 4px;color:#3f5147;background:#f2f7f4;font-size:11px;line-height:1.55}.note.show{display:block}
    @media (prefers-reduced-motion:no-preference){#download,.secondary{transition:background .16s ease,color .16s ease,transform .16s ease}#download:active{transform:translateY(1px)}}
  </style><div class="wrap"><section class="card" aria-label="合集归档"><header class="head"><span class="mark"><svg viewBox="0 0 24 24" aria-hidden="true"><path d="M5 5.5h10.5L19 9v10H5z"/><path d="M15.5 5.5V9H19M8 13h8m-8 3h6"/></svg></span><span class="title"><strong>合集归档</strong><small>LOCAL ARCHIVE</small></span></header><div class="note" role="status" aria-live="polite"></div><button id="download" type="button">下载合集</button><button id="library" type="button" hidden>加入文章库</button><div class="secondary-actions"><button id="restart" class="secondary" type="button">重新导出全部</button></div></section></div>`;const c=r.querySelector("#download"),l=r.querySelector("#library"),u=r.querySelector("#restart"),y=r.querySelector(".note"),t=s=>{y.textContent=s,y.classList.add("show")};let i=0,f;if(Se){f=Ge({surface:"album_panel",onLicenseTransition:async(m,b)=>{if(b==="activated"&&m.licensed){if(O.isRunning()){t("完整版已激活 · 合集权益已同步，当前任务完成后将自动刷新操作状态");return}await P(!1,!0),t("完整版已激活 · 合集权益已同步，可下载完整合集并在后续只归档新增文章")}else if(b==="deactivated"&&!m.licensed){if(O.isRunning()){t("完整版状态已更新 · 当前任务结束后将自动切换为免费版");return}await P(!1,!1),t("完整版状态已更新 · 当前已切换为免费版，请重新激活后继续完整合集操作")}}}),f.trigger.className="secondary action license-trigger";const s=r.querySelector(".wrap"),g=r.querySelector(".card");s.prepend(f.badge),s.querySelector(".secondary-actions").append(f.trigger),g.append(f.panel)}let k=!1;const x=()=>Math.max(e.articleCount,e.articles.length);async function P(s,g){const m=++i,b=g??await ie().catch(()=>!1),h=b?{}:await $().get(se),L=!b&&Ce(h[se]);if(m!==i)return{licensed:b,trialConsumed:L};const a=x(),v=tt({primaryButton:c,libraryButton:l,restartButton:u},a,b,L);return v.mode==="licensed"?s&&t(`检测到 ${a} 篇 · 完整版只导出上次归档后新增的文章，省去逐篇检查`):v.mode==="trial-consumed"?s&&t(`已免费保存 ${v.trialCount} 篇 · 解锁后可继续归档剩余 ${v.remaining} 篇，并自动增量更新`):s&&(j("album_trial_shown",{surface:"album_panel",articleCountBucket:K(a),licensed:b,trialConsumed:L}),t(`检测到 ${a} 篇 · 本机可免费试用前 ${v.trialCount} 篇；解锁后可一次完整归档`)),{licensed:b,trialConsumed:L}}const I=async()=>{for(;k;)await re(300)};let A,T=!1;const O=Be(async()=>{const s=T;if(T=!1,!s&&!await ge(x()))return{success:!1,error:"已取消批量处理"};const g=A??await ie();A=void 0;const m=g?{}:await $().get(se),b=!g;if(b&&Ce(m[se]))return j("album_trial_blocked_used",{surface:"album_panel",trigger:"trial_used",articleCountBucket:K(x()),trialConsumed:!0}),j("pro_feature_blocked",{surface:"album_panel",trigger:"trial_used",errorReason:"not_licensed"}),f&&f.open("trial_used"),{success:!1,error:"本机免费试用已使用，解锁后可导出完整合集"};c.textContent="暂停下载",l.disabled=!0,u.disabled=!0;let h="",L="",a=e,v=a.articleCount,E=Math.ceil(a.articleCount/ee),M=!1;try{a=ae(),e=a,h=me(a.id,a.ascending),L=Ee(a.id,a.ascending);const R={type:"ENSURE_ALBUM_DIRECTORY",album:{id:a.id,title:a.title,accountName:a.accountName,articleCount:x()}},S=await chrome.runtime.sendMessage(R);if(!S.success)throw new Error(S.error);if(!S.ready)return t(S.message),{success:!0,message:S.message};t(b?`检测到 ${x()} 篇 · 正在读取免费试用的前 ${Math.min(te,x())} 篇…`:`检测到 ${x()} 篇 · 正在检查上次归档后新增的文章…`);const w=await Le(a,b?te:Number.POSITIVE_INFINITY);if(w.length===0)throw new Error("合集列表暂时为空，请刷新页面后重试");const q={id:a.id,title:a.title,accountName:a.accountName,articleCount:b?x():w.length};if(b){j("album_trial_started",{surface:"album_panel",articleCountBucket:K(x()),trialConsumed:!1});const p=[];for(const[ue,J]of w.entries())await I(),t(`免费试用 · 正在读取第 ${ue+1}/${w.length} 篇（合集共 ${x()} 篇）`),p.push({...await xe(J),position:J.position});t(`正在打包 ${w.length} 篇试用文章，并写入所选目录…`);const _={type:"EXPORT_ALBUM_BATCH",album:q,articles:p,batchNumber:1,totalBatches:1,trial:!0},F=await chrome.runtime.sendMessage(_);if(!F.success)throw new Error(F.error);const Z=Math.max(x()-w.length,0);return t(`免费试用已保存 ${w.length} 篇 · 解锁后可继续归档剩余 ${Z} 篇，并自动增量更新`),j("album_trial_completed",{surface:"album_panel",trigger:"post_success",articleCountBucket:K(x()),trialConsumed:!0}),Z>0&&f&&f.open("post_success"),{success:!0,message:`免费试用已保存 ${w.length} 篇`}}const U=await $().get([h,L]),B=U[h],V=B?.albumId===a.id&&B.status!=="completed",{pending:D,completedIdentities:H}=$e(w,U[L],V?B.completedArticleIds:void 0),G=w.map(p=>({title:p.title,sourceUrl:p.url,publishTime:Fe(p.createTime),position:p.position})),Q=V&&H.size>0&&D.length===0;if(D.length===0&&!Q)return await $().set({[L]:Ae(w),[h]:{albumId:a.id,title:a.title,completedArticles:0,totalArticles:0,completedBatches:0,totalBatches:0,status:"completed"}}),t(`已是最新 · 当前 ${w.length} 篇均已归档，没有创建重复文件`),{success:!0,message:"合集已是最新，没有新增文章"};v=H.size+D.length;const W=V&&H.size>0&&Number.isInteger(B.completedBatches)&&B.completedBatches>=0?B.completedBatches:0,N=Math.ceil(D.length/ee);E=W+N,await $().set({[h]:{albumId:a.id,title:a.title,completedArticles:H.size,totalArticles:v,completedBatches:W,totalBatches:E,completedArticleIds:[...H],status:"running"}}),M=!0;for(let p=0;p<N;p+=1){const _=W+p;await I();const F=D.slice(p*ee,(p+1)*ee),Z=[];for(const[fe,ke]of F.entries())await I(),t(`待续传 ${D.length} 篇 · 第 ${_+1}/${E} 卷 · 正在读取第 ${p*ee+fe+1} 篇`),Z.push({...await xe(ke),position:ke.position});t(`正在打包第 ${_+1}/${E} 卷，并写入所选目录…`);const ue={type:"EXPORT_ALBUM_BATCH",album:q,articles:Z,batchNumber:_+1,totalBatches:E},J=await chrome.runtime.sendMessage(ue);if(!J.success)throw new Error(J.error);for(const fe of F)H.add(qe(fe));const Ie={albumId:a.id,title:a.title,completedArticles:H.size,totalArticles:v,completedBatches:_+1,totalBatches:E,completedArticleIds:[...H],status:"running"};await $().set({[h]:Ie})}const ne={type:"EXPORT_ALBUM_INDEX",album:q,articles:G},X=await chrome.runtime.sendMessage(ne);if(!X.success)throw new Error(X.error);await $().set({[L]:Ae(w)});const o={albumId:a.id,title:a.title,completedArticles:v,totalArticles:v,completedBatches:E,totalBatches:E,status:"completed"};await $().set({[h]:o}),t(`增量归档完成 · 新增 ${v} 篇 · 当前索引共 ${w.length} 篇`);const d={type:"NOTIFY_ALBUM_COMPLETE",album:q,exportedArticles:v,totalArticles:w.length};return await chrome.runtime.sendMessage(d).catch(()=>{}),{success:!0,message:`合集新增 ${v} 篇已归档`}}catch(R){const S=R instanceof Error?R.message:"合集下载失败，请稍后继续";if(b)return t(`${S}；下载未完成，免费试用资格不会消耗，可再次重试`),{success:!1,error:S};if(!M)return t(`${S}；再次点击会重新检查新增文章`),{success:!1,error:S};t(`${S}；再次点击可从已完成分卷继续`);const q=(h?await $().get(h):{})[h];return h&&await $().set({[h]:{albumId:a.id,title:a.title,completedArticles:q?.completedArticles||0,totalArticles:q?.totalArticles||v,completedBatches:q?.completedBatches||0,totalBatches:q?.totalBatches||E,completedArticleIds:q?.completedArticleIds,status:"failed",error:S}}),{success:!1,error:S}}finally{k=!1,u.disabled=!1,l.disabled=!1,P(!1).catch(()=>{c.textContent="下载合集"})}}),z=Be(async()=>{if(!await ge(x()))return{success:!1,error:"已取消批量处理"};const s="加入文章库";l.disabled=!0,l.textContent="正在加入…",c.disabled=!0,u.disabled=!0;try{if(!await ie())return f&&f.open("batch_export"),t("整合集加入文章库是完整版能力，请先解锁"),{success:!1,error:"整合集加入文章库需要解锁完整版"};const g=ae();t(`正在读取“${g.title}”的完整文章列表…`);const m=await Le(g);if(m.length===0)throw new Error("合集列表暂时为空，请刷新页面后重试");const b={id:g.id,title:g.title,accountName:g.accountName,articleCount:m.length},h=await _e({type:"PREPARE_ALBUM_LIBRARY",album:b}),L=new Set(h.linkedArticleIds),a=m.filter(M=>!L.has(Ke(M.url)));if(a.length===0)return t(`“${h.collection.name}”已包含全部 ${m.length} 篇文章，正在打开文章库…`),await chrome.runtime.sendMessage({type:"OPEN_LIBRARY",collectionId:h.collection.id}),{success:!0,message:"合集已全部加入文章库"};let v=h.collection,E=0;for(let M=0;M<a.length;M+=10){const R=a.slice(M,M+10);let S=0;const w=[];for(const U of R){const B=await xe(U);S+=1,t(`正在读取“${v.name}” · ${E+S}/${a.length} 篇`),w.push(B)}const q=await _e({type:"ARCHIVE_ALBUM_LIBRARY_BATCH",album:b,articles:w});v=q.collection,E+=q.articleIds.length}return t(`已加入“${v.name}” · 新增 ${E} 篇 · 共 ${m.length} 篇，正在打开文章库…`),await chrome.runtime.sendMessage({type:"OPEN_LIBRARY",collectionId:v.id}),{success:!0,message:`已把 ${E} 篇文章加入文章库`}}catch(g){const m=g instanceof Error?g.message:"合集加入文章库失败";return t(`${m}；再次点击会跳过已成功入库的文章并继续`),{success:!1,error:m}}finally{l.disabled=!1,l.textContent=s,c.disabled=!1,u.disabled=!1}});de=async()=>{if(O.isRunning())return k=!k,c.textContent=k?"继续下载":"暂停下载",t(k?"任务已暂停，点击继续下载":"任务已继续"),{success:!0,message:k?"合集任务已暂停":"合集任务已继续"};const s=await P(!1);if(!s.licensed&&s.trialConsumed){const g=Math.max(x()-Math.min(te,x()),0);return t(`已免费保存 ${Math.min(te,x())} 篇 · 解锁后可继续归档剩余 ${g} 篇，并自动增量更新`),j("album_trial_blocked_used",{surface:"album_panel",trigger:"trial_used",articleCountBucket:K(x()),trialConsumed:!0}),j("pro_feature_blocked",{surface:"album_panel",trigger:"trial_used",errorReason:"not_licensed"}),f&&f.open("trial_used"),{success:!1,error:"本机免费试用已使用，解锁后可导出完整合集"}}return k=!1,A=s.licensed,he({surface:"album_panel",trigger:"batch_export",format:"zip",articleCountBucket:K(x())},()=>O.run(),g=>g.success)},pe=async()=>{if(O.isRunning())return{success:!1,error:"当前任务仍在运行，请等待本卷完成或取消保存后再完整重新导出"};if(!await ie({forceRevalidate:!0}))return t("完整重新导出是完整版能力；可先使用一次免费试用"),j("pro_feature_blocked",{surface:"album_panel",trigger:"batch_export",errorReason:"not_licensed"}),f&&f.open("batch_export"),{success:!1,error:"完整重新导出需要解锁完整版"};const s=ae();return await ge(s.articleCount)?(await $().remove([me(s.id,s.ascending),Ee(s.id,s.ascending)]),t("当前排序方向的断点和增量历史已清零，正在完整重新导出…"),A=!0,T=!0,he({surface:"album_panel",trigger:"batch_export",format:"zip",articleCountBucket:K(x())},()=>O.run(),g=>g.success)):{success:!1,error:"已取消批量处理，断点保持不变"}};const Y=s=>{s&&s().catch(g=>t(oe(g)))};c.addEventListener("click",()=>{Y(de)}),l.addEventListener("click",()=>{Y(()=>z.run())}),u.addEventListener("click",()=>{Y(pe)}),document.documentElement.append(n);const C=me(e.id,e.ascending);try{P(!0).then(async({licensed:s})=>{if(!s)return;const m=(await $().get(C))[C];(m?.status==="running"||m?.status==="failed")&&t(`上次新增归档完成 ${m.completedArticles}/${m.totalArticles} 篇，点击继续`)}).catch(()=>t("扩展已更新，请刷新当前页面后再试"))}catch(s){t(s instanceof Error?s.message:"扩展已更新，请刷新当前页面后再试")}}bt();we=gt({onQuickSave:e=>{ve=e}});
