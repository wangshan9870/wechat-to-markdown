import{j as Fe,e as he,k as ne,l as de,A as ae,i as ye,f as Y,m as we,n as Z,s as Ie,u as Ae,p as ve,q as Me,t as Pe,v as Te,w as Re,x as qe,a as $e}from"./official-site-B91Gl9XI.js";import{i as Ne,e as Ue,a as C,r as Oe,b as He,c as ze,d as ee,f as _e,g as De,s as ke,t as me,h as J,j as U,k as j,l as Se,m as Ye}from"./license-panel-DKNvind2.js";import{C as je,r as oe,v as Ve,f as We,I as Ke,g as Xe}from"./release-CJxG1UBU.js";const Ge=2;function Be(t){return t.replace(/\s+/g," ").trim()}function Qe(t){const a=[];let n="";for(const c of t){const l=Be(c.text);if(!l||l===n)continue;const h=Math.min(6,Math.max(1,Math.round(c.level)||1));a.push({level:h,text:l}),n=l}return a}function Ze(t){return Qe(t).length>=Ge}const Je=`
  :host{all:initial;display:block}
  *{box-sizing:border-box}
  .notice{position:relative;margin:0;padding:12px 13px 13px;border:1px solid #cfe1d5;border-left:4px solid #087f4e;border-radius:10px;color:#33443a;background:#f7fbf8;box-shadow:0 5px 15px rgba(27,48,35,.08);font-family:-apple-system,BlinkMacSystemFont,"PingFang SC",sans-serif;animation:notice-in .18s ease-out}
  .topline{display:flex;align-items:center;justify-content:space-between;gap:10px;margin:0 28px 6px 0}
  .eyebrow{margin:0;color:#087f4e;font:700 10px/1 ui-monospace,SFMono-Regular,Menlo,monospace;letter-spacing:.06em}
  .version{flex:none;padding:3px 6px;border-radius:999px;color:#087f4e;background:#e3f2e8;font:700 10px/1 ui-monospace,SFMono-Regular,Menlo,monospace}
  h3{margin:0;color:#16211b;font:700 13px/1.45 -apple-system,BlinkMacSystemFont,"PingFang SC",sans-serif}
  .summary{margin:5px 0 0;color:#4f6056;font:400 12px/1.55 -apple-system,BlinkMacSystemFont,"PingFang SC",sans-serif}
  .hint{margin:7px 0 0;color:#728078;font:400 10px/1.5 -apple-system,BlinkMacSystemFont,"PingFang SC",sans-serif}
  .actions{display:flex;flex-wrap:wrap;align-items:center;gap:7px;margin-top:10px}
  a,.ignore{display:inline-flex;align-items:center;justify-content:center;min-height:30px;border-radius:8px;padding:7px 10px;font:600 11px/1 -apple-system,BlinkMacSystemFont,"PingFang SC",sans-serif;text-decoration:none;cursor:pointer}
  .primary{border:1px solid #087f4e;color:#fff;background:#087f4e}
  .primary:hover{background:#066d43}
  .secondary{border:1px solid #cfe1d5;color:#087f4e;background:#fff}
  .secondary:hover{background:#eef6f1}
  .ignore{border:0;color:#607068;background:transparent}
  .ignore:hover{color:#24352b;background:#e9f2ec}
  .ignore:disabled{opacity:.55;cursor:wait}
  .dismiss{position:absolute;top:7px;right:7px;display:grid;width:28px;height:28px;place-items:center;border:0;border-radius:7px;color:#607068;background:transparent;font:700 15px/1 -apple-system,BlinkMacSystemFont,"PingFang SC",sans-serif;cursor:pointer}
  .dismiss:hover{color:#16211b;background:#e9f2ec}
  a:focus-visible,button:focus-visible{outline:3px solid #a6dbc0;outline-offset:2px}
  .feedback{min-height:14px;margin:7px 0 0;color:#a33b32;font:400 10px/1.4 -apple-system,BlinkMacSystemFont,"PingFang SC",sans-serif}
  @keyframes notice-in{from{opacity:0;transform:translateY(-3px)}to{opacity:1;transform:translateY(0)}}
  @media (prefers-reduced-motion:reduce){.notice{animation:none}}
`;function et(t){return typeof t=="object"&&t!==null&&!Array.isArray(t)}function tt(t){const a=t.channel==="store",n=a?t.storeUrl:t.offlineDownloadUrl,c=t.guideUrl&&t.guideUrl!==n?t.guideUrl:void 0;return{eyebrow:t.noticeLevel==="required"?"需要更新":"新版可用",primaryLabel:a?"打开扩展商店":"下载新版 ZIP",primaryUrl:n,...c?{secondaryLabel:"查看更新步骤",secondaryUrl:c}:{},channelHint:a?"商店版通常会自动更新；打开商店可立即查看新版本。":"离线版需手动更新：解压覆盖原目录，再到扩展管理页点击“重新加载”。",canIgnore:t.noticeLevel!=="required"}}async function rt(t){try{const a=await chrome.runtime.sendMessage({type:Ke,version:t});return a?.ok===!0&&a.ignored===!0}catch{return!1}}function nt(t){if(!et(t))return;const a=chrome.runtime.getManifest().version;if(t.currentVersion!==a||t.channel!==oe.channel)return;const n=Ve(t,{channel:oe.channel,trustedOrigins:oe.trustedOrigins});return n?We(n,a,oe.channel):void 0}async function at(){try{const t=await chrome.runtime.sendMessage({type:je});return t?.ok!==!0?void 0:nt(t.update)}catch{return}}function ot(t,a={}){const n=tt(t),c=document.createElement("div");c.dataset.wechatToMarkdownUpdate=t.latestVersion;const l=c.attachShadow({mode:"open"});l.innerHTML=`
    <style>${Je}</style>
    <section class="notice" role="region" aria-live="polite" aria-labelledby="wtm-update-title">
      <button class="dismiss" type="button" aria-label="暂时关闭更新提示">×</button>
      <div class="topline">
        <p class="eyebrow"></p>
        <span class="version"></span>
      </div>
      <h3 id="wtm-update-title"></h3>
      <p class="summary"></p>
      <p class="hint"></p>
      <div class="actions"></div>
      <p class="feedback" role="status" aria-live="polite"></p>
    </section>`,l.querySelector(".eyebrow").textContent=n.eyebrow,l.querySelector(".version").textContent=`v${t.latestVersion}`,l.querySelector("h3").textContent=t.title,l.querySelector(".summary").textContent=t.summary,l.querySelector(".hint").textContent=n.channelHint;const h=l.querySelector(".actions"),F=l.querySelector(".feedback");if(n.primaryUrl){const o=document.createElement("a");o.className="primary",o.href=n.primaryUrl,o.target="_blank",o.rel="noopener noreferrer",o.textContent=n.primaryLabel,h.append(o)}if(n.secondaryUrl&&n.secondaryLabel){const o=document.createElement("a");o.className="secondary",o.href=n.secondaryUrl,o.target="_blank",o.rel="noopener noreferrer",o.textContent=n.secondaryLabel,h.append(o)}const r=()=>{c.remove(),a.onDismiss?.()};if(l.querySelector(".dismiss").addEventListener("click",r),n.canIgnore){const o=document.createElement("button");o.type="button",o.className="ignore",o.textContent="忽略此版本",o.addEventListener("click",()=>{(async()=>(o.disabled=!0,F.textContent="",await(a.onIgnore??rt)(t.latestVersion)?r():(o.disabled=!1,F.textContent="暂时无法保存此设置，请稍后再试。")))()}),h.append(o)}return{element:c,focus:()=>l.querySelector(".primary, .secondary, .dismiss")?.focus(),remove:r}}async function st(t){const a=await at();if(!a)return;const n=ot(a);return t.appendChild(n.element),n}const it=90,pe="paywall:first-success-shown:v1";function ct(t={}){if(!Ne()||document.querySelector("#wechat-to-markdown-reader-entry"))return;const a=document.querySelector("#js_content");if(!a)return;const n=[...a.querySelectorAll("h1, h2, h3, h4, h5, h6")],c=[];let l="";for(const e of n){const s=Be(e.textContent||"");!s||s===l||(l=s,c.push({level:Math.min(6,Math.max(1,Math.round(Number(e.tagName.slice(1)))||1)),text:s,element:e}))}const h=Ze(n.map(e=>({level:Number(e.tagName.slice(1)),text:e.textContent||""}))),F=document.createElement("div");F.id="wechat-to-markdown-reader-entry";const r=F.attachShadow({mode:"closed"});r.innerHTML=`
    <style>
      :host { all: initial; }
      * { box-sizing: border-box; }
      button { font-family: inherit; }
      .trigger {
        position: fixed; right: 30px; top: 50%; transform: translateY(-50%);
        z-index: 2147483646; display: grid; place-items: center;
        width: 30px; height: 56px; border: 0; border-radius: 12px;
        color: #fff; background: #087f4e; box-shadow: 0 9px 25px rgba(5, 67, 40, .27);
        font: 700 18px/1 -apple-system, BlinkMacSystemFont, "PingFang SC", sans-serif;
        cursor: pointer;
        transition: opacity .18s ease, transform .18s ease;
      }
      .trigger:hover { background: #066d43; }
      .trigger:focus-visible { outline: 3px solid #a6dbc0; outline-offset: 3px; }
      .trigger.hidden { opacity: 0; pointer-events: none; }
      .drawer {
        position: fixed; top: 72px; bottom: 20px; right: 30px; height: auto; width: 280px; max-width: 85vw;
        z-index: 2147483647; display: flex; flex-direction: column;
        color: #24352b; background: #fbfdfb; border-radius: 14px;
        box-shadow: 0 8px 30px rgba(27, 48, 35, .18);
        font-family: -apple-system, BlinkMacSystemFont, "PingFang SC", sans-serif;
        transform: translateX(calc(100% + 34px)); transition: transform .22s ease;
      }
      .drawer.open { transform: translateX(0); }
      .header { display: flex; align-items: center; justify-content: space-between; gap: 10px; padding: 14px 14px 12px; border-bottom: 1px solid #e3ece6; }
      .brand { display: flex; align-items: center; gap: 10px; min-width: 0; }
      .mark { display: grid; flex: none; width: 34px; height: 34px; place-items: center; border-radius: 10px 4px 10px 4px; color: #fff; background: #087f4e; box-shadow: 0 6px 14px rgba(8, 127, 78, .2); font: 400 18px/1 STSong, SimSun, serif; }
      .eyebrow { margin: 0 0 2px; color: #77847c; font: 600 8px/1 ui-monospace, monospace; letter-spacing: .14em; }
      .brand h2 { margin: 0; color: #16211b; font: 700 15px/1.2 -apple-system, BlinkMacSystemFont, "PingFang SC", sans-serif; letter-spacing: .03em; }
      .close { display: grid; flex: none; width: 30px; height: 30px; place-items: center; border: 0; border-radius: 8px; color: #607068; background: transparent; font: 700 15px/1 -apple-system, BlinkMacSystemFont, "PingFang SC", sans-serif; cursor: pointer; }
      .close:hover { background: #eef4f0; }
      .close:focus-visible { outline: 3px solid #a6dbc0; outline-offset: 1px; }
      .archive { padding: 14px 14px 12px; border-bottom: 1px solid #e3ece6; }
      .status { display: flex; align-items: center; gap: 7px; margin: 0 0 10px; color: #087f4e; font: 600 11px/1 -apple-system, BlinkMacSystemFont, "PingFang SC", sans-serif; }
      .status::before { content: ""; width: 6px; height: 6px; border-radius: 50%; background: #08a864; box-shadow: 0 0 0 4px #def4e8; }
      .article-title { margin: 0; color: #16211b; font: 700 16px/1.5 STSong, SimSun, serif; display: -webkit-box; -webkit-line-clamp: 3; -webkit-box-orient: vertical; overflow: hidden; }
      .account { margin: 6px 0 12px; color: #728078; font: 400 12px/1.4 -apple-system, BlinkMacSystemFont, "PingFang SC", sans-serif; }
      .archive-option { position: relative; display: flex; align-items: center; justify-content: space-between; gap: 12px; margin-bottom: 10px; padding: 10px 12px; border: 1px solid #dce6df; border-radius: 10px; background: #f4f8f5; cursor: pointer; }
      .archive-option strong, .archive-option small { display: block; }
      .archive-option strong { color: #24352b; font: 600 12px/1.3 -apple-system, BlinkMacSystemFont, "PingFang SC", sans-serif; }
      .archive-option small { margin-top: 3px; color: #77847c; font: 400 10px/1.4 -apple-system, BlinkMacSystemFont, "PingFang SC", sans-serif; }
      .archive-option input { position: absolute; width: 1px; height: 1px; opacity: 0; }
      .switch { position: relative; flex: 0 0 36px; width: 36px; height: 20px; border-radius: 999px; background: #b9c4bd; transition: background .16s ease; }
      .switch::after { content: ""; position: absolute; left: 3px; top: 3px; width: 14px; height: 14px; border-radius: 50%; background: #fff; box-shadow: 0 1px 3px rgba(0, 0, 0, .2); transition: transform .16s ease; }
      .archive-option input:checked + .switch { background: #087f4e; }
      .archive-option input:checked + .switch::after { transform: translateX(16px); }
      .archive-option input:focus-visible + .switch { outline: 3px solid #a6dbc0; outline-offset: 2px; }
      .segmented { display: flex; flex: none; border: 1px solid #cfdcd3; border-radius: 999px; background: #fff; overflow: hidden; }
      .option-stack { flex-direction: column; align-items: stretch; }
      .option-stack .segmented { margin-top: 8px; width: 100%; }
      .segment { flex: 1 1 0; min-width: 0; border: 0; padding: 6px 2px; color: #4a5950; background: transparent; font: 600 10px/1 -apple-system, BlinkMacSystemFont, "PingFang SC", sans-serif; text-align: center; cursor: pointer; transition: background .16s ease, color .16s ease; }
      .segment + .segment { border-left: 1px solid #e3ece6; }
      .segment:hover { background: #f1f7f3; }
      .segment.active { color: #fff; background: #087f4e; }
      .segment:focus-visible { outline: 3px solid #a6dbc0; outline-offset: -1px; }
      .archive-option.is-hidden { display: none; }
      .save-archive { display: flex; width: 100%; align-items: center; justify-content: space-between; border: 0; border-radius: 10px; padding: 12px 14px; color: #fff; background: #087f4e; font: 600 14px/1 -apple-system, BlinkMacSystemFont, "PingFang SC", sans-serif; cursor: pointer; transition: background .16s ease; }
      .save-archive:hover { background: #066d43; }
      .save-archive:focus-visible { outline: 3px solid #a6dbc0; outline-offset: 2px; }
      .save-archive:disabled { opacity: .62; cursor: wait; }
      .library-actions { display: grid; grid-template-columns: 1fr auto; gap: 8px; margin-top: 8px; }
      .library-actions[hidden] { display: none; }
      .archive-library, .open-library { min-height: 38px; border: 1px solid #b9d5c4; border-radius: 9px; color: #087f4e; background: #f7fbf8; font: 600 12px/1 -apple-system, BlinkMacSystemFont, "PingFang SC", sans-serif; cursor: pointer; }
      .archive-library { padding: 0 12px; text-align: left; }
      .open-library { width: 38px; padding: 0; font-size: 17px; }
      .archive-library:hover, .open-library:hover { background: #eaf5ed; }
      .archive-library:focus-visible, .open-library:focus-visible { outline: 3px solid #a6dbc0; outline-offset: 2px; }
      .archive-library:disabled { cursor: wait; opacity: .62; }
      .feedback { min-height: 15px; margin: 8px 0 0; color: #607068; font: 400 11px/1.4 -apple-system, BlinkMacSystemFont, "PingFang SC", sans-serif; text-align: center; }
      .export-settings { border-top: 1px solid #e3ece6; margin-top: 10px; }
      .export-settings-toggle { display: flex; align-items: center; justify-content: space-between; width: 100%; padding: 10px 14px; border: 0; background: transparent; color: #77847c; font: 600 11px/1 -apple-system, BlinkMacSystemFont, "PingFang SC", sans-serif; cursor: pointer; }
      .export-settings-toggle:hover { color: #4a5950; }
      .export-settings-toggle .chevron { transition: transform .2s ease; }
      .export-settings-toggle[aria-expanded="true"] .chevron { transform: rotate(180deg); }
      .export-settings-content { display: none; padding: 0 14px 12px; }
      .export-settings-content[aria-hidden="false"] { display: block; }
      .toc-label { padding: 10px 14px 2px; color: #77847c; font: 600 11px/1.4 -apple-system, BlinkMacSystemFont, "PingFang SC", sans-serif; }
      .list { flex: 1; overflow-y: auto; padding: 8px 8px 12px; }
      .item { display: block; width: 100%; padding: 9px 10px; border: 0; border-radius: 8px; color: #4a5950; background: transparent; font: 400 13px/1.5 -apple-system, BlinkMacSystemFont, "PingFang SC", sans-serif; text-align: left; cursor: pointer; }
      .item:hover { background: #f1f7f3; color: #24352b; }
      .item:focus-visible { outline: 3px solid #a6dbc0; outline-offset: 1px; }
      .item.active { color: #087f4e; background: #eef6f1; font-weight: 600; }
      .empty { margin: 24px 16px; padding: 18px 14px; border: 1px dashed #d8e3dc; border-radius: 10px; color: #77847c; font: 400 13px/1.6 -apple-system, BlinkMacSystemFont, "PingFang SC", sans-serif; text-align: center; }
      .albums { display: grid; gap: 6px; padding: 8px 14px 10px; border-top: 1px solid #e3ece6; }
      .albums:empty { display: none; }
      .albums .label { color: #77847c; font: 400 11px/1.4 -apple-system, BlinkMacSystemFont, "PingFang SC", sans-serif; }
      .album { display: flex; align-items: center; justify-content: space-between; gap: 8px; width: 100%; padding: 8px 10px; border: 1px solid #d8e8de; border-radius: 9px; color: #087f4e; background: #f4faf6; font: 600 12px/1.4 -apple-system, BlinkMacSystemFont, "PingFang SC", sans-serif; text-align: left; cursor: pointer; }
      .album:hover { background: #e9f5ec; }
      .album:focus-visible { outline: 3px solid #a6dbc0; outline-offset: 1px; }
      .album .arrow { flex: none; color: #5f8a72; }
      .updates { padding: 8px 14px 10px; border-top: 1px solid #e3ece6; }
      .updates:empty { display: none; }
      .footer { padding: 10px 14px 14px; border-top: 1px solid #e3ece6; }
      .action { display: flex; width: 100%; align-items: center; justify-content: center; gap: 6px; padding: 10px 12px; border: 0; border-radius: 10px; color: #087f4e; background: #eef6f1; font: 600 13px/1 -apple-system, BlinkMacSystemFont, "PingFang SC", sans-serif; cursor: pointer; }
      .action:hover { background: #e3f0e7; }
      .action:focus-visible { outline: 3px solid #a6dbc0; outline-offset: 2px; }
      .toast {
        position: fixed; right: 16px; bottom: 20px; z-index: 2147483647;
        max-width: 260px; padding: 9px 12px; border: 1px solid #dbe5de; border-radius: 9px;
        color: #33443a; background: rgba(251, 253, 251, .97); box-shadow: 0 7px 20px rgba(27, 48, 35, .12);
        font: 400 12px/1.5 -apple-system, BlinkMacSystemFont, "PingFang SC", sans-serif;
        opacity: 0; pointer-events: none; transition: opacity .16s ease;
      }
      .toast.show { opacity: 1; }
      @media (prefers-reduced-motion: reduce) { .trigger, .drawer, .toast { transition: none; } }
    </style>
    <button class="trigger hidden" type="button" aria-label="展开文章存档面板" aria-expanded="true">‹</button>
    <aside class="drawer open" aria-hidden="false">
      <header class="header">
        <div class="brand">
          <div class="mark" aria-hidden="true">文</div>
          <div>
            <p class="eyebrow">WECHAT · MARKDOWN</p>
            <h2>文章存档</h2>
          </div>
        </div>
        <button class="close" type="button" aria-label="收起面板">›</button>
      </header>
      <section class="archive" aria-label="文章存档">
        <p class="status">已识别微信公众号文章</p>
        <h3 class="article-title"></h3>
        <p class="account"></p>
        <button class="save-archive" type="button">
          <span class="save-label">保存 Markdown</span>
          <span aria-hidden="true">↓</span>
        </button>
        <div class="library-actions">
          <button class="archive-library" type="button">☆ 加入本地文章库</button>
          <button class="open-library" type="button" aria-label="打开本地文章库" title="打开本地文章库">›</button>
        </div>
        <p class="feedback" role="status" aria-live="polite"></p>
        <div class="export-settings">
          <button class="export-settings-toggle" type="button" aria-expanded="false">
            <span>导出设置</span>
            <span class="chevron" aria-hidden="true">▼</span>
          </button>
          <div class="export-settings-content" aria-hidden="true">
            <div class="archive-option option-stack">
              <span>
                <strong>导出类型</strong>
                <small class="format-desc">Markdown · 适合笔记与知识库</small>
              </span>
              <span class="segmented" role="radiogroup" aria-label="导出类型">
                <button class="segment active" type="button" data-format="markdown" role="radio" aria-checked="true">MD</button>
                <button class="segment" type="button" data-format="html" role="radio" aria-checked="false">HTML</button>
                <button class="segment" type="button" data-format="image" role="radio" aria-checked="false">图片</button>
                <button class="segment" type="button" data-format="pdf" role="radio" aria-checked="false">PDF</button>
              </span>
            </div>
            <label class="archive-option download-option">
              <span>
                <strong>下载文章图片</strong>
                <small>导出 ZIP，离线阅读不依赖网络</small>
              </span>
              <input class="download-images" type="checkbox" role="switch" />
              <span class="switch" aria-hidden="true"></span>
            </label>
          </div>
        </div>
      </section>
      <p class="toc-label">文章目录</p>
      <nav class="list" aria-label="文章目录"></nav>
      <section class="albums" aria-label="所属合集"></section>
      <section class="updates" aria-label="扩展更新"></section>
      <footer class="footer">
        <button class="action back-top" type="button">↑ 返回顶部</button>
        <button class="action community" type="button">反馈 / 交流群</button>
      </footer>
    </aside>
    <div class="toast" role="status" aria-live="polite"></div>`;const o=r.querySelector(".trigger"),y=r.querySelector(".drawer"),b=r.querySelector(".close"),O=r.querySelector(".back-top"),H=r.querySelector(".community"),z=r.querySelector(".save-archive"),T=r.querySelector(".save-label");r.querySelector(".library-actions");const R=r.querySelector(".archive-library"),V=r.querySelector(".open-library"),$=r.querySelector(".download-images"),p=r.querySelector(".download-option"),x=r.querySelector(".format-desc"),u=[...r.querySelectorAll(".segment")],w=r.querySelector(".feedback"),v=r.querySelector(".toast"),i=r.querySelector(".list"),m=r.querySelector(".albums"),S=r.querySelector(".updates"),I=r.querySelector(".export-settings-toggle"),A=r.querySelector(".export-settings-content");try{const e=Ue();r.querySelector(".article-title").textContent=e.title,r.querySelector(".account").textContent=e.accountName||"公众号文章"}catch{r.querySelector(".article-title").textContent=document.title,r.querySelector(".account").textContent="公众号文章"}let f="markdown",d;function k(){if(f==="image"){T.textContent="保存图片";return}if(f==="pdf"){T.textContent="导出 PDF";return}if($.checked){T.textContent="保存完整文章";return}T.textContent=f==="html"?"保存 HTML":"保存 Markdown"}function N(e,s=!0){f=e;for(const L of u){const q=L.dataset.format===e;L.classList.toggle("active",q),L.setAttribute("aria-checked",String(q))}const g={markdown:"Markdown · 适合笔记与知识库",html:"HTML · 保留原文排版，可直接浏览",image:"图片 · 生成一张分享卡片 PNG",pdf:"PDF · 浏览器打印，版式还原"};x.textContent=g[e],p.classList.toggle("is-hidden",e==="image"||e==="pdf"),k(),s&&C().set({exportFormat:e})}for(const e of u)e.addEventListener("click",()=>{const s=e.dataset.format;N(s==="markdown"||s==="html"||s==="image"||s==="pdf"?s:"markdown")});$.addEventListener("change",()=>{k(),C().set({downloadImages:$.checked})}),I.addEventListener("click",()=>{const e=I.getAttribute("aria-expanded")==="true";I.setAttribute("aria-expanded",String(!e)),A.setAttribute("aria-hidden",String(e))}),Oe().then(e=>{$.checked=e.downloadImages,N(e.exportFormat,!1),k()}).catch(()=>{});const P=He();if(P.length>0){const e=document.createElement("div");e.className="label",e.textContent="本文收录于合集",m.append(e);for(const s of P){const g=document.createElement("button");g.type="button",g.className="album";const L=document.createElement("span");L.textContent=s.title;const q=document.createElement("span");q.className="arrow",q.textContent="›",g.append(L,q),g.addEventListener("click",()=>{window.open(s.url,"_blank","noopener,noreferrer")}),m.append(g)}}let M=-1,E=!0,_;const W=[];if(h)c.forEach((e,s)=>{const g=document.createElement("button");g.type="button",g.className="item",g.style.paddingLeft=`${10+(e.level-1)*14}px`,g.textContent=e.text,g.addEventListener("click",()=>{e.element.scrollIntoView({behavior:"smooth",block:"start"}),te(s)}),i.append(g),W.push(g)});else{const e=document.createElement("p");e.className="empty",e.textContent="本文未使用标题结构，暂无目录",i.append(e)}function te(e){if(e!==M&&(M>=0&&W[M]?.classList.remove("active"),M=e,M>=0)){const s=W[M];s?.classList.add("active"),s?.scrollIntoView({block:"nearest"})}}function D(){let e=-1;for(let s=0;s<c.length;s+=1){const g=c[s];if(!g)break;if(g.element.getBoundingClientRect().top<=it)e=s;else break}te(e)}function K(e=!1){E||(E=!0,y.classList.add("open"),y.setAttribute("aria-hidden","false"),o.classList.add("hidden"),o.setAttribute("aria-expanded","true"),e&&b.focus(),D())}function X(){E&&(E=!1,y.classList.remove("open"),y.setAttribute("aria-hidden","true"),o.classList.remove("hidden"),o.setAttribute("aria-expanded","false"),r.activeElement&&y.contains(r.activeElement)&&o.focus())}function B(e){w.textContent=e,!E&&(v.textContent=e,v.classList.add("show"),_&&window.clearTimeout(_),_=window.setTimeout(()=>v.classList.remove("show"),5e3))}async function re(){if(De())return B("正在保存，请稍候…"),ke();z.disabled=!0,T.textContent="保存中…";try{B(f==="pdf"?"正在打开打印窗口…":f==="image"?"正在生成分享图片…":$.checked?"正在下载图片并打包…":f==="html"?"正在生成 HTML…":"正在生成 Markdown…");const e=await me({surface:"reader_panel",format:f},ke,s=>s.success);return B(e.success?e.message||"已保存":e.error),e.success&&d&&!await J().catch(()=>!1)&&((await C().get(pe).catch(()=>({})))[pe]?$.checked&&(f==="markdown"||f==="html")&&d.open("zip_download"):(await C().set({[pe]:!0}).catch(()=>{}),d.open("post_success"))),e}catch(e){const s=ee(e,"保存失败，请稍后重试");return B(s),d&&d.open("manual_click"),{success:!1,error:s}}finally{z.disabled=!1,k()}}o.addEventListener("click",()=>E?X():K(!0)),b.addEventListener("click",X),O.addEventListener("click",()=>{window.scrollTo({top:0,behavior:"smooth"})}),H.addEventListener("click",()=>{chrome.runtime.sendMessage({type:"OPEN_FEEDBACK"})}),z.addEventListener("click",()=>{re()}),R.addEventListener("click",()=>{(async()=>{R.disabled=!0,R.textContent="正在加入…";const e=await ze();e.success?(R.textContent=e.data?.created===!1?"✓ 已更新文章库快照":"✓ 已加入文章库",B(e.data?.created===!1?"文章库中的正文快照已更新":"已加入本地文章库，可按公众号、日期和归档合集整理")):(R.textContent="☆ 加入本地文章库",B(e.error),e.reason==="not-licensed"&&d&&(U("pro_feature_blocked",{surface:"reader_panel",trigger:"library_locked",errorReason:"not_licensed"}),d.open("library_locked"))),R.disabled=!1})().catch(e=>{R.disabled=!1,R.textContent="☆ 加入本地文章库",B(ee(e,"加入文章库失败，请刷新页面后再试"))})}),V.addEventListener("click",()=>{(async()=>{const e={type:"OPEN_LIBRARY"},s=await chrome.runtime.sendMessage(e);s?.success||B(s?.error??"文章库暂时无法打开，请刷新页面后重试")})().catch(e=>{B(ee(e,"文章库暂时无法打开，请刷新页面后重试"))})}),window.addEventListener("keydown",e=>{e.key==="Escape"&&E&&X()});let G=!1;window.addEventListener("scroll",()=>{G||(G=!0,window.requestAnimationFrame(()=>{G=!1,E&&D()}))},{passive:!0});{d=_e({surface:"reader_panel"}),d.trigger.className="action",d.trigger.style.marginBottom="8px",d.badge.style.margin="0 14px 8px";const e=r.querySelector(".footer");e.prepend(d.trigger),y.insertBefore(d.badge,e)}return st(S),t.onQuickSave?.(()=>re()),D(),document.documentElement.append(F),{open:()=>K(!0)}}let ge,se,ie,be;function ue(t,a){return t.then(a).catch(n=>a({success:!1,error:ee(n,"扩展操作失败，请刷新页面后再试")})),!0}async function Ce(t){const a=await chrome.runtime.sendMessage(t);if(!a)throw new Error("扩展没有返回文章库结果，请重新加载扩展后再试");if(!a.success)throw new Error(a.error);return a.data}chrome.runtime.onMessage.addListener((t,a,n)=>t.type==="OPEN_DRAWER"?be?(be.open(),n({success:!0}),!1):(n({success:!1,error:"当前页面没有存档面板"}),!1):t.type==="QUICK_SAVE"?ge?ue(ge(),n):(n({success:!1,error:"请打开一篇微信公众号文章后再试"}),!1):t.type==="DOWNLOAD_ALBUM"?se?ue(se(),n):(n({success:!1,error:"请打开微信公众号合集页面后再试"}),!1):t.type==="RESTART_ALBUM"?ie?ue(ie(),n):(n({success:!1,error:"请打开微信公众号合集页面后再试"}),!1):!1);const ce=t=>new Promise(a=>window.setTimeout(a,t));async function Ee(t,a=Number.POSITIVE_INFINITY){const n=new URL(location.href).searchParams.get("__biz");if(!n)throw new Error("合集链接缺少公众号标识");const c=[],l=new Set;let h=!0;for(;h&&c.length<a;){const F=c.at(-1),r=Math.min(10,a-c.length),o=await fetch(Te(n,t.id,F,r,t.ascending),{credentials:"omit",referrerPolicy:"no-referrer"});if(!o.ok)throw new Error(`合集列表读取失败（HTTP ${o.status}）`);const y=Re(await o.json());let b=0;for(const O of y.articles){const H=Me(O);if(!l.has(H)&&(l.add(H),c.push(O),b+=1,c.length>=a))break}if(h=y.continueFlag,h&&b===0)throw new Error("合集分页没有返回新文章，请稍后重试");await ce(250)}if(!qe(c,t.ascending))throw new Error("微信返回的合集序号不连续，请刷新页面后重试");return c}async function fe(t){for(let a=0;a<3;a+=1)try{const n=await fetch(t.url,{credentials:"omit",referrerPolicy:"no-referrer"});if(!n.ok){if((n.status===429||n.status>=500)&&a<2){await ce(500*2**a);continue}throw new Error(`文章读取失败（HTTP ${n.status}）：${t.title}`)}const c=new DOMParser().parseFromString(await n.text(),"text/html"),l=Ye(c,t.url);return l.publishTime||(l.publishTime=Ae(t.createTime)),{article:l,markdown:$e(l)}}catch(n){if(n instanceof Error&&n.message.startsWith("文章读取失败")||a>=2)throw n;await ce(500*2**a)}throw new Error(`文章读取失败：${t.title}`)}function lt(){if(!Fe()||document.querySelector("#wechat-to-markdown-album-entry")||!he)return;let t;try{t=ne()}catch{return}const a=document.createElement("div");a.id="wechat-to-markdown-album-entry";const n=a.attachShadow({mode:"closed"});n.innerHTML=`<style>
    :host{all:initial}.wrap{position:fixed;right:22px;bottom:148px;z-index:2147483647;display:grid;justify-items:end;gap:9px;width:min(310px,calc(100vw - 28px));font-family:-apple-system,BlinkMacSystemFont,"PingFang SC",sans-serif}
    .card{width:100%;padding:13px;border:1px solid #d3e4da;border-radius:14px;background:rgba(253,255,253,.98);box-shadow:0 14px 38px rgba(19,58,36,.18)}
    .head{display:flex;align-items:center;gap:9px;margin:0 1px 10px}.mark{display:grid;flex:none;width:30px;height:30px;place-items:center;border-radius:9px;color:#087f4e;background:#e5f3ea}.mark svg{width:18px;height:18px;fill:none;stroke:currentColor;stroke-width:1.7;stroke-linecap:round;stroke-linejoin:round}.title{display:grid;gap:2px;min-width:0}.title strong{color:#183b29;font-size:13px;line-height:1.2}.title small{color:#77847c;font-size:10px;line-height:1.2;letter-spacing:.05em}
    button{border:0;font:700 13px/1.2 inherit;cursor:pointer}button:focus-visible{outline:3px solid #a6dbc0;outline-offset:2px}button:disabled{cursor:wait;opacity:.55}button[hidden]{display:none}
    #download{width:100%;min-height:42px;border-radius:10px;padding:11px 14px;color:#fff;background:#087f4e;box-shadow:0 7px 18px rgba(5,67,40,.22)}#download:hover{background:#076f45}
    #library{width:100%;min-height:38px;margin-top:8px;border:1px solid #9bcdb2;border-radius:10px;padding:9px 12px;color:#087f4e;background:#f0f8f3}#library:hover{background:#e5f3ea}
    .secondary-actions{display:flex;align-items:center;justify-content:flex-end;gap:7px;margin-top:8px}.secondary-actions:empty{display:none}button.secondary{min-height:32px;border:1px solid #d7e5dc;border-radius:8px;padding:7px 10px;color:#597065;background:#f5f8f6;box-shadow:none;font-size:11px}button.secondary:hover{color:#087f4e;background:#ebf4ee}
    .note{display:none;margin:0 0 10px;padding:9px 10px;border-left:3px solid #53a477;border-radius:4px 8px 8px 4px;color:#3f5147;background:#f2f7f4;font-size:11px;line-height:1.55}.note.show{display:block}
    @media (prefers-reduced-motion:no-preference){#download,.secondary{transition:background .16s ease,color .16s ease,transform .16s ease}#download:active{transform:translateY(1px)}}
  </style><div class="wrap"><section class="card" aria-label="合集归档"><header class="head"><span class="mark"><svg viewBox="0 0 24 24" aria-hidden="true"><path d="M5 5.5h10.5L19 9v10H5z"/><path d="M15.5 5.5V9H19M8 13h8m-8 3h6"/></svg></span><span class="title"><strong>合集归档</strong><small>LOCAL ARCHIVE</small></span></header><div class="note" role="status" aria-live="polite"></div><button id="download" type="button">下载合集</button><button id="library" type="button" hidden>加入文章库</button><div class="secondary-actions"><button id="restart" class="secondary" type="button">重新导出全部</button></div></section></div>`;const c=n.querySelector("#download"),l=n.querySelector("#library"),h=n.querySelector("#restart"),F=n.querySelector(".note"),r=p=>{F.textContent=p,F.classList.add("show")};let o;if(he){o=_e({surface:"album_panel"}),o.trigger.className="secondary action license-trigger";const p=n.querySelector(".wrap");p.prepend(o.badge),p.querySelector(".secondary-actions").append(o.trigger)}let y=!1;const b=()=>Math.max(t.articleCount,t.articles.length);async function O(p,x){const u=x??await J({forceRevalidate:!0}).catch(()=>!1),w=u?{}:await C().get(ae),v=!u&&ye(w[ae]),i=b();if(h.hidden=!u,l.hidden=!u,u)c.textContent="下载新增文章",p&&r(`检测到 ${i} 篇 · 完整版只导出上次归档后新增的文章，省去逐篇检查`);else if(v){const m=Math.max(i-Math.min(Y,i),0);c.textContent=m>0?`解锁剩余 ${m} 篇`:"解锁完整版",p&&r(`已免费保存 ${Math.min(Y,i)} 篇 · 解锁后可继续归档剩余 ${m} 篇，并自动增量更新`)}else{const m=Math.min(Y,i);c.textContent=`免费试用 ${m} 篇`,p&&(U("album_trial_shown",{surface:"album_panel",articleCountBucket:j(i),licensed:u,trialConsumed:v}),r(`检测到 ${i} 篇 · 本机可免费试用前 ${m} 篇；解锁后可一次完整归档`))}return{licensed:u,trialConsumed:v}}const H=async()=>{for(;y;)await ce(300)};let z;const T=Se(async()=>{const p=z??await J({forceRevalidate:!0});z=void 0;const x=p?{}:await C().get(ae),u=!p;if(u&&ye(x[ae]))return U("album_trial_blocked_used",{surface:"album_panel",trigger:"trial_used",articleCountBucket:j(b()),trialConsumed:!0}),U("pro_feature_blocked",{surface:"album_panel",trigger:"trial_used",errorReason:"not_licensed"}),o&&o.open("trial_used"),{success:!1,error:"本机免费试用已使用，解锁后可导出完整合集"};c.textContent="暂停下载",l.disabled=!0,h.disabled=!0;let w="",v="",i=t,m=i.articleCount,S=Math.ceil(i.articleCount/Z),I=!1;try{i=ne(),t=i,w=de(i.id,i.ascending),v=we(i.id,i.ascending);const A={type:"ENSURE_ALBUM_DIRECTORY",album:{id:i.id,title:i.title,accountName:i.accountName,articleCount:b()}},f=await chrome.runtime.sendMessage(A);if(!f.success)throw new Error(f.error);if(!f.ready)return r(f.message),{success:!0,message:f.message};r(u?`检测到 ${b()} 篇 · 正在读取免费试用的前 ${Math.min(Y,b())} 篇…`:`检测到 ${b()} 篇 · 正在检查上次归档后新增的文章…`);const d=await Ee(i,u?Y:Number.POSITIVE_INFINITY);if(d.length===0)throw new Error("合集列表暂时为空，请刷新页面后重试");const k={id:i.id,title:i.title,accountName:i.accountName,articleCount:u?b():d.length};if(u){U("album_trial_started",{surface:"album_panel",articleCountBucket:j(b()),trialConsumed:!1});const e=[];for(const[q,Q]of d.entries())await H(),r(`免费试用 · 正在读取第 ${q+1}/${d.length} 篇（合集共 ${b()} 篇）`),e.push({...await fe(Q),position:Q.position});r(`正在打包 ${d.length} 篇试用文章，并写入所选目录…`);const s={type:"EXPORT_ALBUM_BATCH",album:k,articles:e,batchNumber:1,totalBatches:1,trial:!0},g=await chrome.runtime.sendMessage(s);if(!g.success)throw new Error(g.error);const L=Math.max(b()-d.length,0);return r(`免费试用已保存 ${d.length} 篇 · 解锁后可继续归档剩余 ${L} 篇，并自动增量更新`),U("album_trial_completed",{surface:"album_panel",trigger:"post_success",articleCountBucket:j(b()),trialConsumed:!0}),L>0&&o&&o.open("post_success"),{success:!0,message:`免费试用已保存 ${d.length} 篇`}}const N=await C().get([w,v]),P=N[w],M=P?.albumId===i.id&&P.status!=="completed",{pending:E,completedIdentities:_}=Ie(d,N[v],M?P.completedArticleIds:void 0),W=d.map(e=>({title:e.title,sourceUrl:e.url,publishTime:Ae(e.createTime),position:e.position})),te=M&&_.size>0&&E.length===0;if(E.length===0&&!te)return await C().set({[v]:ve(d),[w]:{albumId:i.id,title:i.title,completedArticles:0,totalArticles:0,completedBatches:0,totalBatches:0,status:"completed"}}),r(`已是最新 · 当前 ${d.length} 篇均已归档，没有创建重复文件`),{success:!0,message:"合集已是最新，没有新增文章"};m=_.size+E.length;const D=M&&_.size>0&&Number.isInteger(P.completedBatches)&&P.completedBatches>=0?P.completedBatches:0,K=Math.ceil(E.length/Z);S=D+K,await C().set({[w]:{albumId:i.id,title:i.title,completedArticles:_.size,totalArticles:m,completedBatches:D,totalBatches:S,completedArticleIds:[..._],status:"running"}}),I=!0;for(let e=0;e<K;e+=1){const s=D+e;await H();const g=E.slice(e*Z,(e+1)*Z),L=[];for(const[le,xe]of g.entries())await H(),r(`待续传 ${E.length} 篇 · 第 ${s+1}/${S} 卷 · 正在读取第 ${e*Z+le+1} 篇`),L.push({...await fe(xe),position:xe.position});r(`正在打包第 ${s+1}/${S} 卷，并写入所选目录…`);const q={type:"EXPORT_ALBUM_BATCH",album:k,articles:L,batchNumber:s+1,totalBatches:S},Q=await chrome.runtime.sendMessage(q);if(!Q.success)throw new Error(Q.error);for(const le of g)_.add(Me(le));const Le={albumId:i.id,title:i.title,completedArticles:_.size,totalArticles:m,completedBatches:s+1,totalBatches:S,completedArticleIds:[..._],status:"running"};await C().set({[w]:Le})}const X={type:"EXPORT_ALBUM_INDEX",album:k,articles:W},B=await chrome.runtime.sendMessage(X);if(!B.success)throw new Error(B.error);await C().set({[v]:ve(d)});const re={albumId:i.id,title:i.title,completedArticles:m,totalArticles:m,completedBatches:S,totalBatches:S,status:"completed"};await C().set({[w]:re}),r(`增量归档完成 · 新增 ${m} 篇 · 当前索引共 ${d.length} 篇`);const G={type:"NOTIFY_ALBUM_COMPLETE",album:k,exportedArticles:m,totalArticles:d.length};return await chrome.runtime.sendMessage(G).catch(()=>{}),{success:!0,message:`合集新增 ${m} 篇已归档`}}catch(A){const f=A instanceof Error?A.message:"合集下载失败，请稍后继续";if(u)return r(`${f}；下载未完成，免费试用资格不会消耗，可再次重试`),{success:!1,error:f};if(!I)return r(`${f}；再次点击会重新检查新增文章`),{success:!1,error:f};r(`${f}；再次点击可从已完成分卷继续`);const k=(w?await C().get(w):{})[w];return w&&await C().set({[w]:{albumId:i.id,title:i.title,completedArticles:k?.completedArticles||0,totalArticles:k?.totalArticles||m,completedBatches:k?.completedBatches||0,totalBatches:k?.totalBatches||S,completedArticleIds:k?.completedArticleIds,status:"failed",error:f}}),{success:!1,error:f}}finally{y=!1,h.disabled=!1,l.disabled=!1,O(!1).catch(()=>{c.textContent="下载合集"})}}),R=Se(async()=>{const p="加入文章库";l.disabled=!0,l.textContent="正在加入…",c.disabled=!0,h.disabled=!0;try{if(!await J({forceRevalidate:!0}))return o&&o.open("batch_export"),r("整合集加入文章库是完整版能力，请先解锁"),{success:!1,error:"整合集加入文章库需要解锁完整版"};const x=ne();r(`正在读取“${x.title}”的完整文章列表…`);const u=await Ee(x);if(u.length===0)throw new Error("合集列表暂时为空，请刷新页面后重试");const w={id:x.id,title:x.title,accountName:x.accountName,articleCount:u.length},v=await Ce({type:"PREPARE_ALBUM_LIBRARY",album:w}),i=new Set(v.linkedArticleIds),m=u.filter(A=>!i.has(Xe(A.url)));if(m.length===0)return r(`“${v.collection.name}”已包含全部 ${u.length} 篇文章，正在打开文章库…`),await chrome.runtime.sendMessage({type:"OPEN_LIBRARY",collectionId:v.collection.id}),{success:!0,message:"合集已全部加入文章库"};let S=v.collection,I=0;for(let A=0;A<m.length;A+=10){const f=m.slice(A,A+10);let d=0;const k=await Pe(f,3,async P=>{const M=await fe(P);return d+=1,r(`正在并行读取“${S.name}” · ${I+d}/${m.length} 篇`),M}),N=await Ce({type:"ARCHIVE_ALBUM_LIBRARY_BATCH",album:w,articles:k});S=N.collection,I+=N.articleIds.length}return r(`已加入“${S.name}” · 新增 ${I} 篇 · 共 ${u.length} 篇，正在打开文章库…`),await chrome.runtime.sendMessage({type:"OPEN_LIBRARY",collectionId:S.id}),{success:!0,message:`已把 ${I} 篇文章加入文章库`}}catch(x){const u=x instanceof Error?x.message:"合集加入文章库失败";return r(`${u}；再次点击会跳过已成功入库的文章并继续`),{success:!1,error:u}}finally{l.disabled=!1,l.textContent=p,c.disabled=!1,h.disabled=!1}});se=async()=>{if(T.isRunning())return y=!y,c.textContent=y?"继续下载":"暂停下载",r(y?"任务已暂停，点击继续下载":"任务已继续"),{success:!0,message:y?"合集任务已暂停":"合集任务已继续"};const p=await O(!1);if(!p.licensed&&p.trialConsumed){const x=Math.max(b()-Math.min(Y,b()),0);return r(`已免费保存 ${Math.min(Y,b())} 篇 · 解锁后可继续归档剩余 ${x} 篇，并自动增量更新`),U("album_trial_blocked_used",{surface:"album_panel",trigger:"trial_used",articleCountBucket:j(b()),trialConsumed:!0}),U("pro_feature_blocked",{surface:"album_panel",trigger:"trial_used",errorReason:"not_licensed"}),o&&o.open("trial_used"),{success:!1,error:"本机免费试用已使用，解锁后可导出完整合集"}}return y=!1,z=p.licensed,me({surface:"album_panel",trigger:"batch_export",format:"zip",articleCountBucket:j(b())},()=>T.run(),x=>x.success)},ie=async()=>{if(T.isRunning())return{success:!1,error:"当前任务仍在运行，请等待本卷完成或取消保存后再完整重新导出"};if(!await J({forceRevalidate:!0}))return r("完整重新导出是完整版能力；可先使用一次免费试用"),U("pro_feature_blocked",{surface:"album_panel",trigger:"batch_export",errorReason:"not_licensed"}),o&&o.open("batch_export"),{success:!1,error:"完整重新导出需要解锁完整版"};const p=ne();return await C().remove([de(p.id,p.ascending),we(p.id,p.ascending)]),r("当前排序方向的断点和增量历史已清零，正在完整重新导出…"),z=!0,me({surface:"album_panel",trigger:"batch_export",format:"zip",articleCountBucket:j(b())},()=>T.run(),x=>x.success)};const V=p=>{p&&p().catch(x=>r(ee(x)))};c.addEventListener("click",()=>{V(se)}),l.addEventListener("click",()=>{V(()=>R.run())}),h.addEventListener("click",()=>{V(ie)}),document.documentElement.append(a);const $=de(t.id,t.ascending);try{O(!0).then(async({licensed:p})=>{if(!p)return;const u=(await C().get($))[$];(u?.status==="running"||u?.status==="failed")&&r(`上次新增归档完成 ${u.completedArticles}/${u.totalArticles} 篇，点击继续`)}).catch(()=>r("扩展已更新，请刷新当前页面后再试"))}catch(p){r(p instanceof Error?p.message:"扩展已更新，请刷新当前页面后再试")}}lt();be=ct({onQuickSave:t=>{ge=t}});
