const je=20;async function ze(e,t,n){const r=new Array(e.length);let i=0;const a=Math.min(e.length,Math.max(1,Math.floor(t)));return await Promise.all(Array.from({length:a},async()=>{for(;i<e.length;){const o=i;i+=1,r[o]=await n(e[o],o)}})),r}const Ve=5,We="albumTrial:v1";function Ye(e,t){return`albumProgress:v2:${e}:${t?"asc":"desc"}`}function Ke(e,t){return`albumHistory:v1:${e}:${t?"asc":"desc"}`}function v(e){return`${e.msgid}:${e.itemidx}`}function P(e){return Array.isArray(e)?new Set(e.filter(t=>typeof t=="string"&&t.length>0)):new Set}function Ge(e){return[...new Set(e.map(v))]}function Z(e,t){const n=P(t);return e.filter(r=>!n.has(v(r)))}function Xe(e,t,n){const r=Z(e,t),i=new Set(r.map(v)),a=new Set([...P(n)].filter(o=>i.has(o)));return{pending:r.filter(o=>!a.has(v(o))),completedIdentities:a}}function Je(e){return e===!0||typeof e=="object"&&e!==null&&e.consumed===!0}function Qe(e){if(!e||!/^\d+$/.test(e))return;const t=Number(e);if(!Number.isFinite(t)||t<=0)return;const n=new Date(t*1e3);return Number.isNaN(n.getTime())?void 0:n.toISOString()}function M(e){return e.replace(/&amp;/g,"&")}function h(e,t){return e.match(new RegExp(`${t}:\\s*'([^']*)'`))?.[1]}function ee(e){if(!(!e.title||!e.url||!e.msgid||!e.itemidx))return{title:e.title,url:M(e.url).replace(/^http:/,"https:"),msgid:e.msgid,itemidx:e.itemidx,createTime:e.create_time,position:e.pos_num?Number(e.pos_num):void 0}}function te(e=location.href){const t=new URL(e);return t.hostname==="mp.weixin.qq.com"&&t.pathname==="/mp/appmsgalbum"&&t.searchParams.get("action")==="getalbum"&&!!t.searchParams.get("album_id")}function ne(e){if(!e)return;let t;try{t=new URL(e,"https://mp.weixin.qq.com")}catch{return}if(t.hostname==="mp.weixin.qq.com"&&t.pathname==="/mp/appmsgalbum"&&t.searchParams.get("album_id"))return t.protocol="https:",t.hash="",t.toString()}function Ze(e){const t=[],n=new Set,r=(o,l)=>{if(!l)return;const s=ne(l.replace(/\\x26amp;/g,"&").replace(/&amp;/g,"&"));if(!s)return;const u=new URL(s).searchParams.get("album_id")||s;if(n.has(u))return;n.add(u);const m=(o||"").replace(/\s+/g," ").trim();t.push({title:m||"微信合集",url:s})},i=e.indexOf("album_info_list");if(i>=0){const o=e.slice(i,i+2e4);for(const l of o.split("{").slice(1))if(r(l.match(/title:\s*'([^']*)'/)?.[1],l.match(/link:\s*'([^']*)'/)?.[1]),t.length>=3)return t}const a=e.match(/appmsgalbuminfo:\s*\{([\s\S]{0,2000}?)\}/)?.[1];return a&&r(a.match(/title:\s*'([^']*)'/)?.[1],a.match(/link:\s*'([^']*)'/)?.[1]),t}function et(e=document){if(!te(e.location?.href||location.href))throw new Error("当前页面不是可识别的微信公众号合集");const t=[...e.scripts].map(f=>f.textContent||"").find(f=>f.includes("window.cgiData"))||"",n=h(t,"albumId")||new URL(location.href).searchParams.get("album_id")||"",r=h(t,"title")||"微信公众号合集",i=h(t,"nick_name")||"微信公众号",a=Number(h(t,"article_count")||0),o=[...e.querySelectorAll(".js_album_item[data-link]")].map(f=>({title:f.querySelector(".album__item-title-wrp")?.textContent?.trim()||"未命名文章",url:M(f.dataset.link||"").replace(/^http:/,"https:"),msgid:f.dataset.msgid||"",itemidx:f.dataset.itemidx||"",createTime:f.querySelector(".js_article_create_time")?.textContent?.trim(),position:f.dataset.pos_num?Number(f.dataset.pos_num):void 0})).filter(f=>f.url&&f.msgid&&f.itemidx);if(!n||o.length===0)throw new Error("没有找到合集文章列表");const l=e.querySelector(".js_positive_order"),s=e.querySelector(".js_negative_order"),u=o[0]?.position,m=o.at(-1)?.position,A=l&&s?l.style.display==="none":u!==void 0&&m!==void 0&&u<m;return{id:n,title:r,accountName:i,articleCount:a,articles:o,ascending:A}}function tt(e){if(e.base_resp?.ret!==0||!e.getalbum_resp)throw new Error("合集分页读取失败");const t=e.getalbum_resp.article_list;return{articles:(t?Array.isArray(t)?t:[t]:[]).map(ee).filter(r=>!!r),continueFlag:Number(e.getalbum_resp.continue_flag)===1}}function nt(e,t,n,r=10,i=!1){const a=new URLSearchParams({action:"getalbum",__biz:e,album_id:t,count:String(r),f:"json"});return n&&(a.set("begin_msgid",n.msgid),a.set("begin_itemidx",n.itemidx)),i&&a.set("is_reverse","1"),`https://mp.weixin.qq.com/mp/appmsgalbum?${a}`}function rt(e,t){const n=e.map(r=>r.position).filter(r=>Number.isFinite(r));return n.length!==e.length?!0:n.every((r,i)=>i===0||(t?r>n[i-1]:r<n[i-1]))}const re={licenseApiUrl:"https://work.bzjkmn.cn",maxDevices:2,launchPriceCny:19},ie=!!re.licenseApiUrl,x="license:installationId",b="license:state",ae=10080*60*1e3,oe=1440*60*1e3;async function se(e){const n=(await e.get(x))[x];if(typeof n=="string"&&n)return n;const r=crypto.randomUUID();return await e.set({[x]:r}),r}async function H(e,t){await e.set({[b]:t})}async function U(e){await e.remove(b)}async function le(e){const n=(await e.get(b))[b];if(!n?.licensed)return;if(n.credential?.kind&&typeof n.credential.value=="string")return n;if(typeof n.email!="string"||!n.email)return;const r=n.email.trim().toLowerCase();if(r.endsWith("@internal")){await U(e);return}const i={licensed:!0,credential:{kind:"email",value:r},type:typeof n.type=="string"?n.type:"lifetime",maxDevices:typeof n.maxDevices=="number"?n.maxDevices:1,expiresAt:null,activatedAt:typeof n.activatedAt=="number"?n.activatedAt:0,checkedAt:typeof n.checkedAt=="number"?n.checkedAt:0};return await H(e,i),i}const S=new Map;async function it(e,t,n=ie){if(!n)return!1;try{const r=await le(e);if(!r?.licensed)return!1;const i=Date.now();if(r.expiresAt!==null&&r.expiresAt*1e3<=i)return await U(e),!1;if(i-r.activatedAt<ae||i-r.checkedAt<oe)return!0;const a=`${r.credential.kind}:${r.credential.value}`;let o=S.get(a);return o||(o=(async()=>{try{return await t(r,await se(e))?(await H(e,{...r,checkedAt:Date.now()}),!0):!1}catch{return!1}finally{S.delete(a)}})(),S.set(a,o)),o}catch{return!1}}function ce(e){for(var t=1;t<arguments.length;t++){var n=arguments[t];for(var r in n)Object.prototype.hasOwnProperty.call(n,r)&&(e[r]=n[r])}return e}function E(e,t){return Array(t+1).join(e)}function F(e){return e.replace(/^\n*/,"")}function q(e){for(var t=e.length;t>0&&e[t-1]===`
`;)t--;return e.substring(0,t)}function j(e){return q(F(e))}var ue=["ADDRESS","ARTICLE","ASIDE","AUDIO","BLOCKQUOTE","BODY","CANVAS","CENTER","DD","DIR","DIV","DL","DT","FIELDSET","FIGCAPTION","FIGURE","FOOTER","FORM","FRAMESET","H1","H2","H3","H4","H5","H6","HEADER","HGROUP","HR","HTML","ISINDEX","LI","MAIN","MENU","NAV","NOFRAMES","NOSCRIPT","OL","OUTPUT","P","PRE","SECTION","TABLE","TBODY","TD","TFOOT","TH","THEAD","TR","UL"];function C(e){return R(e,ue)}var z=["AREA","BASE","BR","COL","COMMAND","EMBED","HR","IMG","INPUT","KEYGEN","LINK","META","PARAM","SOURCE","TRACK","WBR"];function V(e){return R(e,z)}function fe(e){return Y(e,z)}var W=["A","TABLE","THEAD","TBODY","TFOOT","TH","TD","IFRAME","SCRIPT","AUDIO","VIDEO"];function me(e){return R(e,W)}function de(e){return Y(e,W)}function R(e,t){return t.indexOf(e.nodeName)>=0}function Y(e,t){return e.getElementsByTagName&&t.some(function(n){return e.getElementsByTagName(n).length})}var pe=[[/\\/g,"\\\\"],[/\*/g,"\\*"],[/^-/g,"\\-"],[/^\+ /g,"\\+ "],[/^(=+)/g,"\\$1"],[/^(#{1,6}) /g,"\\$1 "],[/`/g,"\\`"],[/^~~~/g,"\\~~~"],[/\[/g,"\\["],[/\]/g,"\\]"],[/^>/g,"\\>"],[/_/g,"\\_"],[/^(\d+)\. /g,"$1\\. "]];function K(e){return pe.reduce(function(t,n){return t.replace(n[0],n[1])},e)}var c={};c.paragraph={filter:"p",replacement:function(e){return`

`+e+`

`}};c.lineBreak={filter:"br",replacement:function(e,t,n){return n.br+`
`}};c.heading={filter:["h1","h2","h3","h4","h5","h6"],replacement:function(e,t,n){var r=Number(t.nodeName.charAt(1));if(n.headingStyle==="setext"&&r<3){var i=E(r===1?"=":"-",e.length);return`

`+e+`
`+i+`

`}else return`

`+E("#",r)+" "+e+`

`}};c.blockquote={filter:"blockquote",replacement:function(e){return e=j(e).replace(/^/gm,"> "),`

`+e+`

`}};c.list={filter:["ul","ol"],replacement:function(e,t){var n=t.parentNode;return n.nodeName==="LI"&&n.lastElementChild===t?`
`+e:`

`+e+`

`}};c.listItem={filter:"li",replacement:function(e,t,n){var r=n.bulletListMarker+"   ",i=t.parentNode;if(i.nodeName==="OL"){var a=i.getAttribute("start"),o=Array.prototype.indexOf.call(i.children,t);r=(a?Number(a)+o:o+1)+".  "}var l=/\n$/.test(e);return e=j(e)+(l?`
`:""),e=e.replace(/\n/gm,`
`+" ".repeat(r.length)),r+e+(t.nextSibling?`
`:"")}};c.indentedCodeBlock={filter:function(e,t){return t.codeBlockStyle==="indented"&&e.nodeName==="PRE"&&e.firstChild&&e.firstChild.nodeName==="CODE"},replacement:function(e,t,n){return`

    `+t.firstChild.textContent.replace(/\n/g,`
    `)+`

`}};c.fencedCodeBlock={filter:function(e,t){return t.codeBlockStyle==="fenced"&&e.nodeName==="PRE"&&e.firstChild&&e.firstChild.nodeName==="CODE"},replacement:function(e,t,n){for(var r=t.firstChild.getAttribute("class")||"",i=(r.match(/language-(\S+)/)||[null,""])[1],a=t.firstChild.textContent,o=n.fence.charAt(0),l=3,s=new RegExp("^"+o+"{3,}","gm"),u;u=s.exec(a);)u[0].length>=l&&(l=u[0].length+1);var m=E(o,l);return`

`+m+i+`
`+a.replace(/\n$/,"")+`
`+m+`

`}};c.horizontalRule={filter:"hr",replacement:function(e,t,n){return`

`+n.hr+`

`}};c.inlineLink={filter:function(e,t){return t.linkStyle==="inlined"&&e.nodeName==="A"&&e.getAttribute("href")},replacement:function(e,t){var n=D(t.getAttribute("href")),r=_(y(t.getAttribute("title"))),i=r?' "'+r+'"':"";return"["+e+"]("+n+i+")"}};c.referenceLink={filter:function(e,t){return t.linkStyle==="referenced"&&e.nodeName==="A"&&e.getAttribute("href")},replacement:function(e,t,n){var r=D(t.getAttribute("href")),i=y(t.getAttribute("title"));i&&(i=' "'+_(i)+'"');var a,o;switch(n.linkReferenceStyle){case"collapsed":a="["+e+"][]",o="["+e+"]: "+r+i;break;case"shortcut":a="["+e+"]",o="["+e+"]: "+r+i;break;default:var l=this.references.length+1;a="["+e+"]["+l+"]",o="["+l+"]: "+r+i}return this.references.push(o),a},references:[],append:function(e){var t="";return this.references.length&&(t=`

`+this.references.join(`
`)+`

`,this.references=[]),t}};c.emphasis={filter:["em","i"],replacement:function(e,t,n){return e.trim()?n.emDelimiter+e+n.emDelimiter:""}};c.strong={filter:["strong","b"],replacement:function(e,t,n){return e.trim()?n.strongDelimiter+e+n.strongDelimiter:""}};c.code={filter:function(e){var t=e.previousSibling||e.nextSibling,n=e.parentNode.nodeName==="PRE"&&!t;return e.nodeName==="CODE"&&!n},replacement:function(e){if(!e)return"";e=e.replace(/\r?\n|\r/g," ");for(var t=/^`|^ .*?[^ ].* $|`$/.test(e)?" ":"",n="`",r=e.match(/`+/gm)||[];r.indexOf(n)!==-1;)n=n+"`";return n+t+e+t+n}};c.image={filter:"img",replacement:function(e,t){var n=K(y(t.getAttribute("alt"))),r=D(t.getAttribute("src")||""),i=y(t.getAttribute("title")),a=i?' "'+_(i)+'"':"";return r?"!["+n+"]("+r+a+")":""}};function y(e){return e?e.replace(/(\n+\s*)+/g,`
`):""}function D(e){var t=e.replace(/([<>()])/g,"\\$1");return t.indexOf(" ")>=0?"<"+t+">":t}function _(e){return e.replace(/"/g,'\\"')}function G(e){this.options=e,this._keep=[],this._remove=[],this.blankRule={replacement:e.blankReplacement},this.keepReplacement=e.keepReplacement,this.defaultRule={replacement:e.defaultReplacement},this.array=[];for(var t in e.rules)this.array.push(e.rules[t])}G.prototype={add:function(e,t){this.array.unshift(t)},keep:function(e){this._keep.unshift({filter:e,replacement:this.keepReplacement})},remove:function(e){this._remove.unshift({filter:e,replacement:function(){return""}})},forNode:function(e){if(e.isBlank)return this.blankRule;var t;return(t=N(this.array,e,this.options))||(t=N(this._keep,e,this.options))||(t=N(this._remove,e,this.options))?t:this.defaultRule},forEach:function(e){for(var t=0;t<this.array.length;t++)e(this.array[t],t)}};function N(e,t,n){for(var r=0;r<e.length;r++){var i=e[r];if(he(i,t,n))return i}}function he(e,t,n){var r=e.filter;if(typeof r=="string"){if(r===t.nodeName.toLowerCase())return!0}else if(Array.isArray(r)){if(r.indexOf(t.nodeName.toLowerCase())>-1)return!0}else if(typeof r=="function"){if(r.call(e,t,n))return!0}else throw new TypeError("`filter` needs to be a string, array, or function")}function ge(e){var t=e.element,n=e.isBlock,r=e.isVoid,i=e.isPre||function(A){return A.nodeName==="PRE"};if(!(!t.firstChild||i(t))){for(var a=null,o=!1,l=null,s=O(l,t,i);s!==t;){if(s.nodeType===3||s.nodeType===4){var u=s.data.replace(/[ \r\n\t]+/g," ");if((!a||/ $/.test(a.data))&&!o&&u[0]===" "&&(u=u.substr(1)),!u){s=k(s);continue}s.data=u,a=s}else if(s.nodeType===1)n(s)||s.nodeName==="BR"?(a&&(a.data=a.data.replace(/ $/,"")),a=null,o=!1):r(s)||i(s)?(a=null,o=!0):a&&(o=!1);else{s=k(s);continue}var m=O(l,s,i);l=s,s=m}a&&(a.data=a.data.replace(/ $/,""),a.data||k(a))}}function k(e){var t=e.nextSibling||e.parentNode;return e.parentNode.removeChild(e),t}function O(e,t,n){return e&&e.parentNode===t||n(t)?t.nextSibling||t.parentNode:t.firstChild||t.nextSibling||t.parentNode}var L=typeof window<"u"?window:{};function ve(){var e=L.DOMParser,t=!1;try{new e().parseFromString("","text/html")&&(t=!0)}catch{}return t}function be(){var e=function(){};return ye()?e.prototype.parseFromString=function(t){var n=new window.ActiveXObject("htmlfile");return n.designMode="on",n.open(),n.write(t),n.close(),n}:e.prototype.parseFromString=function(t){var n=document.implementation.createHTMLDocument("");return n.open(),n.write(t),n.close(),n},e}function ye(){var e=!1;try{document.implementation.createHTMLDocument("").open()}catch{L.ActiveXObject&&(e=!0)}return e}var we=ve()?L.DOMParser:be();function Ae(e,t){var n;if(typeof e=="string"){var r=xe().parseFromString('<x-turndown id="turndown-root">'+e+"</x-turndown>","text/html");n=r.getElementById("turndown-root")}else n=e.cloneNode(!0);return ge({element:n,isBlock:C,isVoid:V,isPre:t.preformattedCode?Se:null}),n}var T;function xe(){return T=T||new we,T}function Se(e){return e.nodeName==="PRE"||e.nodeName==="CODE"}function Ne(e,t){return e.isBlock=C(e),e.isCode=e.nodeName==="CODE"||e.parentNode.isCode,e.isBlank=ke(e),e.flankingWhitespace=Te(e,t),e}function ke(e){return!V(e)&&!me(e)&&/^\s*$/i.test(e.textContent)&&!fe(e)&&!de(e)}function Te(e,t){if(e.isBlock||t.preformattedCode&&e.isCode)return{leading:"",trailing:""};var n=Ee(e.textContent);return n.leadingAscii&&I("left",e,t)&&(n.leading=n.leadingNonAscii),n.trailingAscii&&I("right",e,t)&&(n.trailing=n.trailingNonAscii),{leading:n.leading,trailing:n.trailing}}function Ee(e){var t=e.match(/^(([ \t\r\n]*)(\s*))(?:(?=\S)[\s\S]*\S)?((\s*?)([ \t\r\n]*))$/);return{leading:t[1],leadingAscii:t[2],leadingNonAscii:t[3],trailing:t[4],trailingNonAscii:t[5],trailingAscii:t[6]}}function I(e,t,n){var r,i,a;return e==="left"?(r=t.previousSibling,i=/ $/):(r=t.nextSibling,i=/^ /),r&&(r.nodeType===3?a=i.test(r.nodeValue):n.preformattedCode&&r.nodeName==="CODE"?a=!1:r.nodeType===1&&!C(r)&&(a=i.test(r.textContent))),a}var Ce=Array.prototype.reduce;function w(e){if(!(this instanceof w))return new w(e);var t={rules:c,headingStyle:"setext",hr:"* * *",bulletListMarker:"*",codeBlockStyle:"indented",fence:"```",emDelimiter:"_",strongDelimiter:"**",linkStyle:"inlined",linkReferenceStyle:"full",br:"  ",preformattedCode:!1,blankReplacement:function(n,r){return r.isBlock?`

`:""},keepReplacement:function(n,r){return r.isBlock?`

`+r.outerHTML+`

`:r.outerHTML},defaultReplacement:function(n,r){return r.isBlock?`

`+n+`

`:n}};this.options=ce({},t,e),this.rules=new G(this.options)}w.prototype={turndown:function(e){if(!_e(e))throw new TypeError(e+" is not a string, or an element/document/fragment node.");if(e==="")return"";var t=X.call(this,new Ae(e,this.options));return Re.call(this,t)},use:function(e){if(Array.isArray(e))for(var t=0;t<e.length;t++)this.use(e[t]);else if(typeof e=="function")e(this);else throw new TypeError("plugin must be a Function or an Array of Functions");return this},addRule:function(e,t){return this.rules.add(e,t),this},keep:function(e){return this.rules.keep(e),this},remove:function(e){return this.rules.remove(e),this},escape:function(e){return K(e)}};function X(e){var t=this;return Ce.call(e.childNodes,function(n,r){r=new Ne(r,t.options);var i="";return r.nodeType===3?i=r.isCode?r.nodeValue:t.escape(r.nodeValue):r.nodeType===1&&(i=De.call(t,r)),J(n,i)},"")}function Re(e){var t=this;return this.rules.forEach(function(n){typeof n.append=="function"&&(e=J(e,n.append(t.options)))}),e.replace(/^[\t\r\n]+/,"").replace(/[\t\r\n\s]+$/,"")}function De(e){var t=this.rules.forNode(e),n=X.call(this,e),r=e.flankingWhitespace;return(r.leading||r.trailing)&&(n=n.trim()),r.leading+t.replacement(n,e,this.options)+r.trailing}function J(e,t){var n=q(e),r=F(t),i=Math.max(e.length-n.length,t.length-r.length),a=`

`.substring(0,i);return n+a+r}function _e(e){return e!=null&&(typeof e=="string"||e.nodeType&&(e.nodeType===1||e.nodeType===9||e.nodeType===11))}var B=/highlight-(?:text|source)-([a-z0-9]+)/;function Le(e){e.addRule("highlightedCodeBlock",{filter:function(t){var n=t.firstChild;return t.nodeName==="DIV"&&B.test(t.className)&&n&&n.nodeName==="PRE"},replacement:function(t,n,r){var i=n.className||"",a=(i.match(B)||[null,""])[1];return`

`+r.fence+a+`
`+n.firstChild.textContent+`
`+r.fence+`

`}})}function $e(e){e.addRule("strikethrough",{filter:["del","s","strike"],replacement:function(t){return"~"+t+"~"}})}var Oe=Array.prototype.indexOf,Ie=Array.prototype.every,p={};p.tableCell={filter:["th","td"],replacement:function(e,t){return Q(e,t)}};p.tableRow={filter:"tr",replacement:function(e,t){var n="",r={left:":--",right:"--:",center:":-:"};if($(t))for(var i=0;i<t.childNodes.length;i++){var a="---",o=(t.childNodes[i].getAttribute("align")||"").toLowerCase();o&&(a=r[o]||a),n+=Q(a,t.childNodes[i])}return`
`+e+(n?`
`+n:"")}};p.table={filter:function(e){return e.nodeName==="TABLE"&&$(e.rows[0])},replacement:function(e){return e=e.replace(`

`,`
`),`

`+e+`

`}};p.tableSection={filter:["thead","tbody","tfoot"],replacement:function(e){return e}};function $(e){var t=e.parentNode;return t.nodeName==="THEAD"||t.firstChild===e&&(t.nodeName==="TABLE"||Be(t))&&Ie.call(e.childNodes,function(n){return n.nodeName==="TH"})}function Be(e){var t=e.previousSibling;return e.nodeName==="TBODY"&&(!t||t.nodeName==="THEAD"&&/^\s*$/i.test(t.textContent))}function Q(e,t){var n=Oe.call(t.parentNode.childNodes,t),r=" ";return n===0&&(r="| "),r+e+" |"}function Pe(e){e.keep(function(n){return n.nodeName==="TABLE"&&!$(n.rows[0])});for(var t in p)e.addRule(t,p[t])}function Me(e){e.addRule("taskListItems",{filter:function(t){return t.type==="checkbox"&&t.parentNode.nodeName==="LI"},replacement:function(t,n){return(n.checked?"[x]":"[ ]")+" "}})}function He(e){e.use([Le,$e,Pe,Me])}function d(e){return JSON.stringify(e.replace(/\r?\n/g," "))}function Ue(e){const t=e.getFullYear(),n=String(e.getMonth()+1).padStart(2,"0"),r=String(e.getDate()).padStart(2,"0"),i=String(e.getHours()).padStart(2,"0"),a=String(e.getMinutes()).padStart(2,"0"),o=String(e.getSeconds()).padStart(2,"0");return`${t}-${n}-${r} ${i}:${a}:${o}`}function at(e,t=new Date){const n=new w({headingStyle:"atx",bulletListMarker:"-",codeBlockStyle:"fenced",emDelimiter:"*",strongDelimiter:"**"});n.use(He),n.addRule("wechatSection",{filter:"section",replacement:a=>`

${a.trim()}

`}),n.addRule("wechatImage",{filter:"img",replacement:(a,o)=>{const l=o,s=l.getAttribute("data-src")||l.getAttribute("src")||"";return s?`![${l.alt||""}](${s})`:""}});const r=["---",`title: ${d(e.title)}`,`account: ${d(e.accountName||"")}`,`author: ${d(e.author||"")}`,`published_at: ${d(e.publishTime||"")}`,`source: ${d(e.sourceUrl)}`,'platform: "wechat"',`saved_at: ${d(Ue(t))}`,"---"].join(`
`),i=n.turndown(e.html).trim();return`${r}

# ${e.title}

${i}
`}function g(e){return e.replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;")}function Fe(e){const t=e.getFullYear(),n=String(e.getMonth()+1).padStart(2,"0"),r=String(e.getDate()).padStart(2,"0"),i=String(e.getHours()).padStart(2,"0"),a=String(e.getMinutes()).padStart(2,"0"),o=String(e.getSeconds()).padStart(2,"0");return`${t}-${n}-${r} ${i}:${a}:${o}`}const qe=`
    * { box-sizing: border-box; }
    body { margin: 0; padding: 32px 16px; color: #1f2d24; background: #f4f7f5; font-family: -apple-system, BlinkMacSystemFont, "PingFang SC", "Helvetica Neue", "Microsoft YaHei", sans-serif; }
    .article { max-width: 677px; margin: 0 auto; padding: 40px 32px 56px; background: #fff; border-radius: 12px; box-shadow: 0 4px 18px rgba(27, 48, 35, .06); }
    .article-title { margin: 0 0 12px; font-size: 22px; line-height: 1.4; }
    .article-meta { margin: 0 0 4px; color: #77847c; font-size: 13px; }
    .article-source { margin: 0 0 28px; padding-bottom: 20px; border-bottom: 1px solid #e8efea; color: #9aa8a0; font-size: 12px; }
    .article-source a { color: #087f4e; text-decoration: none; }
    .article-content { font-size: 16px; line-height: 1.75; word-wrap: break-word; overflow-wrap: break-word; }
    .article-content img { display: block; max-width: 100%; height: auto; margin: 12px auto; }
    .article-content blockquote { margin: 16px 0; padding: 10px 16px; border-left: 3px solid #cfddd4; color: #5c6d63; background: #f6f9f7; }
    .article-content pre { overflow-x: auto; padding: 12px 14px; border-radius: 8px; background: #f4f6f5; font-size: 13px; line-height: 1.6; }
    .article-content code { font-family: ui-monospace, SFMono-Regular, Menlo, Consolas, monospace; }
    .article-content table { width: 100%; border-collapse: collapse; }
    .article-content th, .article-content td { padding: 6px 10px; border: 1px solid #dfe7e2; }
    .article-content a { color: #087f4e; }
    @media print { body { margin: 0; padding: 0; background: #fff; } .article { max-width: none; padding: 0; box-shadow: none; border-radius: 0; } }
    @page { margin: 16mm 14mm; }
  `;function ot(e,t=new Date){const n=[e.accountName,e.author,e.publishTime].filter(r=>!!r).map(g).join(" · ");return`<!DOCTYPE html>
<html lang="zh-CN">
<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <meta name="generator" content="wechat-to-markdown" />
  <title>${g(e.title)}</title>
  <style>${qe}</style>
</head>
<body>
  <main class="article">
    <header>
      <h1 class="article-title">${g(e.title)}</h1>
      ${n?`<p class="article-meta">${n}</p>`:""}
      <p class="article-source"><a href="${g(e.sourceUrl)}" rel="noopener noreferrer">查看原文</a> · 保存于 ${Fe(t)}</p>
    </header>
    <div class="article-content">
${e.html}
    </div>
  </main>
</body>
</html>
`}export{We as A,at as a,ot as b,re as c,ie as d,Ve as e,U as f,se as g,te as h,Je as i,et as j,Ye as k,Ke as l,je as m,Ge as n,v as o,ze as p,nt as q,it as r,Xe as s,tt as t,Qe as u,rt as v,Ze as w,ne as x,H as y};
