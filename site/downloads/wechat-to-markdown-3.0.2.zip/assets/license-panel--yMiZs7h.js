import{w as J,x as Q,b as W,a as V,d as G,g as ee,y as te,r as ne,f as re,c as L}from"./html-CTsso1Bm.js";const se="扩展刚刚更新，请刷新当前公众号页面后再保存",ae=[/extension context invalidated/i,/could not establish connection/i,/receiving end does not exist/i,/message port closed/i];function X(e,r="扩展操作失败，请稍后重试"){const n=e instanceof Error?e.message:typeof e=="string"?e:"";return ae.some(t=>t.test(n))?se:n.trim()||r}function oe(e){let r;return{isRunning:()=>!!r,run:()=>(r||(r=e().finally(()=>{r=void 0})),r)}}const ie=["script","style","iframe","noscript",".js_ad_link",".weapp_display_element",'[data-type="ad"]'];function ce(e){const r=e.cloneNode(!0);r.querySelectorAll(ie.join(",")).forEach(t=>t.remove());const n=[];return r.querySelectorAll("img").forEach(t=>{const a=t.getAttribute("data-src")||t.getAttribute("src");if(!a||a.startsWith("data:image/svg")){t.remove();return}t.setAttribute("src",a),t.removeAttribute("srcset"),t.removeAttribute("style"),n.push({src:a,alt:t.alt||void 0})}),r.querySelectorAll("*").forEach(t=>{t.removeAttribute("class"),t.removeAttribute("style"),t.removeAttribute("id");for(const a of Array.from(t.attributes))a.name.startsWith("data-")&&a.name!=="data-src"&&t.removeAttribute(a.name)}),{html:r.innerHTML,images:n}}function k(e,...r){for(const n of r){const t=e.querySelector(n)?.textContent?.trim();if(t)return t}}function $(e,r){return e.querySelector(`meta[property="${r}"], meta[name="${r}"]`)?.content.trim()||void 0}function Fe(){return location.hostname==="mp.weixin.qq.com"&&!!document.querySelector("#js_content")}function $e(e=document){const r=new Set,n=[],t=(s,o)=>{const i=new URL(o).searchParams.get("album_id")||o;r.has(i)||n.length>=3||(r.add(i),n.push({title:s,url:o}))},a=[...e.scripts].map(s=>s.textContent||"").join(`
`);for(const s of J(a))t(s.title,s.url);for(const s of e.querySelectorAll('a[href*="appmsgalbum"]')){const o=Q(s.getAttribute("href")||s.href);if(!o)continue;const i=(s.textContent||"").replace(/#/g," ").replace(/\s+/g," ").trim();t(i||"微信合集",o)}return n}function Y(){return le(document,location.href)}function le(e,r){if(!e.querySelector("#js_content"))throw new Error("当前页面不是可识别的微信公众号文章");const n=e.querySelector("#js_content");if(!n)throw new Error("没有找到文章正文");const t=k(e,"#activity-name",".rich_media_title")||$(e,"og:title")||e.title.replace(/\s*[-_]\s*微信公众平台\s*$/,"").trim()||"未命名文章",a=k(e,"#js_name",".rich_media_meta_nickname")||$(e,"og:article:author"),s=k(e,"#js_author_name",".rich_media_meta_text"),o=k(e,"#publish_time","#js_publish_time",".rich_media_meta_text"),i=ce(n);return{title:t,author:s===o?void 0:s,accountName:a,publishTime:o,sourceUrl:r,html:i.html,images:i.images,siteName:a||"微信公众号",hostname:"mp.weixin.qq.com",extractorType:"wechat",contentType:"article"}}const de={amp:"&",lt:"<",gt:">",quot:'"',apos:"'",nbsp:" "};function q(e){return Number.isFinite(e)&&e>=0&&e<=1114111}function ue(e){return e.replace(/&(#x?[0-9a-f]+|[a-z]+);?/gi,(r,n)=>{if(n.startsWith("#x")){const t=parseInt(n.slice(2),16);return q(t)?String.fromCodePoint(t):r}if(n.startsWith("#")){const t=parseInt(n.slice(1),10);return q(t)?String.fromCodePoint(t):r}return de[n.toLowerCase()]??r})}function pe(e){const r=e.replace(/<br\s*\/?>/gi,`
`).replace(/<\/(p|div|li|h[1-6]|blockquote)>/gi,`
`).replace(/<[^>]+>/g,"");return ue(r).replace(/[ \t]+\n/g,`
`).replace(/\n{3,}/g,`

`).trim()}const x=640,f=28,R=320,A=22,N=1.4,P=15,I=15,z=1.6,fe=18,me="#FFFFFF",H="#1F2D24",O="#77847C",he="#E8EFEA",b='system-ui, -apple-system, "Segoe UI", "PingFang SC", "Microsoft YaHei", sans-serif';async function ge(e){try{const r=await chrome.runtime.sendMessage({type:"FETCH_IMAGE",url:e});return r.success?r.dataUrl:null}catch{return null}}async function xe(e){try{return await createImageBitmap(await(await fetch(e)).blob())}catch{return null}}function be(e){return[...new Intl.Segmenter(void 0,{granularity:"grapheme"}).segment(e)].map(r=>r.segment)}function U(e,r,n,t){const a=[];let s="",o=!1;for(const i of be(r)){if(i===`
`){if(a.push(s),s="",a.length>=t){o=!0;break}continue}const p=s+i;if(s&&e.measureText(p).width>n){if(a.push(s),s=i,a.length>=t){o=!0;break}}else s=p}return s&&(a.length<t?a.push(s):o=!0),{lines:a.slice(0,t),truncated:o}}function j(e,r,n){if(e.measureText(r).width<=n)return r;let t=r;for(;t.length>0&&e.measureText(`${t}…`).width>n;)t=t.slice(0,-1);return`${t}…`}function we(e,r,n,t,a,s){const o=Math.max(a/r.width,s/r.height),i=a/o,p=s/o;e.drawImage(r,(r.width-i)/2,(r.height-p)/2,i,p,n,t,a,s)}function ye(e){if(!e)return"";const r=new Date(e);return Number.isNaN(r.getTime())?e.trim():`${r.getFullYear()}-${String(r.getMonth()+1).padStart(2,"0")}-${String(r.getDate()).padStart(2,"0")}`}function ve(e,r,n){if(e.measureText(r).width<=n)return r;let t=r;for(;t.length>0&&e.measureText(`${t}…`).width>n;)t=t.slice(0,-1);return t?`${t}…`:r.slice(0,12)}async function Ee(e){const r=document.createElement("canvas"),n=r.getContext("2d");if(!n)throw new Error("无法创建画布");const t=x-f*2,a=e.images[0]?.src?await ge(e.images[0].src):null,s=a?await xe(a):null,o=s?R:0;n.font=`700 ${A}px ${b}`;const i=U(n,e.title||"未命名文章",t,3),p=i.lines.length*A*N,y=[e.accountName,ye(e.publishTime)].filter(Boolean).join(" · "),h=pe(e.html).slice(0,160);n.font=`400 ${I}px ${b}`;const m=U(n,h,t,5),g=m.lines.length*I*z;let d=o+f;const l=d;d+=p;let v=0;y&&(d+=8,v=d,d+=P),d+=4,d+=8;const c=d;d+=g,d+=12;const u=d;d+=12;const S=d;d+=fe;const M=Math.ceil(d+f);r.width=x,r.height=M,n.fillStyle=me,n.fillRect(0,0,x,M),s&&we(n,s,0,0,x,R),n.textBaseline="top",n.textAlign="left",n.fillStyle=H,n.font=`700 ${A}px ${b}`;const E=i.lines.slice();i.truncated&&(E[E.length-1]=j(n,`${E[E.length-1]}…`,t)),E.forEach((C,_)=>n.fillText(C,f,l+_*A*N)),y&&(n.fillStyle=O,n.font=`400 ${P}px ${b}`,n.fillText(y,f,v)),n.fillStyle=H,n.font=`400 ${I}px ${b}`;const T=m.lines.slice();m.truncated&&(T[T.length-1]=j(n,`${T[T.length-1]}…`,t)),T.forEach((C,_)=>n.fillText(C,f,c+_*I*z)),n.strokeStyle=he,n.lineWidth=1,n.beginPath(),n.moveTo(f,u),n.lineTo(x-f,u),n.stroke(),n.fillStyle=O,n.font=`400 12px ${b}`;const D="由 WeChat to Markdown 导出",F=n.measureText(D).width;return n.fillText(D,x-f-F,S),n.fillText(ve(n,e.sourceUrl,t-F-16),f,S),r.toDataURL("image/png")}function Te(e){return new Promise(r=>{const n=document.createElement("iframe");n.setAttribute("aria-hidden","true"),n.style.cssText="position:fixed;width:0;height:0;border:0;visibility:hidden";const t=a=>{n.remove(),r(a)};n.addEventListener("error",()=>t({success:!1,error:"无法生成打印文档，请刷新页面后重试"})),n.addEventListener("load",()=>{const a=n.contentWindow;if(!a){t({success:!1,error:"无法打开打印窗口"});return}let s=!1;const o=()=>{s||(s=!0,a.removeEventListener("afterprint",o),t({success:!0,message:"请在打印窗口选择「另存为 PDF」"}))};a.addEventListener("afterprint",o),window.setTimeout(()=>{a.focus(),a.print()},300),window.setTimeout(o,300*1e3)}),n.srcdoc=W(e),document.documentElement.append(n)})}function w(){const e=chrome.storage?.local;if(!e)throw new Error("扩展已更新，请刷新当前页面后再试");return e}const Se=["markdown","html","image","pdf"];function Z(e){const r=e.exportFormat;return{downloadImages:e.downloadImages===!0,exportFormat:typeof r=="string"&&Se.includes(r)?r:"markdown"}}function ke(e){return e==="html"?"HTML":e==="image"?"图片":e==="pdf"?"PDF":"Markdown"}function B(e,r){return e.success?r.exportFormat==="image"?"图片已保存":r.exportFormat==="pdf"?"PDF 已交给浏览器打印":r.downloadImages?e.failedImages?`已保存 ${e.downloadedImages} 张，${e.failedImages} 张保留网络地址`:`完整文章已保存 · ${e.downloadedImages} 张图片`:`${ke(r.exportFormat)} 已保存`:e.error}async function Ae(){const e=Z(await w().get(["downloadImages","exportFormat"])),r=Y(),n=V(r);if(e.exportFormat==="pdf")return Te(r);if(e.exportFormat==="image"){const o={type:"EXPORT_ARTICLE",article:r,format:"image",imageDataUrl:await Ee(r),libraryMarkdown:n,downloadImages:!1},i=await chrome.runtime.sendMessage(o);return i.success?{success:!0,message:B(i,e)}:i}const t=e.exportFormat==="html"?W(r):n,a={type:"EXPORT_ARTICLE",article:r,format:e.exportFormat,content:t,libraryMarkdown:n,downloadImages:e.downloadImages},s=await chrome.runtime.sendMessage(a);return s.success?{success:!0,message:B(s,e)}:s}const K=oe(Ae);function qe(){return K.isRunning()}async function Re(){return Z(await w().get(["downloadImages","exportFormat"]))}async function Ne(){try{return await K.run()}catch(e){return{success:!1,error:X(e,"保存失败，请稍后重试")}}}async function Pe(){try{const e=Y();return await chrome.runtime.sendMessage({type:"ARCHIVE_ARTICLE",article:e,markdown:V(e),source:"manual"})??{success:!1,error:"文章库暂时不可用，请刷新页面后重试"}}catch(e){return{success:!1,error:X(e,"加入文章库失败，请稍后重试")}}}async function Ie(){return ne(w(),async(e,r)=>{try{const n=await chrome.runtime.sendMessage({type:"ACTIVATE_LICENSE",credential:e.credential,installationId:r,extensionVersion:chrome.runtime.getManifest().version});return n?.ok?!0:((n?.reason==="not-found"||n?.reason==="expired")&&await re(w()),!1)}catch{return!1}})}async function Ce(e){if(!G)return{ok:!1,reason:"disabled"};const r=e.trim();let n,t;try{n={type:"REDEEM_LICENSE",code:r},t=await chrome.runtime.sendMessage(n)}catch{return{ok:!1,reason:"network"}}return t||{ok:!1,reason:"network"}}async function _e(e){if(!G)return{ok:!1,reason:"disabled"};const r={kind:"code",value:e.value.trim()};let n,t;try{n={type:"ACTIVATE_LICENSE",credential:r,installationId:await ee(w()),extensionVersion:chrome.runtime.getManifest().version},t=await chrome.runtime.sendMessage(n)}catch{return{ok:!1,reason:"unavailable"}}if(!t)return{ok:!1,reason:"network"};if(!t.ok)return t;const a={licensed:!0,credential:r,type:t.type,maxDevices:t.maxDevices,expiresAt:t.expiresAt,activatedAt:Date.now(),checkedAt:Date.now()};try{await te(w(),a)}catch{}return t}const Le=`
  .panel{width:min(350px,calc(100vw - 32px));max-height:min(600px,calc(100vh - 48px));overflow-x:hidden;overflow-y:auto;padding:12px;border:1px solid #dbe5de;border-radius:12px;background:rgba(251,253,251,.99);box-shadow:0 10px 28px rgba(27,48,35,.15);box-sizing:border-box;font-size:11px;line-height:1.5;color:#33443a;font-family:-apple-system,BlinkMacSystemFont,"PingFang SC",sans-serif;scrollbar-width:thin;scrollbar-color:#b8d5c4 transparent}
  .panel[hidden]{display:none}
  .panel-header{display:flex;align-items:center;justify-content:space-between;margin-bottom:6px}
  .panel-title{margin:0;font-weight:700;font-size:13px;color:#16211b}
  .panel-subtitle{margin:-2px 0 8px;color:#607068;font-size:10px}
  .close-btn{border:0;background:transparent;color:#607068;font-size:18px;line-height:1;cursor:pointer;padding:4px;border-radius:4px;transition:background .16s}
  .close-btn:hover{background:#e3ece6;color:#16211b}
  .close-btn:focus-visible{outline:2px solid #a6dbc0;outline-offset:2px}
  .step[hidden]{display:none}
  .plan-compare{overflow:hidden;margin:0 0 9px;border:1px solid #d8e8de;border-radius:9px;background:#fff}
  .plan-row{display:grid;grid-template-columns:78px minmax(0,1fr) minmax(0,1.2fr);align-items:center;min-height:28px;border-top:1px solid #edf2ee}
  .plan-row:first-child{border-top:0;background:#eef6f1;color:#16211b;font-weight:700}
  .plan-row>*{min-width:0;padding:5px 6px;box-sizing:border-box}
  .plan-label{color:#607068}
  .plan-pro{color:#087f4e;font-weight:650}
  .purchase-block{padding:8px;border-radius:9px;background:#f5f8f6;text-align:center}
  .assurances{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));margin:0 0 8px;border:1px solid #d8e8de;border-radius:7px;background:#fff;color:#33443a}
  .assurance{min-width:0;padding:6px 3px;font-size:10px;font-weight:650;white-space:nowrap}
  .assurance+.assurance{border-left:1px solid #e3ece6}
  .assurance::before{content:"✓";margin-right:3px;color:#087f4e;font-weight:800}
  .purchase-label{margin:0 0 5px;color:#33443a;font-size:10px}
  .purchase-guide{margin:5px auto 0;max-width:250px;color:#4d5d54;font-size:10px;overflow-wrap:anywhere}
  .wechat-note{display:block;margin-top:5px;padding:6px 8px;border:1px solid #b8d5c4;border-radius:7px;color:#076b43;background:#fff;font-size:11px;font-weight:700}
  .details{margin:8px 0 0;border-top:1px solid #e3ece6;padding-top:7px;color:#4d5d54}
  .details summary{color:#087f4e;font-weight:650;cursor:pointer;list-style-position:outside;margin-left:14px}
  .details summary:focus-visible{outline:2px solid #a6dbc0;outline-offset:2px;border-radius:3px}
  .details ul{margin:6px 0 0;padding-left:18px}
  .details li+li{margin-top:3px}
  .redeem-title{margin:8px 0 5px;color:#16211b;font-weight:650}
  .input-row{display:flex;gap:6px;margin-top:8px}
  .input-row input{flex:1;min-width:0;padding:7px 9px;border:1px solid #cfdcd3;border-radius:8px;font:12px inherit}
  .input-row input:focus{outline:2px solid #a6dbc0;border-color:#087f4e}
  .input-row button{border:0;border-radius:8px;padding:7px 14px;color:#fff;background:#087f4e;font:700 12px/1.2 inherit;cursor:pointer;font-family:inherit}
  .input-row button:disabled{opacity:.55;cursor:wait}
  .panel-status{min-height:16px;margin:8px 0 0;color:#607068}
  .panel-status.ok{color:#087f4e;font-weight:600}
  .panel-status.error{color:#c62828}
  .device-info{margin-top:6px;font-size:11px;color:#607068}
  .licensed-badge{max-width:280px;padding:7px 12px;border-radius:9px;color:#087f4e;background:#eef6f1;font-size:12px;font-weight:600;font-family:-apple-system,BlinkMacSystemFont,"PingFang SC",sans-serif}
  .licensed-badge[hidden]{display:none}
`;function Me(e){return e===null?"已解锁完整版 · 永久有效":`已解锁完整版 · 有效期至 ${new Date(e*1e3).toLocaleString()}`}function ze(e={}){const r=document.createElement("style");r.textContent=Le;const n=document.createElement("div");n.className="licensed-badge",n.textContent="已解锁完整版 · 感谢支持",n.hidden=!0;const t=document.createElement("div");t.className="panel",t.hidden=!0,t.innerHTML=`
    <div class="panel-header">
      <p class="panel-title">完整版 · ¥${L.launchPriceCny} 永久使用</p>
      <button type="button" class="close-btn" aria-label="关闭">✕</button>
    </div>
    <p class="panel-subtitle">单篇导出继续免费；完整合集、文章库和知识库联动由完整版解锁。</p>

    <div class="plan-compare" aria-label="免费版与完整版功能对比">
      <div class="plan-row"><span>功能</span><span>免费版</span><span class="plan-pro">完整版</span></div>
      <div class="plan-row"><span class="plan-label">单篇导出</span><span>不限次数</span><span class="plan-pro">不限次数</span></div>
      <div class="plan-row"><span class="plan-label">合集导出</span><span>试用 5 篇</span><span class="plan-pro">完整＋增量续传</span></div>
      <div class="plan-row"><span class="plan-label">本地文章库</span><span>—</span><span class="plan-pro">筛选＋合集管理</span></div>
      <div class="plan-row"><span class="plan-label">批量下载</span><span>—</span><span class="plan-pro">MD＋离线图片</span></div>
      <div class="plan-row"><span class="plan-label">知识库联动</span><span>—</span><span class="plan-pro">Obsidian＋思源</span></div>
    </div>
    
    <div class="step" id="step-redeem">
      <div class="purchase-block">
        <div class="assurances" aria-label="购买保障">
          <span class="assurance">永久使用</span>
          <span class="assurance">${L.maxDevices} 台设备</span>
          <span class="assurance">换机协助</span>
        </div>
        <p class="purchase-label">扫码添加作者微信购买</p>
        <img src="${chrome.runtime.getURL("wechat-qr.jpg")}" alt="作者微信二维码" style="display:block;width:96px;height:96px;margin:0 auto;border-radius:7px;border:1px solid #e3ece6">
        <p class="purchase-guide">添加作者微信并完成付款后，将为你发放完整版卡密。</p>
        <strong class="wechat-note">添加好友时请备注：开通会员</strong>
      </div>
      <p class="redeem-title">已有卡密？直接兑换</p>
      <input type="text" id="code-input" placeholder="卡密（如：ABCD-EFGH-JKMN-PQRS）" autocomplete="off" style="width:100%;padding:7px 9px;border:1px solid #cfdcd3;border-radius:8px;font:12px inherit;margin-bottom:6px;box-sizing:border-box">
      <button type="button" id="redeem-btn" style="width:100%;border:0;border-radius:8px;padding:7px 14px;color:#fff;background:#087f4e;font:700 12px/1.2 inherit;cursor:pointer;font-family:inherit">兑换卡密</button>
      <details class="details">
        <summary>展开了解完整版与购买说明</summary>
        <ul>
          <li>适合持续整理公众号文章，需要筛选、批量下载或同步个人知识库的用户。</li>
          <li>支持将所选文章和离线图片写入 Obsidian，或同步到本机思源笔记。</li>
          <li>文章在本机处理，不会上传正文；导出的文件永久保留。</li>
          <li>一次购买可激活 ${L.maxDevices} 台设备，换机或激活异常可直接联系作者处理。</li>
        </ul>
      </details>
    </div>
    
    <div class="step" id="step-activate" hidden>
      <p style="margin:8px 0;color:#33443a;font-size:12px" id="activate-hint">卡密兑换成功，点击下方按钮激活此设备</p>
      <button type="button" id="activate-btn" style="width:100%;border:0;border-radius:8px;padding:7px 14px;color:#fff;background:#087f4e;font:700 12px/1.2 inherit;cursor:pointer;font-family:inherit">激活设备</button>
      <div class="device-info" id="device-info"></div>
    </div>
    
    <p class="panel-status" role="status" aria-live="polite"></p>`,t.prepend(r);let a="";const s=document.createElement("button");s.type="button",s.textContent="解锁完整版";const o=t.querySelector("#code-input"),i=t.querySelector("#redeem-btn"),p=t.querySelector("#activate-btn"),y=t.querySelector(".close-btn"),h=t.querySelector(".panel-status"),m=t.querySelector("#step-redeem"),g=t.querySelector("#step-activate"),d=t.querySelector("#device-info"),l=(c,u="normal")=>{h.textContent=c,h.classList.remove("ok","error"),u==="ok"&&h.classList.add("ok"),u==="error"&&h.classList.add("error")};s.addEventListener("click",()=>{t.hidden=!t.hidden}),y.addEventListener("click",()=>{t.hidden=!0}),i.addEventListener("click",()=>{(async()=>{const c=o.value.trim();if(!c||c.length<8){l("请输入有效的卡密","error");return}i.disabled=!0,l("正在兑换卡密…");try{const u=await Ce(c);if(u.ok)l(u.alreadyLicensed?"该卡密已有授权，可继续激活设备":"兑换成功，请激活设备","ok"),m.hidden=!0,g.hidden=!1,a=u.credential.value;else if(u.reason==="code-not-found")l("卡密不存在，请检查输入或联系客服","error");else if(u.reason==="code-used"){a=c,m.hidden=!0,g.hidden=!1,l("该卡密已兑换，请激活当前设备以恢复授权","ok");const S=t.querySelector("#activate-hint");S.textContent="卡密已兑换。点击下方按钮验证并激活当前设备"}else u.reason==="code-disabled"?l("该卡密已作废，请联系客服","error"):u.reason==="invalid-request"?l("卡密格式不正确，请检查后重新输入","error"):u.reason==="rate-limited"?l("操作过于频繁，请稍后再试","error"):l("网络异常，请稍后重试","error")}finally{i.disabled=!1}})()}),p.addEventListener("click",()=>{(async()=>{p.disabled=!0,l("正在激活设备…");try{const c=await _e({kind:"code",value:a});c.ok?(l("已解锁完整合集，感谢支持","ok"),d.textContent=`设备占用：${c.devicesUsed}/${c.maxDevices}`,n.textContent=Me(c.expiresAt),t.hidden=!0,s.remove(),n.style.display="block",e.onActivated?.()):c.reason==="not-found"?(m.hidden=!1,g.hidden=!0,l("该卡密授权已重置或不存在，请重新兑换后激活","error")):c.reason==="expired"?(m.hidden=!1,g.hidden=!0,l("该卡密已到期，请续费或使用新的卡密","error")):c.reason==="device-limit"?l(`已达 ${c.devicesUsed}/${c.maxDevices} 台设备上限，请在不再使用的设备上停用，或联系客服解绑`,"error"):c.reason==="rate-limited"?l("操作过于频繁，请稍后再试","error"):c.reason==="unavailable"?l("扩展已更新，请刷新当前页面后再试","error"):l("网络异常，请稍后重试","error")}finally{p.disabled=!1}})()});const v={trigger:s,panel:t,badge:n,refresh:async()=>{const c=await Ie().catch(()=>!1);s.style.display=c?"none":"",n.style.display=c?"block":"none",c&&(t.hidden=!0)}};return v.refresh(),v}export{w as a,$e as b,Pe as c,X as d,Y as e,ze as f,qe as g,Ie as h,Fe as i,oe as j,le as k,Re as r,Ne as s};
