import{h as Me,d as me,j as ee,k as ce,A as te,i as ge,e as D,l as be,m as G,s as Be,u as ke,n as xe,o as Se,p as Le,q as Fe,t as Ie,v as Pe,a as Te}from"./html-CTsso1Bm.js";import{i as qe,e as $e,a as A,r as Ne,b as _e,c as Re,d as Q,f as Ce,g as Ue,s as he,h as ne,j as ye,k as He}from"./license-panel--yMiZs7h.js";import{C as Oe,r as re,v as ze,f as De,I as je,g as Ye}from"./release-CJxG1UBU.js";const Ve=2;function Ae(t){return t.replace(/\s+/g," ").trim()}function We(t){const o=[];let r="";for(const c of t){const l=Ae(c.text);if(!l||l===r)continue;const x=Math.min(6,Math.max(1,Math.round(c.level)||1));o.push({level:x,text:l}),r=l}return o}function Ke(t){return We(t).length>=Ve}const Xe=`
  :host{all:initial;display:block}
  *{box-sizing:border-box}
  .notice{position:relative;margin:0;padding:12px 13px 13px;border:1px solid #cfe1d5;border-left:4px solid #087f4e;border-radius:10px;color:#33443a;background:#f7fbf8;box-shadow:0 5px 15px rgba(27,48,35,.08);font-family:-apple-system,BlinkMacSystemFont,"PingFang SC",sans-serif;animation:notice-in .18s ease-out}
  .topline{display:flex;align-items:center;justify-content:space-between;gap:10px;margin:0 28px 6px 0}
  .eyebrow{margin:0;color:#087f4e;font:700 10px/1 ui-monospace,SFMono-Regular,Menlo,monospace;letter-spacing:.06em}
  .version{flex:none;padding:3px 6px;border-radius:999px;color:#087f4e;background:#e3f2e8;font:700 10px/1 ui-monospace,SFMono-Regular,Menlo,monospace}
  h3{margin:0;color:#16211b;font:700 13px/1.45 -apple-system,BlinkMacSystemFont,"PingFang SC",sans-serif}
  .summary{margin:5px 0 0;color:#4f6056;font:400 12px/1.55 -apple-system,BlinkMacSystemFont,"PingFang SC",sans-serif}
  .hint{margin:7px 0 0;color:#728078;font:400 10px/1.5 -apple-system,BlinkMacSystemFont,"PingFang SC",sans-serif}
  .actions{display:flex;flex-wrap:wrap;align-items:center;gap:7px;margin-top:10px}
  a,.ignore{display:inline-flex;align-items:center;justify-content:center;min-height:30px;border-radius:8px;padding:7px 10px;font:600 11px/1 -apple-system,BlinkMacSystemFont,"PingFang SC",sans-serif;text-decoration:none;cursor:pointer}
  .primary{border:1px solid #087f4e;color:#fff;background:#087f4e}
  .primary:hover{background:#066d43}
  .secondary{border:1px solid #cfe1d5;color:#087f4e;background:#fff}
  .secondary:hover{background:#eef6f1}
  .ignore{border:0;color:#607068;background:transparent}
  .ignore:hover{color:#24352b;background:#e9f2ec}
  .ignore:disabled{opacity:.55;cursor:wait}
  .dismiss{position:absolute;top:7px;right:7px;display:grid;width:28px;height:28px;place-items:center;border:0;border-radius:7px;color:#607068;background:transparent;font:700 15px/1 -apple-system,BlinkMacSystemFont,"PingFang SC",sans-serif;cursor:pointer}
  .dismiss:hover{color:#16211b;background:#e9f2ec}
  a:focus-visible,button:focus-visible{outline:3px solid #a6dbc0;outline-offset:2px}
  .feedback{min-height:14px;margin:7px 0 0;color:#a33b32;font:400 10px/1.4 -apple-system,BlinkMacSystemFont,"PingFang SC",sans-serif}
  @keyframes notice-in{from{opacity:0;transform:translateY(-3px)}to{opacity:1;transform:translateY(0)}}
  @media (prefers-reduced-motion:reduce){.notice{animation:none}}
`;function Ge(t){return typeof t=="object"&&t!==null&&!Array.isArray(t)}function Qe(t){const o=t.channel==="store",r=o?t.storeUrl:t.offlineDownloadUrl,c=t.guideUrl&&t.guideUrl!==r?t.guideUrl:void 0;return{eyebrow:t.noticeLevel==="required"?"需要更新":"新版可用",primaryLabel:o?"打开扩展商店":"下载新版 ZIP",primaryUrl:r,...c?{secondaryLabel:"查看更新步骤",secondaryUrl:c}:{},channelHint:o?"商店版通常会自动更新；打开商店可立即查看新版本。":"离线版需手动更新：解压覆盖原目录，再到扩展管理页点击“重新加载”。",canIgnore:t.noticeLevel!=="required"}}async function Ze(t){try{const o=await chrome.runtime.sendMessage({type:je,version:t});return o?.ok===!0&&o.ignored===!0}catch{return!1}}function Je(t){if(!Ge(t))return;const o=chrome.runtime.getManifest().version;if(t.currentVersion!==o||t.channel!==re.channel)return;const r=ze(t,{channel:re.channel,trustedOrigins:re.trustedOrigins});return r?De(r,o,re.channel):void 0}async function et(){try{const t=await chrome.runtime.sendMessage({type:Oe});return t?.ok!==!0?void 0:Je(t.update)}catch{return}}function tt(t,o={}){const r=Qe(t),c=document.createElement("div");c.dataset.wechatToMarkdownUpdate=t.latestVersion;const l=c.attachShadow({mode:"open"});l.innerHTML=`
    <style>${Xe}</style>
    <section class="notice" role="region" aria-live="polite" aria-labelledby="wtm-update-title">
      <button class="dismiss" type="button" aria-label="暂时关闭更新提示">×</button>
      <div class="topline">
        <p class="eyebrow"></p>
        <span class="version"></span>
      </div>
      <h3 id="wtm-update-title"></h3>
      <p class="summary"></p>
      <p class="hint"></p>
      <div class="actions"></div>
      <p class="feedback" role="status" aria-live="polite"></p>
    </section>`,l.querySelector(".eyebrow").textContent=r.eyebrow,l.querySelector(".version").textContent=`v${t.latestVersion}`,l.querySelector("h3").textContent=t.title,l.querySelector(".summary").textContent=t.summary,l.querySelector(".hint").textContent=r.channelHint;const x=l.querySelector(".actions"),I=l.querySelector(".feedback");if(r.primaryUrl){const a=document.createElement("a");a.className="primary",a.href=r.primaryUrl,a.target="_blank",a.rel="noopener noreferrer",a.textContent=r.primaryLabel,x.append(a)}if(r.secondaryUrl&&r.secondaryLabel){const a=document.createElement("a");a.className="secondary",a.href=r.secondaryUrl,a.target="_blank",a.rel="noopener noreferrer",a.textContent=r.secondaryLabel,x.append(a)}const n=()=>{c.remove(),o.onDismiss?.()};if(l.querySelector(".dismiss").addEventListener("click",n),r.canIgnore){const a=document.createElement("button");a.type="button",a.className="ignore",a.textContent="忽略此版本",a.addEventListener("click",()=>{(async()=>(a.disabled=!0,I.textContent="",await(o.onIgnore??Ze)(t.latestVersion)?n():(a.disabled=!1,I.textContent="暂时无法保存此设置，请稍后再试。")))()}),x.append(a)}return{element:c,focus:()=>l.querySelector(".primary, .secondary, .dismiss")?.focus(),remove:n}}async function nt(t){const o=await et();if(!o)return;const r=tt(o);return t.appendChild(r.element),r}const rt=90;function ot(t={}){if(!qe()||document.querySelector("#wechat-to-markdown-reader-entry"))return;const o=document.querySelector("#js_content");if(!o)return;const r=[...o.querySelectorAll("h1, h2, h3, h4, h5, h6")],c=[];let l="";for(const e of r){const i=Ae(e.textContent||"");!i||i===l||(l=i,c.push({level:Math.min(6,Math.max(1,Math.round(Number(e.tagName.slice(1)))||1)),text:i,element:e}))}const x=Ke(r.map(e=>({level:Number(e.tagName.slice(1)),text:e.textContent||""}))),I=document.createElement("div");I.id="wechat-to-markdown-reader-entry";const n=I.attachShadow({mode:"closed"});n.innerHTML=`
    <style>
      :host { all: initial; }
      * { box-sizing: border-box; }
      button { font-family: inherit; }
      .trigger {
        position: fixed; right: 30px; top: 50%; transform: translateY(-50%);
        z-index: 2147483646; display: grid; place-items: center;
        width: 30px; height: 56px; border: 0; border-radius: 12px;
        color: #fff; background: #087f4e; box-shadow: 0 9px 25px rgba(5, 67, 40, .27);
        font: 700 18px/1 -apple-system, BlinkMacSystemFont, "PingFang SC", sans-serif;
        cursor: pointer;
        transition: opacity .18s ease, transform .18s ease;
      }
      .trigger:hover { background: #066d43; }
      .trigger:focus-visible { outline: 3px solid #a6dbc0; outline-offset: 3px; }
      .trigger.hidden { opacity: 0; pointer-events: none; }
      .drawer {
        position: fixed; top: 72px; bottom: 20px; right: 30px; height: auto; width: 280px; max-width: 85vw;
        z-index: 2147483647; display: flex; flex-direction: column;
        color: #24352b; background: #fbfdfb; border-radius: 14px;
        box-shadow: 0 8px 30px rgba(27, 48, 35, .18);
        font-family: -apple-system, BlinkMacSystemFont, "PingFang SC", sans-serif;
        transform: translateX(calc(100% + 34px)); transition: transform .22s ease;
      }
      .drawer.open { transform: translateX(0); }
      .header { display: flex; align-items: center; justify-content: space-between; gap: 10px; padding: 14px 14px 12px; border-bottom: 1px solid #e3ece6; }
      .brand { display: flex; align-items: center; gap: 10px; min-width: 0; }
      .mark { display: grid; flex: none; width: 34px; height: 34px; place-items: center; border-radius: 10px 4px 10px 4px; color: #fff; background: #087f4e; box-shadow: 0 6px 14px rgba(8, 127, 78, .2); font: 400 18px/1 STSong, SimSun, serif; }
      .eyebrow { margin: 0 0 2px; color: #77847c; font: 600 8px/1 ui-monospace, monospace; letter-spacing: .14em; }
      .brand h2 { margin: 0; color: #16211b; font: 700 15px/1.2 -apple-system, BlinkMacSystemFont, "PingFang SC", sans-serif; letter-spacing: .03em; }
      .close { display: grid; flex: none; width: 30px; height: 30px; place-items: center; border: 0; border-radius: 8px; color: #607068; background: transparent; font: 700 15px/1 -apple-system, BlinkMacSystemFont, "PingFang SC", sans-serif; cursor: pointer; }
      .close:hover { background: #eef4f0; }
      .close:focus-visible { outline: 3px solid #a6dbc0; outline-offset: 1px; }
      .archive { padding: 14px 14px 12px; border-bottom: 1px solid #e3ece6; }
      .status { display: flex; align-items: center; gap: 7px; margin: 0 0 10px; color: #087f4e; font: 600 11px/1 -apple-system, BlinkMacSystemFont, "PingFang SC", sans-serif; }
      .status::before { content: ""; width: 6px; height: 6px; border-radius: 50%; background: #08a864; box-shadow: 0 0 0 4px #def4e8; }
      .article-title { margin: 0; color: #16211b; font: 700 16px/1.5 STSong, SimSun, serif; display: -webkit-box; -webkit-line-clamp: 3; -webkit-box-orient: vertical; overflow: hidden; }
      .account { margin: 6px 0 12px; color: #728078; font: 400 12px/1.4 -apple-system, BlinkMacSystemFont, "PingFang SC", sans-serif; }
      .archive-option { position: relative; display: flex; align-items: center; justify-content: space-between; gap: 12px; margin-bottom: 10px; padding: 10px 12px; border: 1px solid #dce6df; border-radius: 10px; background: #f4f8f5; cursor: pointer; }
      .archive-option strong, .archive-option small { display: block; }
      .archive-option strong { color: #24352b; font: 600 12px/1.3 -apple-system, BlinkMacSystemFont, "PingFang SC", sans-serif; }
      .archive-option small { margin-top: 3px; color: #77847c; font: 400 10px/1.4 -apple-system, BlinkMacSystemFont, "PingFang SC", sans-serif; }
      .archive-option input { position: absolute; width: 1px; height: 1px; opacity: 0; }
      .switch { position: relative; flex: 0 0 36px; width: 36px; height: 20px; border-radius: 999px; background: #b9c4bd; transition: background .16s ease; }
      .switch::after { content: ""; position: absolute; left: 3px; top: 3px; width: 14px; height: 14px; border-radius: 50%; background: #fff; box-shadow: 0 1px 3px rgba(0, 0, 0, .2); transition: transform .16s ease; }
      .archive-option input:checked + .switch { background: #087f4e; }
      .archive-option input:checked + .switch::after { transform: translateX(16px); }
      .archive-option input:focus-visible + .switch { outline: 3px solid #a6dbc0; outline-offset: 2px; }
      .segmented { display: flex; flex: none; border: 1px solid #cfdcd3; border-radius: 999px; background: #fff; overflow: hidden; }
      .option-stack { flex-direction: column; align-items: stretch; }
      .option-stack .segmented { margin-top: 8px; width: 100%; }
      .segment { flex: 1 1 0; min-width: 0; border: 0; padding: 6px 2px; color: #4a5950; background: transparent; font: 600 10px/1 -apple-system, BlinkMacSystemFont, "PingFang SC", sans-serif; text-align: center; cursor: pointer; transition: background .16s ease, color .16s ease; }
      .segment + .segment { border-left: 1px solid #e3ece6; }
      .segment:hover { background: #f1f7f3; }
      .segment.active { color: #fff; background: #087f4e; }
      .segment:focus-visible { outline: 3px solid #a6dbc0; outline-offset: -1px; }
      .archive-option.is-hidden { display: none; }
      .save-archive { display: flex; width: 100%; align-items: center; justify-content: space-between; border: 0; border-radius: 10px; padding: 12px 14px; color: #fff; background: #087f4e; font: 600 14px/1 -apple-system, BlinkMacSystemFont, "PingFang SC", sans-serif; cursor: pointer; transition: background .16s ease; }
      .save-archive:hover { background: #066d43; }
      .save-archive:focus-visible { outline: 3px solid #a6dbc0; outline-offset: 2px; }
      .save-archive:disabled { opacity: .62; cursor: wait; }
      .library-actions { display: grid; grid-template-columns: 1fr auto; gap: 8px; margin-top: 8px; }
      .library-actions[hidden] { display: none; }
      .archive-library, .open-library { min-height: 38px; border: 1px solid #b9d5c4; border-radius: 9px; color: #087f4e; background: #f7fbf8; font: 600 12px/1 -apple-system, BlinkMacSystemFont, "PingFang SC", sans-serif; cursor: pointer; }
      .archive-library { padding: 0 12px; text-align: left; }
      .open-library { width: 38px; padding: 0; font-size: 17px; }
      .archive-library:hover, .open-library:hover { background: #eaf5ed; }
      .archive-library:focus-visible, .open-library:focus-visible { outline: 3px solid #a6dbc0; outline-offset: 2px; }
      .archive-library:disabled { cursor: wait; opacity: .62; }
      .feedback { min-height: 15px; margin: 8px 0 0; color: #607068; font: 400 11px/1.4 -apple-system, BlinkMacSystemFont, "PingFang SC", sans-serif; text-align: center; }
      .export-settings { border-top: 1px solid #e3ece6; margin-top: 10px; }
      .export-settings-toggle { display: flex; align-items: center; justify-content: space-between; width: 100%; padding: 10px 14px; border: 0; background: transparent; color: #77847c; font: 600 11px/1 -apple-system, BlinkMacSystemFont, "PingFang SC", sans-serif; cursor: pointer; }
      .export-settings-toggle:hover { color: #4a5950; }
      .export-settings-toggle .chevron { transition: transform .2s ease; }
      .export-settings-toggle[aria-expanded="true"] .chevron { transform: rotate(180deg); }
      .export-settings-content { display: none; padding: 0 14px 12px; }
      .export-settings-content[aria-hidden="false"] { display: block; }
      .toc-label { padding: 10px 14px 2px; color: #77847c; font: 600 11px/1.4 -apple-system, BlinkMacSystemFont, "PingFang SC", sans-serif; }
      .list { flex: 1; overflow-y: auto; padding: 8px 8px 12px; }
      .item { display: block; width: 100%; padding: 9px 10px; border: 0; border-radius: 8px; color: #4a5950; background: transparent; font: 400 13px/1.5 -apple-system, BlinkMacSystemFont, "PingFang SC", sans-serif; text-align: left; cursor: pointer; }
      .item:hover { background: #f1f7f3; color: #24352b; }
      .item:focus-visible { outline: 3px solid #a6dbc0; outline-offset: 1px; }
      .item.active { color: #087f4e; background: #eef6f1; font-weight: 600; }
      .empty { margin: 24px 16px; padding: 18px 14px; border: 1px dashed #d8e3dc; border-radius: 10px; color: #77847c; font: 400 13px/1.6 -apple-system, BlinkMacSystemFont, "PingFang SC", sans-serif; text-align: center; }
      .albums { display: grid; gap: 6px; padding: 8px 14px 10px; border-top: 1px solid #e3ece6; }
      .albums:empty { display: none; }
      .albums .label { color: #77847c; font: 400 11px/1.4 -apple-system, BlinkMacSystemFont, "PingFang SC", sans-serif; }
      .album { display: flex; align-items: center; justify-content: space-between; gap: 8px; width: 100%; padding: 8px 10px; border: 1px solid #d8e8de; border-radius: 9px; color: #087f4e; background: #f4faf6; font: 600 12px/1.4 -apple-system, BlinkMacSystemFont, "PingFang SC", sans-serif; text-align: left; cursor: pointer; }
      .album:hover { background: #e9f5ec; }
      .album:focus-visible { outline: 3px solid #a6dbc0; outline-offset: 1px; }
      .album .arrow { flex: none; color: #5f8a72; }
      .updates { padding: 8px 14px 10px; border-top: 1px solid #e3ece6; }
      .updates:empty { display: none; }
      .footer { padding: 10px 14px 14px; border-top: 1px solid #e3ece6; }
      .action { display: flex; width: 100%; align-items: center; justify-content: center; gap: 6px; padding: 10px 12px; border: 0; border-radius: 10px; color: #087f4e; background: #eef6f1; font: 600 13px/1 -apple-system, BlinkMacSystemFont, "PingFang SC", sans-serif; cursor: pointer; }
      .action:hover { background: #e3f0e7; }
      .action:focus-visible { outline: 3px solid #a6dbc0; outline-offset: 2px; }
      .toast {
        position: fixed; right: 16px; bottom: 20px; z-index: 2147483647;
        max-width: 260px; padding: 9px 12px; border: 1px solid #dbe5de; border-radius: 9px;
        color: #33443a; background: rgba(251, 253, 251, .97); box-shadow: 0 7px 20px rgba(27, 48, 35, .12);
        font: 400 12px/1.5 -apple-system, BlinkMacSystemFont, "PingFang SC", sans-serif;
        opacity: 0; pointer-events: none; transition: opacity .16s ease;
      }
      .toast.show { opacity: 1; }
      @media (prefers-reduced-motion: reduce) { .trigger, .drawer, .toast { transition: none; } }
    </style>
    <button class="trigger hidden" type="button" aria-label="展开文章存档面板" aria-expanded="true">‹</button>
    <aside class="drawer open" aria-hidden="false">
      <header class="header">
        <div class="brand">
          <div class="mark" aria-hidden="true">文</div>
          <div>
            <p class="eyebrow">WECHAT · MARKDOWN</p>
            <h2>文章存档</h2>
          </div>
        </div>
        <button class="close" type="button" aria-label="收起面板">›</button>
      </header>
      <section class="archive" aria-label="文章存档">
        <p class="status">已识别微信公众号文章</p>
        <h3 class="article-title"></h3>
        <p class="account"></p>
        <button class="save-archive" type="button">
          <span class="save-label">保存 Markdown</span>
          <span aria-hidden="true">↓</span>
        </button>
        <div class="library-actions">
          <button class="archive-library" type="button">☆ 加入本地文章库</button>
          <button class="open-library" type="button" aria-label="打开本地文章库" title="打开本地文章库">›</button>
        </div>
        <p class="feedback" role="status" aria-live="polite"></p>
        <div class="export-settings">
          <button class="export-settings-toggle" type="button" aria-expanded="false">
            <span>导出设置</span>
            <span class="chevron" aria-hidden="true">▼</span>
          </button>
          <div class="export-settings-content" aria-hidden="true">
            <div class="archive-option option-stack">
              <span>
                <strong>导出类型</strong>
                <small class="format-desc">Markdown · 适合笔记与知识库</small>
              </span>
              <span class="segmented" role="radiogroup" aria-label="导出类型">
                <button class="segment active" type="button" data-format="markdown" role="radio" aria-checked="true">MD</button>
                <button class="segment" type="button" data-format="html" role="radio" aria-checked="false">HTML</button>
                <button class="segment" type="button" data-format="image" role="radio" aria-checked="false">图片</button>
                <button class="segment" type="button" data-format="pdf" role="radio" aria-checked="false">PDF</button>
              </span>
            </div>
            <label class="archive-option download-option">
              <span>
                <strong>下载文章图片</strong>
                <small>导出 ZIP，离线阅读不依赖网络</small>
              </span>
              <input class="download-images" type="checkbox" role="switch" />
              <span class="switch" aria-hidden="true"></span>
            </label>
          </div>
        </div>
      </section>
      <p class="toc-label">文章目录</p>
      <nav class="list" aria-label="文章目录"></nav>
      <section class="albums" aria-label="所属合集"></section>
      <section class="updates" aria-label="扩展更新"></section>
      <footer class="footer">
        <button class="action back-top" type="button">↑ 返回顶部</button>
        <button class="action community" type="button">反馈 / 交流群</button>
      </footer>
    </aside>
    <div class="toast" role="status" aria-live="polite"></div>`;const a=n.querySelector(".trigger"),b=n.querySelector(".drawer"),w=n.querySelector(".close"),_=n.querySelector(".back-top"),U=n.querySelector(".community"),H=n.querySelector(".save-archive"),q=n.querySelector(".save-label");n.querySelector(".library-actions");const $=n.querySelector(".archive-library"),j=n.querySelector(".open-library"),O=n.querySelector(".download-images"),d=n.querySelector(".download-option"),h=n.querySelector(".format-desc"),u=[...n.querySelectorAll(".segment")],y=n.querySelector(".feedback"),v=n.querySelector(".toast"),s=n.querySelector(".list"),f=n.querySelector(".albums"),S=n.querySelector(".updates"),P=n.querySelector(".export-settings-toggle"),E=n.querySelector(".export-settings-content");try{const e=$e();n.querySelector(".article-title").textContent=e.title,n.querySelector(".account").textContent=e.accountName||"公众号文章"}catch{n.querySelector(".article-title").textContent=document.title,n.querySelector(".account").textContent="公众号文章"}let g="markdown",p;function k(){if(g==="image"){q.textContent="保存图片";return}if(g==="pdf"){q.textContent="导出 PDF";return}if(O.checked){q.textContent="保存完整文章";return}q.textContent=g==="html"?"保存 HTML":"保存 Markdown"}function R(e,i=!0){g=e;for(const F of u){const N=F.dataset.format===e;F.classList.toggle("active",N),F.setAttribute("aria-checked",String(N))}const m={markdown:"Markdown · 适合笔记与知识库",html:"HTML · 保留原文排版，可直接浏览",image:"图片 · 生成一张分享卡片 PNG",pdf:"PDF · 浏览器打印，版式还原"};h.textContent=m[e],d.classList.toggle("is-hidden",e==="image"||e==="pdf"),k(),i&&A().set({exportFormat:e})}for(const e of u)e.addEventListener("click",()=>{const i=e.dataset.format;R(i==="markdown"||i==="html"||i==="image"||i==="pdf"?i:"markdown")});O.addEventListener("change",()=>{k(),A().set({downloadImages:O.checked})}),P.addEventListener("click",()=>{const e=P.getAttribute("aria-expanded")==="true";P.setAttribute("aria-expanded",String(!e)),E.setAttribute("aria-hidden",String(e))}),Ne().then(e=>{O.checked=e.downloadImages,R(e.exportFormat,!1),k()}).catch(()=>{});const T=_e();if(T.length>0){const e=document.createElement("div");e.className="label",e.textContent="本文收录于合集",f.append(e);for(const i of T){const m=document.createElement("button");m.type="button",m.className="album";const F=document.createElement("span");F.textContent=i.title;const N=document.createElement("span");N.className="arrow",N.textContent="›",m.append(F,N),m.addEventListener("click",()=>{window.open(i.url,"_blank","noopener,noreferrer")}),f.append(m)}}let B=-1,C=!0,L;const Y=[];if(x)c.forEach((e,i)=>{const m=document.createElement("button");m.type="button",m.className="item",m.style.paddingLeft=`${10+(e.level-1)*14}px`,m.textContent=e.text,m.addEventListener("click",()=>{e.element.scrollIntoView({behavior:"smooth",block:"start"}),Z(i)}),s.append(m),Y.push(m)});else{const e=document.createElement("p");e.className="empty",e.textContent="本文未使用标题结构，暂无目录",s.append(e)}function Z(e){if(e!==B&&(B>=0&&Y[B]?.classList.remove("active"),B=e,B>=0)){const i=Y[B];i?.classList.add("active"),i?.scrollIntoView({block:"nearest"})}}function z(){let e=-1;for(let i=0;i<c.length;i+=1){const m=c[i];if(!m)break;if(m.element.getBoundingClientRect().top<=rt)e=i;else break}Z(e)}function V(e=!1){C||(C=!0,b.classList.add("open"),b.setAttribute("aria-hidden","false"),a.classList.add("hidden"),a.setAttribute("aria-expanded","true"),e&&w.focus(),z())}function W(){C&&(C=!1,b.classList.remove("open"),b.setAttribute("aria-hidden","true"),a.classList.remove("hidden"),a.setAttribute("aria-expanded","false"),n.activeElement&&b.contains(n.activeElement)&&a.focus())}function M(e){y.textContent=e,!C&&(v.textContent=e,v.classList.add("show"),L&&window.clearTimeout(L),L=window.setTimeout(()=>v.classList.remove("show"),5e3))}async function J(){if(Ue())return M("正在保存，请稍候…"),he();H.disabled=!0,q.textContent="保存中…";try{M(g==="pdf"?"正在打开打印窗口…":g==="image"?"正在生成分享图片…":O.checked?"正在下载图片并打包…":g==="html"?"正在生成 HTML…":"正在生成 Markdown…");const e=await he();return M(e.success?e.message||"已保存":e.error),e}catch(e){const i=Q(e,"保存失败，请稍后重试");return M(i),{success:!1,error:i}}finally{H.disabled=!1,k()}}a.addEventListener("click",()=>C?W():V(!0)),w.addEventListener("click",W),_.addEventListener("click",()=>{window.scrollTo({top:0,behavior:"smooth"})}),U.addEventListener("click",()=>{chrome.runtime.sendMessage({type:"OPEN_FEEDBACK"})}),H.addEventListener("click",()=>{J()}),$.addEventListener("click",()=>{(async()=>{$.disabled=!0,$.textContent="正在加入…";const e=await Re();e.success?($.textContent=e.data?.created===!1?"✓ 已更新文章库快照":"✓ 已加入文章库",M(e.data?.created===!1?"文章库中的正文快照已更新":"已加入本地文章库，可按公众号、日期和归档合集整理")):($.textContent="☆ 加入本地文章库",M(e.error),e.reason==="not-licensed"&&p&&(p.panel.hidden=!1)),$.disabled=!1})().catch(e=>{$.disabled=!1,$.textContent="☆ 加入本地文章库",M(Q(e,"加入文章库失败，请刷新页面后再试"))})}),j.addEventListener("click",()=>{(async()=>{const e={type:"OPEN_LIBRARY"},i=await chrome.runtime.sendMessage(e);i?.success||M(i?.error??"文章库暂时无法打开，请刷新页面后重试")})().catch(e=>{M(Q(e,"文章库暂时无法打开，请刷新页面后重试"))})}),window.addEventListener("keydown",e=>{e.key==="Escape"&&C&&W()});let K=!1;window.addEventListener("scroll",()=>{K||(K=!0,window.requestAnimationFrame(()=>{K=!1,C&&z()}))},{passive:!0});{p=Ce({onActivated:()=>M("已解锁完整版，合集可完整归档")}),p.trigger.className="action",p.trigger.style.marginBottom="8px",p.panel.style.width="auto",p.panel.style.minHeight="0",p.panel.style.margin="0 14px 8px",p.badge.style.margin="0 14px 8px";const e=n.querySelector(".footer");e.prepend(p.trigger),b.insertBefore(p.badge,e),b.insertBefore(p.panel,e)}return nt(S),t.onQuickSave?.(()=>J()),z(),document.documentElement.append(I),{open:()=>V(!0)}}let pe,oe,ae,ue;function le(t,o){return t.then(o).catch(r=>o({success:!1,error:Q(r,"扩展操作失败，请刷新页面后再试")})),!0}async function we(t){const o=await chrome.runtime.sendMessage(t);if(!o)throw new Error("扩展没有返回文章库结果，请重新加载扩展后再试");if(!o.success)throw new Error(o.error);return o.data}chrome.runtime.onMessage.addListener((t,o,r)=>t.type==="OPEN_DRAWER"?ue?(ue.open(),r({success:!0}),!1):(r({success:!1,error:"当前页面没有存档面板"}),!1):t.type==="QUICK_SAVE"?pe?le(pe(),r):(r({success:!1,error:"请打开一篇微信公众号文章后再试"}),!1):t.type==="DOWNLOAD_ALBUM"?oe?le(oe(),r):(r({success:!1,error:"请打开微信公众号合集页面后再试"}),!1):t.type==="RESTART_ALBUM"?ae?le(ae(),r):(r({success:!1,error:"请打开微信公众号合集页面后再试"}),!1):!1);const se=t=>new Promise(o=>window.setTimeout(o,t));async function ve(t,o=Number.POSITIVE_INFINITY){const r=new URL(location.href).searchParams.get("__biz");if(!r)throw new Error("合集链接缺少公众号标识");const c=[],l=new Set;let x=!0;for(;x&&c.length<o;){const I=c.at(-1),n=Math.min(10,o-c.length),a=await fetch(Fe(r,t.id,I,n,t.ascending),{credentials:"omit",referrerPolicy:"no-referrer"});if(!a.ok)throw new Error(`合集列表读取失败（HTTP ${a.status}）`);const b=Ie(await a.json());let w=0;for(const _ of b.articles){const U=Se(_);if(!l.has(U)&&(l.add(U),c.push(_),w+=1,c.length>=o))break}if(x=b.continueFlag,x&&w===0)throw new Error("合集分页没有返回新文章，请稍后重试");await se(250)}if(!Pe(c,t.ascending))throw new Error("微信返回的合集序号不连续，请刷新页面后重试");return c}async function de(t){for(let o=0;o<3;o+=1)try{const r=await fetch(t.url,{credentials:"omit",referrerPolicy:"no-referrer"});if(!r.ok){if((r.status===429||r.status>=500)&&o<2){await se(500*2**o);continue}throw new Error(`文章读取失败（HTTP ${r.status}）：${t.title}`)}const c=new DOMParser().parseFromString(await r.text(),"text/html"),l=He(c,t.url);return l.publishTime||(l.publishTime=ke(t.createTime)),{article:l,markdown:Te(l)}}catch(r){if(r instanceof Error&&r.message.startsWith("文章读取失败")||o>=2)throw r;await se(500*2**o)}throw new Error(`文章读取失败：${t.title}`)}function at(){if(!Me()||document.querySelector("#wechat-to-markdown-album-entry")||!me)return;let t;try{t=ee()}catch{return}const o=document.createElement("div");o.id="wechat-to-markdown-album-entry";const r=o.attachShadow({mode:"closed"});r.innerHTML=`<style>
    :host{all:initial}.wrap{position:fixed;right:22px;bottom:148px;z-index:2147483647;display:grid;justify-items:end;gap:9px;width:min(310px,calc(100vw - 28px));font-family:-apple-system,BlinkMacSystemFont,"PingFang SC",sans-serif}
    .card{width:100%;padding:13px;border:1px solid #d3e4da;border-radius:14px;background:rgba(253,255,253,.98);box-shadow:0 14px 38px rgba(19,58,36,.18)}
    .head{display:flex;align-items:center;gap:9px;margin:0 1px 10px}.mark{display:grid;flex:none;width:30px;height:30px;place-items:center;border-radius:9px;color:#087f4e;background:#e5f3ea}.mark svg{width:18px;height:18px;fill:none;stroke:currentColor;stroke-width:1.7;stroke-linecap:round;stroke-linejoin:round}.title{display:grid;gap:2px;min-width:0}.title strong{color:#183b29;font-size:13px;line-height:1.2}.title small{color:#77847c;font-size:10px;line-height:1.2;letter-spacing:.05em}
    button{border:0;font:700 13px/1.2 inherit;cursor:pointer}button:focus-visible{outline:3px solid #a6dbc0;outline-offset:2px}button:disabled{cursor:wait;opacity:.55}button[hidden]{display:none}
    #download{width:100%;min-height:42px;border-radius:10px;padding:11px 14px;color:#fff;background:#087f4e;box-shadow:0 7px 18px rgba(5,67,40,.22)}#download:hover{background:#076f45}
    #library{width:100%;min-height:38px;margin-top:8px;border:1px solid #9bcdb2;border-radius:10px;padding:9px 12px;color:#087f4e;background:#f0f8f3}#library:hover{background:#e5f3ea}
    .secondary-actions{display:flex;align-items:center;justify-content:flex-end;gap:7px;margin-top:8px}.secondary-actions:empty{display:none}button.secondary{min-height:32px;border:1px solid #d7e5dc;border-radius:8px;padding:7px 10px;color:#597065;background:#f5f8f6;box-shadow:none;font-size:11px}button.secondary:hover{color:#087f4e;background:#ebf4ee}
    .note{display:none;margin:0 0 10px;padding:9px 10px;border-left:3px solid #53a477;border-radius:4px 8px 8px 4px;color:#3f5147;background:#f2f7f4;font-size:11px;line-height:1.55}.note.show{display:block}
    @media (prefers-reduced-motion:no-preference){#download,.secondary{transition:background .16s ease,color .16s ease,transform .16s ease}#download:active{transform:translateY(1px)}}
  </style><div class="wrap"><section class="card" aria-label="合集归档"><header class="head"><span class="mark"><svg viewBox="0 0 24 24" aria-hidden="true"><path d="M5 5.5h10.5L19 9v10H5z"/><path d="M15.5 5.5V9H19M8 13h8m-8 3h6"/></svg></span><span class="title"><strong>合集归档</strong><small>LOCAL ARCHIVE</small></span></header><div class="note" role="status" aria-live="polite"></div><button id="download" type="button">下载合集</button><button id="library" type="button" hidden>加入文章库</button><div class="secondary-actions"><button id="restart" class="secondary" type="button">重新导出全部</button></div></section></div>`;const c=r.querySelector("#download"),l=r.querySelector("#library"),x=r.querySelector("#restart"),I=r.querySelector(".note"),n=d=>{I.textContent=d,I.classList.add("show")};let a;if(me){a=Ce({onActivated:()=>{_(!0,!0).catch(()=>n("已解锁完整版，可归档完整合集"))}}),a.trigger.className="secondary action license-trigger";const d=r.querySelector(".wrap");d.prepend(a.badge,a.panel),d.querySelector(".secondary-actions").append(a.trigger)}let b=!1;const w=()=>Math.max(t.articleCount,t.articles.length);async function _(d,h){const u=h??await ne().catch(()=>!1),y=u?{}:await A().get(te),v=!u&&ge(y[te]),s=w();if(x.hidden=!u,l.hidden=!u,u)c.textContent="下载新增文章",d&&n(`检测到 ${s} 篇 · 完整版只导出上次归档后新增的文章，省去逐篇检查`);else if(v){const f=Math.max(s-Math.min(D,s),0);c.textContent=f>0?`解锁剩余 ${f} 篇`:"解锁完整版",d&&n(`已免费保存 ${Math.min(D,s)} 篇 · 解锁后可继续归档剩余 ${f} 篇，并自动增量更新`)}else{const f=Math.min(D,s);c.textContent=`免费试用 ${f} 篇`,d&&n(`检测到 ${s} 篇 · 本机可免费试用前 ${f} 篇；解锁后可一次完整归档`)}return{licensed:u,trialConsumed:v}}const U=async()=>{for(;b;)await se(300)};let H;const q=ye(async()=>{const d=H??await ne();H=void 0;const h=d?{}:await A().get(te),u=!d;if(u&&ge(h[te]))return a&&(a.panel.hidden=!1),{success:!1,error:"本机免费试用已使用，解锁后可导出完整合集"};c.textContent="暂停下载",l.disabled=!0,x.disabled=!0;let y="",v="",s=t,f=s.articleCount,S=Math.ceil(s.articleCount/G),P=!1;try{s=ee(),t=s,y=ce(s.id,s.ascending),v=be(s.id,s.ascending);const E={type:"ENSURE_ALBUM_DIRECTORY",album:{id:s.id,title:s.title,accountName:s.accountName,articleCount:w()}},g=await chrome.runtime.sendMessage(E);if(!g.success)throw new Error(g.error);if(!g.ready)return n(g.message),{success:!0,message:g.message};n(u?`检测到 ${w()} 篇 · 正在读取免费试用的前 ${Math.min(D,w())} 篇…`:`检测到 ${w()} 篇 · 正在检查上次归档后新增的文章…`);const p=await ve(s,u?D:Number.POSITIVE_INFINITY);if(p.length===0)throw new Error("合集列表暂时为空，请刷新页面后重试");const k={id:s.id,title:s.title,accountName:s.accountName,articleCount:u?w():p.length};if(u){const e=[];for(const[N,X]of p.entries())await U(),n(`免费试用 · 正在读取第 ${N+1}/${p.length} 篇（合集共 ${w()} 篇）`),e.push({...await de(X),position:X.position});n(`正在打包 ${p.length} 篇试用文章，并写入所选目录…`);const i={type:"EXPORT_ALBUM_BATCH",album:k,articles:e,batchNumber:1,totalBatches:1,trial:!0},m=await chrome.runtime.sendMessage(i);if(!m.success)throw new Error(m.error);const F=Math.max(w()-p.length,0);return n(`免费试用已保存 ${p.length} 篇 · 解锁后可继续归档剩余 ${F} 篇，并自动增量更新`),F>0&&a&&(a.panel.hidden=!1),{success:!0,message:`免费试用已保存 ${p.length} 篇`}}const R=await A().get([y,v]),T=R[y],B=T?.albumId===s.id&&T.status!=="completed",{pending:C,completedIdentities:L}=Be(p,R[v],B?T.completedArticleIds:void 0),Y=p.map(e=>({title:e.title,sourceUrl:e.url,publishTime:ke(e.createTime),position:e.position})),Z=B&&L.size>0&&C.length===0;if(C.length===0&&!Z)return await A().set({[v]:xe(p),[y]:{albumId:s.id,title:s.title,completedArticles:0,totalArticles:0,completedBatches:0,totalBatches:0,status:"completed"}}),n(`已是最新 · 当前 ${p.length} 篇均已归档，没有创建重复文件`),{success:!0,message:"合集已是最新，没有新增文章"};f=L.size+C.length;const z=B&&L.size>0&&Number.isInteger(T.completedBatches)&&T.completedBatches>=0?T.completedBatches:0,V=Math.ceil(C.length/G);S=z+V,await A().set({[y]:{albumId:s.id,title:s.title,completedArticles:L.size,totalArticles:f,completedBatches:z,totalBatches:S,completedArticleIds:[...L],status:"running"}}),P=!0;for(let e=0;e<V;e+=1){const i=z+e;await U();const m=C.slice(e*G,(e+1)*G),F=[];for(const[ie,fe]of m.entries())await U(),n(`待续传 ${C.length} 篇 · 第 ${i+1}/${S} 卷 · 正在读取第 ${e*G+ie+1} 篇`),F.push({...await de(fe),position:fe.position});n(`正在打包第 ${i+1}/${S} 卷，并写入所选目录…`);const N={type:"EXPORT_ALBUM_BATCH",album:k,articles:F,batchNumber:i+1,totalBatches:S},X=await chrome.runtime.sendMessage(N);if(!X.success)throw new Error(X.error);for(const ie of m)L.add(Se(ie));const Ee={albumId:s.id,title:s.title,completedArticles:L.size,totalArticles:f,completedBatches:i+1,totalBatches:S,completedArticleIds:[...L],status:"running"};await A().set({[y]:Ee})}const W={type:"EXPORT_ALBUM_INDEX",album:k,articles:Y},M=await chrome.runtime.sendMessage(W);if(!M.success)throw new Error(M.error);await A().set({[v]:xe(p)});const J={albumId:s.id,title:s.title,completedArticles:f,totalArticles:f,completedBatches:S,totalBatches:S,status:"completed"};await A().set({[y]:J}),n(`增量归档完成 · 新增 ${f} 篇 · 当前索引共 ${p.length} 篇`);const K={type:"NOTIFY_ALBUM_COMPLETE",album:k,exportedArticles:f,totalArticles:p.length};return await chrome.runtime.sendMessage(K).catch(()=>{}),{success:!0,message:`合集新增 ${f} 篇已归档`}}catch(E){const g=E instanceof Error?E.message:"合集下载失败，请稍后继续";if(u)return n(`${g}；下载未完成，免费试用资格不会消耗，可再次重试`),{success:!1,error:g};if(!P)return n(`${g}；再次点击会重新检查新增文章`),{success:!1,error:g};n(`${g}；再次点击可从已完成分卷继续`);const k=(y?await A().get(y):{})[y];return y&&await A().set({[y]:{albumId:s.id,title:s.title,completedArticles:k?.completedArticles||0,totalArticles:k?.totalArticles||f,completedBatches:k?.completedBatches||0,totalBatches:k?.totalBatches||S,completedArticleIds:k?.completedArticleIds,status:"failed",error:g}}),{success:!1,error:g}}finally{b=!1,x.disabled=!1,l.disabled=!1,_(!1).catch(()=>{c.textContent="下载合集"})}}),$=ye(async()=>{const d="加入文章库";l.disabled=!0,l.textContent="正在加入…",c.disabled=!0,x.disabled=!0;try{if(!await ne())return a&&(a.panel.hidden=!1),n("整合集加入文章库是完整版能力，请先解锁"),{success:!1,error:"整合集加入文章库需要解锁完整版"};const h=ee();n(`正在读取“${h.title}”的完整文章列表…`);const u=await ve(h);if(u.length===0)throw new Error("合集列表暂时为空，请刷新页面后重试");const y={id:h.id,title:h.title,accountName:h.accountName,articleCount:u.length},v=await we({type:"PREPARE_ALBUM_LIBRARY",album:y}),s=new Set(v.linkedArticleIds),f=u.filter(E=>!s.has(Ye(E.url)));if(f.length===0)return n(`“${v.collection.name}”已包含全部 ${u.length} 篇文章，正在打开文章库…`),await chrome.runtime.sendMessage({type:"OPEN_LIBRARY",collectionId:v.collection.id}),{success:!0,message:"合集已全部加入文章库"};let S=v.collection,P=0;for(let E=0;E<f.length;E+=10){const g=f.slice(E,E+10);let p=0;const k=await Le(g,3,async T=>{const B=await de(T);return p+=1,n(`正在并行读取“${S.name}” · ${P+p}/${f.length} 篇`),B}),R=await we({type:"ARCHIVE_ALBUM_LIBRARY_BATCH",album:y,articles:k});S=R.collection,P+=R.articleIds.length}return n(`已加入“${S.name}” · 新增 ${P} 篇 · 共 ${u.length} 篇，正在打开文章库…`),await chrome.runtime.sendMessage({type:"OPEN_LIBRARY",collectionId:S.id}),{success:!0,message:`已把 ${P} 篇文章加入文章库`}}catch(h){const u=h instanceof Error?h.message:"合集加入文章库失败";return n(`${u}；再次点击会跳过已成功入库的文章并继续`),{success:!1,error:u}}finally{l.disabled=!1,l.textContent=d,c.disabled=!1,x.disabled=!1}});oe=async()=>{if(q.isRunning())return b=!b,c.textContent=b?"继续下载":"暂停下载",n(b?"任务已暂停，点击继续下载":"任务已继续"),{success:!0,message:b?"合集任务已暂停":"合集任务已继续"};const d=await _(!1);if(!d.licensed&&d.trialConsumed){const h=Math.max(w()-Math.min(D,w()),0);return n(`已免费保存 ${Math.min(D,w())} 篇 · 解锁后可继续归档剩余 ${h} 篇，并自动增量更新`),a&&(a.panel.hidden=!1),{success:!1,error:"本机免费试用已使用，解锁后可导出完整合集"}}return b=!1,H=d.licensed,q.run()},ae=async()=>{if(q.isRunning())return{success:!1,error:"当前任务仍在运行，请等待本卷完成或取消保存后再完整重新导出"};if(!await ne())return n("完整重新导出是完整版能力；可先使用一次免费试用"),{success:!1,error:"完整重新导出需要解锁完整版"};const d=ee();return await A().remove([ce(d.id,d.ascending),be(d.id,d.ascending)]),n("当前排序方向的断点和增量历史已清零，正在完整重新导出…"),H=!0,q.run()};const j=d=>{d&&d().catch(h=>n(Q(h)))};c.addEventListener("click",()=>{j(oe)}),l.addEventListener("click",()=>{j(()=>$.run())}),x.addEventListener("click",()=>{j(ae)}),document.documentElement.append(o);const O=ce(t.id,t.ascending);try{_(!0).then(async({licensed:d})=>{if(!d)return;const u=(await A().get(O))[O];(u?.status==="running"||u?.status==="failed")&&n(`上次新增归档完成 ${u.completedArticles}/${u.totalArticles} 篇，点击继续`)}).catch(()=>n("扩展已更新，请刷新当前页面后再试"))}catch(d){n(d instanceof Error?d.message:"扩展已更新，请刷新当前页面后再试")}}at();ue=ot({onQuickSave:t=>{pe=t}});
